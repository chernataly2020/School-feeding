﻿namespace Школьное_питание
{


    partial class SchoolFoodDataSet
    {
    }
}
