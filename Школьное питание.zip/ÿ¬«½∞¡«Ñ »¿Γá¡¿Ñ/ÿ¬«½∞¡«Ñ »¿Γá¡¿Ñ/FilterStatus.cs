﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Школьное_питание
{
    class FilterStatus
    {
        public string columnName { get; set; }
        public string valueString { get; set; }
        public bool check { get; set; }
    }
}
