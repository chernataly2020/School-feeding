﻿namespace Школьное_питание
{
    partial class Admin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle79 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle80 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle81 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle82 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle83 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle84 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle85 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle86 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle87 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle88 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle89 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle90 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle91 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle92 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle93 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle94 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle95 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle96 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle97 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle98 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle99 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle100 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle101 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle102 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle103 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle104 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Admin));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bindingNavigator2 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem1 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bindingNavigator3 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem2 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem2 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem2 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem2 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem2 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem2 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem2 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem2 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.bindingNavigator4 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem3 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem3 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem3 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem3 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem3 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem3 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem3 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem3 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.bindingNavigator5 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem4 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem4 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem4 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem4 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem4 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem4 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem4 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem4 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.bindingNavigator6 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem5 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem5 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem5 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem5 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem5 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem5 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem5 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem5 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridView6 = new System.Windows.Forms.DataGridView();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.bindingNavigator11 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem10 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator30 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem10 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator31 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator32 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView10 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator10 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem9 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator27 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem9 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator28 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator29 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView12 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator12 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridView13 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator13 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.bindingNavigator9 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem8 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator24 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem8 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator25 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator26 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator7 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem6 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem6 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.bindingNavigator8 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem7 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem7 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.fillToolStrip1 = new System.Windows.Forms.ToolStrip();
            this.fillToolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.fillBy2ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox3 = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy2ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBy1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.dataGridView17 = new System.Windows.Forms.DataGridView();
            this.Месяц = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Год = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingNavigator18 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem15 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem15 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem15 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator45 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem15 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator46 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem15 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem15 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator47 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton23 = new System.Windows.Forms.ToolStripButton();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.dataGridView18 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingNavigator19 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem16 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem16 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem16 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator48 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem16 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator49 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem16 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem16 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator50 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.dataGridView19 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator20 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem17 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem17 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem17 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator51 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem17 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator52 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem17 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem17 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator53 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton20 = new System.Windows.Forms.ToolStripButton();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.dataGridView20 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator14 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem11 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem11 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem11 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator33 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem11 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator34 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem11 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem11 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator35 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton21 = new System.Windows.Forms.ToolStripButton();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.dataGridView15 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator15 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem12 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem12 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem12 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator36 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem12 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator37 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem12 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem12 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator38 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.dataGridView14 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator17 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem14 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem14 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem14 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator42 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem14 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator43 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem14 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem14 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator44 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton18 = new System.Windows.Forms.ToolStripButton();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.dataGridView16 = new System.Windows.Forms.DataGridView();
            this.bindingNavigator16 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem13 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem13 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem13 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator39 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem13 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator40 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem13 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem13 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator41 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton19 = new System.Windows.Forms.ToolStripButton();
            this.tabPage24 = new System.Windows.Forms.TabPage();
            this.bindingNavigator21 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem18 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem18 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem18 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator54 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem18 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator55 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem18 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem18 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator56 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.dataGridView21 = new System.Windows.Forms.DataGridView();
            this.tabPage25 = new System.Windows.Forms.TabPage();
            this.bindingNavigator22 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem19 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem19 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem19 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator57 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem19 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator58 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem19 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem19 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator59 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton24 = new System.Windows.Forms.ToolStripButton();
            this.dataGridView22 = new System.Windows.Forms.DataGridView();
            this.Close_Pr = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewCalendarColumn1 = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCalendarColumn2 = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.dataGridViewComboBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCalendarColumn3 = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.dataGridViewComboBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn6 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewCalendarColumn4 = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.dataGridViewComboBoxColumn7 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn8 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewCalendarColumn5 = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.dataGridViewComboBoxColumn9 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn10 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn54 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn57 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn58 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn60 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn61 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn62 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn63 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn64 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn65 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn66 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn67 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn68 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn69 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn70 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn71 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn72 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn73 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.справочникПоставщиковBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet = new Школьное_питание.SchoolFoodDataSet();
            this.кодПоставщикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеПоставщикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.реквизитыПоставщикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.справочникТиповПитанияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.кодТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.справочникПродуктовBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.кодПродуктаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.справочникКлассовBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.кодКлассаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеКлассаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.учителяШколыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.кодУчителяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУчителяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.домашнийАдресDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.телефонDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.предметDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ученикиШколыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.кодУченикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУченикаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.классDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.датаРожденияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.домашнийАдресDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.телефонDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кПоставкеТоваровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.накладнойDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.накладнойDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаПоставкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.поставщикDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.поставкаТоваровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.накладнойDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаРасходаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.типПитанияDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.количествоУчащихсяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.расходТоваровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.накладнойDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кРасходуBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.затратыПродуктовBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.датаЗатратDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.продуктDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.количествоНаПорциюDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типПитанияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.фИОУчителяDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.датаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.типПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.количествоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.питаниеУчителейBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.питаниеУчениковBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.фИОУченикаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.датаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewCalendarColumn();
            this.типПитанияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.справочникТиповПитанияBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.количествоDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.классDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.названиеКлассаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view51BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.фИОУчителяDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.итогоКоличествоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view61BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet5 = new Школьное_питание.SchoolFoodDataSet();
            this.датаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеКлассаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУченикаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.датаDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУчителяDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view8BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet6 = new Школьное_питание.SchoolFoodDataSet();
            this.датаЗатратDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоНаПорциюDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet3 = new Школьное_питание.SchoolFoodDataSet();
            this.датаПоставкиDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеПоставщикаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.итогоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view41BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.датаРасходаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.общаяСуммаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view3BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet4 = new Школьное_питание.SchoolFoodDataSet();
            this.view10BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet7 = new Школьное_питание.SchoolFoodDataSet();
            this.датаЗатратDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУченикаDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеКлассаDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.итогоDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view11BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet2 = new Школьное_питание.SchoolFoodDataSet();
            this.schoolFoodDataSet1 = new Школьное_питание.SchoolFoodDataSet();
            this.справочник_поставщиковTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Справочник_поставщиковTableAdapter();
            this.справочник_типов_питанияTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Справочник_типов_питанияTableAdapter();
            this.справочник_продуктовTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Справочник_продуктовTableAdapter();
            this.справочник_классовTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Справочник_классовTableAdapter();
            this.учителя_школыTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Учителя_школыTableAdapter();
            this.ученики_школыTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Ученики_школыTableAdapter();
            this.питание_учителейTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Питание_учителейTableAdapter();
            this.питание_учениковTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Питание_учениковTableAdapter();
            this.затраты_продуктовTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Затраты_продуктовTableAdapter();
            this.поставка_товаровTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Поставка_товаровTableAdapter();
            this.к_поставке_товаровTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.К_поставке_товаровTableAdapter();
            this.расход_товаровTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Расход_товаровTableAdapter();
            this.к_расходуTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.К_расходуTableAdapter();
            this.view4TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View4TableAdapter();
            this.view2TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View2TableAdapter();
            this.view41TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View41TableAdapter();
            this.view3TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View3TableAdapter();
            this.view51TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View51TableAdapter();
            this.view61TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View61TableAdapter();
            this.viewTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.ViewTableAdapter();
            this.view8TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View8TableAdapter();
            this.view1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view2BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.view4BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view10TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View10TableAdapter();
            this.view11TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View11TableAdapter();
            this.tabPage26 = new System.Windows.Forms.TabPage();
            this.dataGridView23 = new System.Windows.Forms.DataGridView();
            this.view12BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view12TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View12TableAdapter();
            this.месяцDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.годDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУченикаDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеКлассаDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.итогоDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingNavigator23 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem20 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem20 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator60 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem20 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem20 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator61 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem20 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem20 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator62 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton25 = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).BeginInit();
            this.bindingNavigator2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator3)).BeginInit();
            this.bindingNavigator3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator4)).BeginInit();
            this.bindingNavigator4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator5)).BeginInit();
            this.bindingNavigator5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.tabPage8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator6)).BeginInit();
            this.bindingNavigator6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator11)).BeginInit();
            this.bindingNavigator11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator10)).BeginInit();
            this.bindingNavigator10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator12)).BeginInit();
            this.bindingNavigator12.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator13)).BeginInit();
            this.bindingNavigator13.SuspendLayout();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator9)).BeginInit();
            this.bindingNavigator9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            this.tabPage13.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator7)).BeginInit();
            this.bindingNavigator7.SuspendLayout();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator8)).BeginInit();
            this.bindingNavigator8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            this.tabPage16.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.fillToolStrip1.SuspendLayout();
            this.fillBy2ToolStrip.SuspendLayout();
            this.fillBy1ToolStrip.SuspendLayout();
            this.fillByToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator18)).BeginInit();
            this.bindingNavigator18.SuspendLayout();
            this.tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator19)).BeginInit();
            this.bindingNavigator19.SuspendLayout();
            this.tabPage19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator20)).BeginInit();
            this.bindingNavigator20.SuspendLayout();
            this.tabPage20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator14)).BeginInit();
            this.bindingNavigator14.SuspendLayout();
            this.tabPage21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator15)).BeginInit();
            this.bindingNavigator15.SuspendLayout();
            this.tabPage22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator17)).BeginInit();
            this.bindingNavigator17.SuspendLayout();
            this.tabPage23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator16)).BeginInit();
            this.bindingNavigator16.SuspendLayout();
            this.tabPage24.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator21)).BeginInit();
            this.bindingNavigator21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView21)).BeginInit();
            this.tabPage25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator22)).BeginInit();
            this.bindingNavigator22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникПоставщиковBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникТиповПитанияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникПродуктовBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникКлассовBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.учителяШколыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ученикиШколыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.кПоставкеТоваровBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.поставкаТоваровBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расходТоваровBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.кРасходуBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.затратыПродуктовBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеУчителейBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеУчениковBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникТиповПитанияBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view51BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view61BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view8BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view41BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view10BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view11BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view4BindingSource)).BeginInit();
            this.tabPage26.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view12BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator23)).BeginInit();
            this.bindingNavigator23.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Школьное_питание.Properties.Resources.workgroup_1205;
            this.pictureBox1.Location = new System.Drawing.Point(44, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 95);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(12, 119);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 1;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage16);
            this.tabControl1.Location = new System.Drawing.Point(188, 7);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(716, 477);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.tabControl2);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(708, 451);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Справочники";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Controls.Add(this.tabPage4);
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Location = new System.Drawing.Point(6, 6);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(696, 439);
            this.tabControl2.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.Controls.Add(this.dataGridView1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(688, 413);
            this.tabPage3.TabIndex = 0;
            this.tabPage3.Text = "Справочник поставщиков";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.bindingNavigator1);
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(6, 6);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(676, 142);
            this.panel1.TabIndex = 2;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigator1.BindingSource = this.справочникПоставщиковBindingSource;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.сохранитьToolStripButton1,
            this.toolStripSeparator2});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 117);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(676, 25);
            this.bindingNavigator1.TabIndex = 14;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton1
            // 
            this.сохранитьToolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton1.Image")));
            this.сохранитьToolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton1.Name = "сохранитьToolStripButton1";
            this.сохранитьToolStripButton1.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton1.Text = "&Сохранить данные";
            this.сохранитьToolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // textBox3
            // 
            this.textBox3.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникПоставщиковBindingSource, "Реквизиты поставщика", true));
            this.textBox3.Location = new System.Drawing.Point(141, 65);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(525, 36);
            this.textBox3.TabIndex = 13;
            this.textBox3.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox3_KeyDown);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(2, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Реквизиты поставщика";
            // 
            // textBox2
            // 
            this.textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникПоставщиковBindingSource, "Название поставщика", true));
            this.textBox2.Location = new System.Drawing.Point(141, 38);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(196, 20);
            this.textBox2.TabIndex = 11;
            this.textBox2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox2_KeyDown);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Название поставщика";
            // 
            // textBox1
            // 
            this.textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникПоставщиковBindingSource, "Код поставщика", true));
            this.textBox1.Location = new System.Drawing.Point(141, 9);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(196, 20);
            this.textBox1.TabIndex = 9;
            this.textBox1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Код поставщика";
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодПоставщикаDataGridViewTextBoxColumn,
            this.названиеПоставщикаDataGridViewTextBoxColumn,
            this.реквизитыПоставщикаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.справочникПоставщиковBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(3, 154);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(682, 256);
            this.dataGridView1.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel2);
            this.tabPage4.Controls.Add(this.dataGridView2);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(688, 413);
            this.tabPage4.TabIndex = 1;
            this.tabPage4.Text = "Справочник типов питания";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.Controls.Add(this.bindingNavigator2);
            this.panel2.Controls.Add(this.textBox5);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.textBox6);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Location = new System.Drawing.Point(3, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(676, 108);
            this.panel2.TabIndex = 3;
            // 
            // bindingNavigator2
            // 
            this.bindingNavigator2.AddNewItem = this.bindingNavigatorAddNewItem1;
            this.bindingNavigator2.BindingSource = this.справочникТиповПитанияBindingSource;
            this.bindingNavigator2.CountItem = this.bindingNavigatorCountItem1;
            this.bindingNavigator2.DeleteItem = this.bindingNavigatorDeleteItem1;
            this.bindingNavigator2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem1,
            this.bindingNavigatorMovePreviousItem1,
            this.bindingNavigatorSeparator3,
            this.bindingNavigatorPositionItem1,
            this.bindingNavigatorCountItem1,
            this.bindingNavigatorSeparator4,
            this.bindingNavigatorMoveNextItem1,
            this.bindingNavigatorMoveLastItem1,
            this.bindingNavigatorSeparator5,
            this.bindingNavigatorAddNewItem1,
            this.bindingNavigatorDeleteItem1,
            this.сохранитьToolStripButton,
            this.toolStripSeparator});
            this.bindingNavigator2.Location = new System.Drawing.Point(0, 83);
            this.bindingNavigator2.MoveFirstItem = this.bindingNavigatorMoveFirstItem1;
            this.bindingNavigator2.MoveLastItem = this.bindingNavigatorMoveLastItem1;
            this.bindingNavigator2.MoveNextItem = this.bindingNavigatorMoveNextItem1;
            this.bindingNavigator2.MovePreviousItem = this.bindingNavigatorMovePreviousItem1;
            this.bindingNavigator2.Name = "bindingNavigator2";
            this.bindingNavigator2.PositionItem = this.bindingNavigatorPositionItem1;
            this.bindingNavigator2.Size = new System.Drawing.Size(676, 25);
            this.bindingNavigator2.TabIndex = 14;
            this.bindingNavigator2.Text = "bindingNavigator2";
            // 
            // bindingNavigatorAddNewItem1
            // 
            this.bindingNavigatorAddNewItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem1.Image")));
            this.bindingNavigatorAddNewItem1.Name = "bindingNavigatorAddNewItem1";
            this.bindingNavigatorAddNewItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem1.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem1.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem1
            // 
            this.bindingNavigatorCountItem1.Name = "bindingNavigatorCountItem1";
            this.bindingNavigatorCountItem1.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem1.Text = "для {0}";
            this.bindingNavigatorCountItem1.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem1
            // 
            this.bindingNavigatorDeleteItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem1.Image")));
            this.bindingNavigatorDeleteItem1.Name = "bindingNavigatorDeleteItem1";
            this.bindingNavigatorDeleteItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem1.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem1.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem1
            // 
            this.bindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem1.Image")));
            this.bindingNavigatorMoveFirstItem1.Name = "bindingNavigatorMoveFirstItem1";
            this.bindingNavigatorMoveFirstItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem1.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem1
            // 
            this.bindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem1.Image")));
            this.bindingNavigatorMovePreviousItem1.Name = "bindingNavigatorMovePreviousItem1";
            this.bindingNavigatorMovePreviousItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem1.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator3
            // 
            this.bindingNavigatorSeparator3.Name = "bindingNavigatorSeparator3";
            this.bindingNavigatorSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem1
            // 
            this.bindingNavigatorPositionItem1.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem1.AutoSize = false;
            this.bindingNavigatorPositionItem1.Name = "bindingNavigatorPositionItem1";
            this.bindingNavigatorPositionItem1.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem1.Text = "0";
            this.bindingNavigatorPositionItem1.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator4
            // 
            this.bindingNavigatorSeparator4.Name = "bindingNavigatorSeparator4";
            this.bindingNavigatorSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem1
            // 
            this.bindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem1.Image")));
            this.bindingNavigatorMoveNextItem1.Name = "bindingNavigatorMoveNextItem1";
            this.bindingNavigatorMoveNextItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem1.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem1
            // 
            this.bindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem1.Image")));
            this.bindingNavigatorMoveLastItem1.Name = "bindingNavigatorMoveLastItem1";
            this.bindingNavigatorMoveLastItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem1.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem1.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator5
            // 
            this.bindingNavigatorSeparator5.Name = "bindingNavigatorSeparator5";
            this.bindingNavigatorSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton
            // 
            this.сохранитьToolStripButton.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton.Image")));
            this.сохранитьToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton.Name = "сохранитьToolStripButton";
            this.сохранитьToolStripButton.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton.Text = "&Сохранить данные";
            this.сохранитьToolStripButton.Click += new System.EventHandler(this.сохранитьToolStripButton_Click);
            // 
            // toolStripSeparator
            // 
            this.toolStripSeparator.Name = "toolStripSeparator";
            this.toolStripSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // textBox5
            // 
            this.textBox5.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникТиповПитанияBindingSource, "Название типа питания", true));
            this.textBox5.Location = new System.Drawing.Point(141, 38);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(196, 20);
            this.textBox5.TabIndex = 11;
            this.textBox5.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox5_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(3, 38);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(127, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Название типа питания";
            // 
            // textBox6
            // 
            this.textBox6.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникТиповПитанияBindingSource, "Код типа питания", true));
            this.textBox6.Location = new System.Drawing.Point(141, 9);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(196, 20);
            this.textBox6.TabIndex = 9;
            this.textBox6.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox6_KeyDown);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "Код типа питания";
            // 
            // dataGridView2
            // 
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодТипаПитанияDataGridViewTextBoxColumn,
            this.названиеТипаПитанияDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.справочникТиповПитанияBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(3, 120);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(682, 290);
            this.dataGridView2.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel3);
            this.tabPage5.Controls.Add(this.dataGridView3);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(688, 413);
            this.tabPage5.TabIndex = 2;
            this.tabPage5.Text = "Справочник продуктов";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.bindingNavigator3);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.textBox7);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Location = new System.Drawing.Point(6, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(676, 108);
            this.panel3.TabIndex = 4;
            // 
            // bindingNavigator3
            // 
            this.bindingNavigator3.AddNewItem = this.bindingNavigatorAddNewItem2;
            this.bindingNavigator3.BindingSource = this.справочникПродуктовBindingSource;
            this.bindingNavigator3.CountItem = this.bindingNavigatorCountItem2;
            this.bindingNavigator3.DeleteItem = this.bindingNavigatorDeleteItem2;
            this.bindingNavigator3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem2,
            this.bindingNavigatorMovePreviousItem2,
            this.bindingNavigatorSeparator6,
            this.bindingNavigatorPositionItem2,
            this.bindingNavigatorCountItem2,
            this.bindingNavigatorSeparator7,
            this.bindingNavigatorMoveNextItem2,
            this.bindingNavigatorMoveLastItem2,
            this.bindingNavigatorSeparator8,
            this.bindingNavigatorAddNewItem2,
            this.bindingNavigatorDeleteItem2,
            this.сохранитьToolStripButton2,
            this.toolStripSeparator1});
            this.bindingNavigator3.Location = new System.Drawing.Point(0, 83);
            this.bindingNavigator3.MoveFirstItem = this.bindingNavigatorMoveFirstItem2;
            this.bindingNavigator3.MoveLastItem = this.bindingNavigatorMoveLastItem2;
            this.bindingNavigator3.MoveNextItem = this.bindingNavigatorMoveNextItem2;
            this.bindingNavigator3.MovePreviousItem = this.bindingNavigatorMovePreviousItem2;
            this.bindingNavigator3.Name = "bindingNavigator3";
            this.bindingNavigator3.PositionItem = this.bindingNavigatorPositionItem2;
            this.bindingNavigator3.Size = new System.Drawing.Size(676, 25);
            this.bindingNavigator3.TabIndex = 12;
            this.bindingNavigator3.Text = "bindingNavigator3";
            // 
            // bindingNavigatorAddNewItem2
            // 
            this.bindingNavigatorAddNewItem2.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem2.Image")));
            this.bindingNavigatorAddNewItem2.Name = "bindingNavigatorAddNewItem2";
            this.bindingNavigatorAddNewItem2.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem2.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem2.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem2
            // 
            this.bindingNavigatorCountItem2.Name = "bindingNavigatorCountItem2";
            this.bindingNavigatorCountItem2.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem2.Text = "для {0}";
            this.bindingNavigatorCountItem2.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem2
            // 
            this.bindingNavigatorDeleteItem2.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem2.Image")));
            this.bindingNavigatorDeleteItem2.Name = "bindingNavigatorDeleteItem2";
            this.bindingNavigatorDeleteItem2.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem2.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem2.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem2
            // 
            this.bindingNavigatorMoveFirstItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem2.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem2.Image")));
            this.bindingNavigatorMoveFirstItem2.Name = "bindingNavigatorMoveFirstItem2";
            this.bindingNavigatorMoveFirstItem2.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem2.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem2.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem2
            // 
            this.bindingNavigatorMovePreviousItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem2.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem2.Image")));
            this.bindingNavigatorMovePreviousItem2.Name = "bindingNavigatorMovePreviousItem2";
            this.bindingNavigatorMovePreviousItem2.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem2.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem2.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator6
            // 
            this.bindingNavigatorSeparator6.Name = "bindingNavigatorSeparator6";
            this.bindingNavigatorSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem2
            // 
            this.bindingNavigatorPositionItem2.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem2.AutoSize = false;
            this.bindingNavigatorPositionItem2.Name = "bindingNavigatorPositionItem2";
            this.bindingNavigatorPositionItem2.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem2.Text = "0";
            this.bindingNavigatorPositionItem2.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator7
            // 
            this.bindingNavigatorSeparator7.Name = "bindingNavigatorSeparator7";
            this.bindingNavigatorSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem2
            // 
            this.bindingNavigatorMoveNextItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem2.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem2.Image")));
            this.bindingNavigatorMoveNextItem2.Name = "bindingNavigatorMoveNextItem2";
            this.bindingNavigatorMoveNextItem2.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem2.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem2.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem2
            // 
            this.bindingNavigatorMoveLastItem2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem2.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem2.Image")));
            this.bindingNavigatorMoveLastItem2.Name = "bindingNavigatorMoveLastItem2";
            this.bindingNavigatorMoveLastItem2.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem2.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem2.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator8
            // 
            this.bindingNavigatorSeparator8.Name = "bindingNavigatorSeparator8";
            this.bindingNavigatorSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton2
            // 
            this.сохранитьToolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton2.Image")));
            this.сохранитьToolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton2.Name = "сохранитьToolStripButton2";
            this.сохранитьToolStripButton2.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton2.Text = "&Сохранить данные";
            this.сохранитьToolStripButton2.Click += new System.EventHandler(this.сохранитьToolStripButton2_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // textBox4
            // 
            this.textBox4.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникПродуктовBindingSource, "Наименование продукта", true));
            this.textBox4.Location = new System.Drawing.Point(141, 38);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(196, 20);
            this.textBox4.TabIndex = 11;
            this.textBox4.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox4_KeyDown);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(3, 38);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Название продукта";
            // 
            // textBox7
            // 
            this.textBox7.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникПродуктовBindingSource, "Код продукта", true));
            this.textBox7.Location = new System.Drawing.Point(141, 9);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(196, 20);
            this.textBox7.TabIndex = 9;
            this.textBox7.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox7_KeyDown);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(3, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Код продуктов";
            // 
            // dataGridView3
            // 
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодПродуктаDataGridViewTextBoxColumn,
            this.наименованиеПродуктаDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.справочникПродуктовBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(3, 120);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(682, 290);
            this.dataGridView3.TabIndex = 0;
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.panel4);
            this.tabPage6.Controls.Add(this.dataGridView4);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(688, 413);
            this.tabPage6.TabIndex = 3;
            this.tabPage6.Text = "Справочник классов";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.bindingNavigator4);
            this.panel4.Controls.Add(this.textBox8);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.textBox9);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Location = new System.Drawing.Point(3, 6);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(676, 108);
            this.panel4.TabIndex = 5;
            // 
            // bindingNavigator4
            // 
            this.bindingNavigator4.AddNewItem = this.bindingNavigatorAddNewItem3;
            this.bindingNavigator4.BindingSource = this.справочникКлассовBindingSource;
            this.bindingNavigator4.CountItem = this.bindingNavigatorCountItem3;
            this.bindingNavigator4.DeleteItem = this.bindingNavigatorDeleteItem3;
            this.bindingNavigator4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem3,
            this.bindingNavigatorMovePreviousItem3,
            this.bindingNavigatorSeparator9,
            this.bindingNavigatorPositionItem3,
            this.bindingNavigatorCountItem3,
            this.bindingNavigatorSeparator10,
            this.bindingNavigatorMoveNextItem3,
            this.bindingNavigatorMoveLastItem3,
            this.bindingNavigatorSeparator11,
            this.bindingNavigatorAddNewItem3,
            this.bindingNavigatorDeleteItem3,
            this.сохранитьToolStripButton3,
            this.toolStripSeparator3});
            this.bindingNavigator4.Location = new System.Drawing.Point(0, 83);
            this.bindingNavigator4.MoveFirstItem = this.bindingNavigatorMoveFirstItem3;
            this.bindingNavigator4.MoveLastItem = this.bindingNavigatorMoveLastItem3;
            this.bindingNavigator4.MoveNextItem = this.bindingNavigatorMoveNextItem3;
            this.bindingNavigator4.MovePreviousItem = this.bindingNavigatorMovePreviousItem3;
            this.bindingNavigator4.Name = "bindingNavigator4";
            this.bindingNavigator4.PositionItem = this.bindingNavigatorPositionItem3;
            this.bindingNavigator4.Size = new System.Drawing.Size(676, 25);
            this.bindingNavigator4.TabIndex = 12;
            this.bindingNavigator4.Text = "bindingNavigator4";
            // 
            // bindingNavigatorAddNewItem3
            // 
            this.bindingNavigatorAddNewItem3.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem3.Image")));
            this.bindingNavigatorAddNewItem3.Name = "bindingNavigatorAddNewItem3";
            this.bindingNavigatorAddNewItem3.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem3.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem3.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem3
            // 
            this.bindingNavigatorCountItem3.Name = "bindingNavigatorCountItem3";
            this.bindingNavigatorCountItem3.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem3.Text = "для {0}";
            this.bindingNavigatorCountItem3.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem3
            // 
            this.bindingNavigatorDeleteItem3.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem3.Image")));
            this.bindingNavigatorDeleteItem3.Name = "bindingNavigatorDeleteItem3";
            this.bindingNavigatorDeleteItem3.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem3.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem3.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem3
            // 
            this.bindingNavigatorMoveFirstItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem3.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem3.Image")));
            this.bindingNavigatorMoveFirstItem3.Name = "bindingNavigatorMoveFirstItem3";
            this.bindingNavigatorMoveFirstItem3.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem3.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem3.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem3
            // 
            this.bindingNavigatorMovePreviousItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem3.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem3.Image")));
            this.bindingNavigatorMovePreviousItem3.Name = "bindingNavigatorMovePreviousItem3";
            this.bindingNavigatorMovePreviousItem3.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem3.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem3.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator9
            // 
            this.bindingNavigatorSeparator9.Name = "bindingNavigatorSeparator9";
            this.bindingNavigatorSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem3
            // 
            this.bindingNavigatorPositionItem3.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem3.AutoSize = false;
            this.bindingNavigatorPositionItem3.Name = "bindingNavigatorPositionItem3";
            this.bindingNavigatorPositionItem3.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem3.Text = "0";
            this.bindingNavigatorPositionItem3.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator10
            // 
            this.bindingNavigatorSeparator10.Name = "bindingNavigatorSeparator10";
            this.bindingNavigatorSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem3
            // 
            this.bindingNavigatorMoveNextItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem3.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem3.Image")));
            this.bindingNavigatorMoveNextItem3.Name = "bindingNavigatorMoveNextItem3";
            this.bindingNavigatorMoveNextItem3.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem3.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem3.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem3
            // 
            this.bindingNavigatorMoveLastItem3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem3.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem3.Image")));
            this.bindingNavigatorMoveLastItem3.Name = "bindingNavigatorMoveLastItem3";
            this.bindingNavigatorMoveLastItem3.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem3.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem3.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator11
            // 
            this.bindingNavigatorSeparator11.Name = "bindingNavigatorSeparator11";
            this.bindingNavigatorSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton3
            // 
            this.сохранитьToolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton3.Image")));
            this.сохранитьToolStripButton3.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton3.Name = "сохранитьToolStripButton3";
            this.сохранитьToolStripButton3.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton3.Text = "&Сохранить данные";
            this.сохранитьToolStripButton3.Click += new System.EventHandler(this.сохранитьToolStripButton3_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // textBox8
            // 
            this.textBox8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникПродуктовBindingSource, "Наименование продукта", true));
            this.textBox8.Location = new System.Drawing.Point(141, 38);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(196, 20);
            this.textBox8.TabIndex = 11;
            this.textBox8.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox8_KeyDown);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 38);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "Название класса";
            // 
            // textBox9
            // 
            this.textBox9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.справочникПродуктовBindingSource, "Код продукта", true));
            this.textBox9.Location = new System.Drawing.Point(141, 9);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(196, 20);
            this.textBox9.TabIndex = 9;
            this.textBox9.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox9_KeyDown);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(3, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Код класса";
            // 
            // dataGridView4
            // 
            this.dataGridView4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодКлассаDataGridViewTextBoxColumn,
            this.названиеКлассаDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.справочникКлассовBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(3, 117);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(682, 268);
            this.dataGridView4.TabIndex = 1;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.tabControl3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(708, 451);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Школа";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // tabControl3
            // 
            this.tabControl3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl3.Controls.Add(this.tabPage7);
            this.tabControl3.Controls.Add(this.tabPage8);
            this.tabControl3.Location = new System.Drawing.Point(7, 7);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(695, 438);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.bindingNavigator5);
            this.tabPage7.Controls.Add(this.dataGridView5);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(687, 412);
            this.tabPage7.TabIndex = 0;
            this.tabPage7.Text = "Учителя";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator5
            // 
            this.bindingNavigator5.AddNewItem = this.bindingNavigatorAddNewItem4;
            this.bindingNavigator5.BindingSource = this.учителяШколыBindingSource;
            this.bindingNavigator5.CountItem = this.bindingNavigatorCountItem4;
            this.bindingNavigator5.DeleteItem = this.bindingNavigatorDeleteItem4;
            this.bindingNavigator5.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator5.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem4,
            this.bindingNavigatorMovePreviousItem4,
            this.bindingNavigatorSeparator12,
            this.bindingNavigatorPositionItem4,
            this.bindingNavigatorCountItem4,
            this.bindingNavigatorSeparator13,
            this.bindingNavigatorMoveNextItem4,
            this.bindingNavigatorMoveLastItem4,
            this.bindingNavigatorSeparator14,
            this.bindingNavigatorAddNewItem4,
            this.bindingNavigatorDeleteItem4,
            this.сохранитьToolStripButton4,
            this.toolStripSeparator4});
            this.bindingNavigator5.Location = new System.Drawing.Point(3, 384);
            this.bindingNavigator5.MoveFirstItem = this.bindingNavigatorMoveFirstItem4;
            this.bindingNavigator5.MoveLastItem = this.bindingNavigatorMoveLastItem4;
            this.bindingNavigator5.MoveNextItem = this.bindingNavigatorMoveNextItem4;
            this.bindingNavigator5.MovePreviousItem = this.bindingNavigatorMovePreviousItem4;
            this.bindingNavigator5.Name = "bindingNavigator5";
            this.bindingNavigator5.PositionItem = this.bindingNavigatorPositionItem4;
            this.bindingNavigator5.Size = new System.Drawing.Size(681, 25);
            this.bindingNavigator5.TabIndex = 1;
            this.bindingNavigator5.Text = "bindingNavigator5";
            // 
            // bindingNavigatorAddNewItem4
            // 
            this.bindingNavigatorAddNewItem4.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem4.Image")));
            this.bindingNavigatorAddNewItem4.Name = "bindingNavigatorAddNewItem4";
            this.bindingNavigatorAddNewItem4.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem4.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem4.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem4
            // 
            this.bindingNavigatorCountItem4.Name = "bindingNavigatorCountItem4";
            this.bindingNavigatorCountItem4.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem4.Text = "для {0}";
            this.bindingNavigatorCountItem4.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem4
            // 
            this.bindingNavigatorDeleteItem4.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem4.Image")));
            this.bindingNavigatorDeleteItem4.Name = "bindingNavigatorDeleteItem4";
            this.bindingNavigatorDeleteItem4.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem4.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem4.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem4
            // 
            this.bindingNavigatorMoveFirstItem4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem4.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem4.Image")));
            this.bindingNavigatorMoveFirstItem4.Name = "bindingNavigatorMoveFirstItem4";
            this.bindingNavigatorMoveFirstItem4.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem4.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem4.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem4
            // 
            this.bindingNavigatorMovePreviousItem4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem4.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem4.Image")));
            this.bindingNavigatorMovePreviousItem4.Name = "bindingNavigatorMovePreviousItem4";
            this.bindingNavigatorMovePreviousItem4.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem4.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem4.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator12
            // 
            this.bindingNavigatorSeparator12.Name = "bindingNavigatorSeparator12";
            this.bindingNavigatorSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem4
            // 
            this.bindingNavigatorPositionItem4.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem4.AutoSize = false;
            this.bindingNavigatorPositionItem4.Name = "bindingNavigatorPositionItem4";
            this.bindingNavigatorPositionItem4.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem4.Text = "0";
            this.bindingNavigatorPositionItem4.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator13
            // 
            this.bindingNavigatorSeparator13.Name = "bindingNavigatorSeparator13";
            this.bindingNavigatorSeparator13.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem4
            // 
            this.bindingNavigatorMoveNextItem4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem4.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem4.Image")));
            this.bindingNavigatorMoveNextItem4.Name = "bindingNavigatorMoveNextItem4";
            this.bindingNavigatorMoveNextItem4.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem4.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem4.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem4
            // 
            this.bindingNavigatorMoveLastItem4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem4.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem4.Image")));
            this.bindingNavigatorMoveLastItem4.Name = "bindingNavigatorMoveLastItem4";
            this.bindingNavigatorMoveLastItem4.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem4.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem4.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator14
            // 
            this.bindingNavigatorSeparator14.Name = "bindingNavigatorSeparator14";
            this.bindingNavigatorSeparator14.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton4
            // 
            this.сохранитьToolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton4.Image")));
            this.сохранитьToolStripButton4.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton4.Name = "сохранитьToolStripButton4";
            this.сохранитьToolStripButton4.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton4.Text = "&Сохранить данные";
            this.сохранитьToolStripButton4.Click += new System.EventHandler(this.сохранитьToolStripButton4_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // dataGridView5
            // 
            this.dataGridView5.AutoGenerateColumns = false;
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодУчителяDataGridViewTextBoxColumn,
            this.фИОУчителяDataGridViewTextBoxColumn,
            this.домашнийАдресDataGridViewTextBoxColumn,
            this.телефонDataGridViewTextBoxColumn,
            this.предметDataGridViewTextBoxColumn});
            this.dataGridView5.DataSource = this.учителяШколыBindingSource;
            this.dataGridView5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView5.Location = new System.Drawing.Point(3, 3);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(681, 406);
            this.dataGridView5.TabIndex = 0;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.bindingNavigator6);
            this.tabPage8.Controls.Add(this.dataGridView6);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(687, 412);
            this.tabPage8.TabIndex = 1;
            this.tabPage8.Text = "Ученики";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator6
            // 
            this.bindingNavigator6.AddNewItem = this.bindingNavigatorAddNewItem5;
            this.bindingNavigator6.BindingSource = this.ученикиШколыBindingSource;
            this.bindingNavigator6.CountItem = this.bindingNavigatorCountItem5;
            this.bindingNavigator6.DeleteItem = this.bindingNavigatorDeleteItem5;
            this.bindingNavigator6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator6.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem5,
            this.bindingNavigatorMovePreviousItem5,
            this.bindingNavigatorSeparator15,
            this.bindingNavigatorPositionItem5,
            this.bindingNavigatorCountItem5,
            this.bindingNavigatorSeparator16,
            this.bindingNavigatorMoveNextItem5,
            this.bindingNavigatorMoveLastItem5,
            this.bindingNavigatorSeparator17,
            this.bindingNavigatorAddNewItem5,
            this.bindingNavigatorDeleteItem5,
            this.сохранитьToolStripButton5,
            this.toolStripSeparator5});
            this.bindingNavigator6.Location = new System.Drawing.Point(3, 384);
            this.bindingNavigator6.MoveFirstItem = this.bindingNavigatorMoveFirstItem5;
            this.bindingNavigator6.MoveLastItem = this.bindingNavigatorMoveLastItem5;
            this.bindingNavigator6.MoveNextItem = this.bindingNavigatorMoveNextItem5;
            this.bindingNavigator6.MovePreviousItem = this.bindingNavigatorMovePreviousItem5;
            this.bindingNavigator6.Name = "bindingNavigator6";
            this.bindingNavigator6.PositionItem = this.bindingNavigatorPositionItem5;
            this.bindingNavigator6.Size = new System.Drawing.Size(681, 25);
            this.bindingNavigator6.TabIndex = 1;
            this.bindingNavigator6.Text = "bindingNavigator6";
            // 
            // bindingNavigatorAddNewItem5
            // 
            this.bindingNavigatorAddNewItem5.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem5.Image")));
            this.bindingNavigatorAddNewItem5.Name = "bindingNavigatorAddNewItem5";
            this.bindingNavigatorAddNewItem5.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem5.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem5.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem5
            // 
            this.bindingNavigatorCountItem5.Name = "bindingNavigatorCountItem5";
            this.bindingNavigatorCountItem5.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem5.Text = "для {0}";
            this.bindingNavigatorCountItem5.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem5
            // 
            this.bindingNavigatorDeleteItem5.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem5.Image")));
            this.bindingNavigatorDeleteItem5.Name = "bindingNavigatorDeleteItem5";
            this.bindingNavigatorDeleteItem5.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem5.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem5.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem5
            // 
            this.bindingNavigatorMoveFirstItem5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem5.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem5.Image")));
            this.bindingNavigatorMoveFirstItem5.Name = "bindingNavigatorMoveFirstItem5";
            this.bindingNavigatorMoveFirstItem5.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem5.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem5.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem5
            // 
            this.bindingNavigatorMovePreviousItem5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem5.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem5.Image")));
            this.bindingNavigatorMovePreviousItem5.Name = "bindingNavigatorMovePreviousItem5";
            this.bindingNavigatorMovePreviousItem5.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem5.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem5.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator15
            // 
            this.bindingNavigatorSeparator15.Name = "bindingNavigatorSeparator15";
            this.bindingNavigatorSeparator15.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem5
            // 
            this.bindingNavigatorPositionItem5.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem5.AutoSize = false;
            this.bindingNavigatorPositionItem5.Name = "bindingNavigatorPositionItem5";
            this.bindingNavigatorPositionItem5.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem5.Text = "0";
            this.bindingNavigatorPositionItem5.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator16
            // 
            this.bindingNavigatorSeparator16.Name = "bindingNavigatorSeparator16";
            this.bindingNavigatorSeparator16.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem5
            // 
            this.bindingNavigatorMoveNextItem5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem5.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem5.Image")));
            this.bindingNavigatorMoveNextItem5.Name = "bindingNavigatorMoveNextItem5";
            this.bindingNavigatorMoveNextItem5.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem5.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem5.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem5
            // 
            this.bindingNavigatorMoveLastItem5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem5.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem5.Image")));
            this.bindingNavigatorMoveLastItem5.Name = "bindingNavigatorMoveLastItem5";
            this.bindingNavigatorMoveLastItem5.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem5.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem5.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator17
            // 
            this.bindingNavigatorSeparator17.Name = "bindingNavigatorSeparator17";
            this.bindingNavigatorSeparator17.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton5
            // 
            this.сохранитьToolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton5.Image")));
            this.сохранитьToolStripButton5.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton5.Name = "сохранитьToolStripButton5";
            this.сохранитьToolStripButton5.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton5.Text = "&Сохранить данные";
            this.сохранитьToolStripButton5.Click += new System.EventHandler(this.сохранитьToolStripButton5_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 25);
            // 
            // dataGridView6
            // 
            this.dataGridView6.AutoGenerateColumns = false;
            this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView6.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодУченикаDataGridViewTextBoxColumn,
            this.фИОУченикаDataGridViewTextBoxColumn,
            this.классDataGridViewTextBoxColumn,
            this.датаРожденияDataGridViewTextBoxColumn,
            this.домашнийАдресDataGridViewTextBoxColumn1,
            this.телефонDataGridViewTextBoxColumn1});
            this.dataGridView6.DataSource = this.ученикиШколыBindingSource;
            this.dataGridView6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView6.Location = new System.Drawing.Point(3, 3);
            this.dataGridView6.Name = "dataGridView6";
            this.dataGridView6.Size = new System.Drawing.Size(681, 406);
            this.dataGridView6.TabIndex = 0;
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.tabControl4);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(708, 451);
            this.tabPage9.TabIndex = 2;
            this.tabPage9.Text = "Продукты";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabControl4
            // 
            this.tabControl4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl4.Controls.Add(this.tabPage10);
            this.tabControl4.Controls.Add(this.tabPage11);
            this.tabControl4.Controls.Add(this.tabPage12);
            this.tabControl4.Location = new System.Drawing.Point(6, 6);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(696, 439);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.groupBox2);
            this.tabPage10.Controls.Add(this.groupBox1);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(688, 413);
            this.tabPage10.TabIndex = 0;
            this.tabPage10.Text = "Поставка продуктов";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.bindingNavigator11);
            this.groupBox2.Controls.Add(this.dataGridView11);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(9, 164);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(670, 243);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Продукты в накладных";
            // 
            // bindingNavigator11
            // 
            this.bindingNavigator11.AddNewItem = this.bindingNavigatorAddNewItem10;
            this.bindingNavigator11.BindingSource = this.кПоставкеТоваровBindingSource;
            this.bindingNavigator11.CountItem = this.bindingNavigatorCountItem10;
            this.bindingNavigator11.DeleteItem = this.bindingNavigatorDeleteItem10;
            this.bindingNavigator11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator11.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem10,
            this.bindingNavigatorMovePreviousItem10,
            this.bindingNavigatorSeparator30,
            this.bindingNavigatorPositionItem10,
            this.bindingNavigatorCountItem10,
            this.bindingNavigatorSeparator31,
            this.bindingNavigatorMoveNextItem10,
            this.bindingNavigatorMoveLastItem10,
            this.bindingNavigatorSeparator32,
            this.bindingNavigatorAddNewItem10,
            this.bindingNavigatorDeleteItem10,
            this.сохранитьToolStripButton10,
            this.toolStripSeparator10});
            this.bindingNavigator11.Location = new System.Drawing.Point(3, 215);
            this.bindingNavigator11.MoveFirstItem = this.bindingNavigatorMoveFirstItem10;
            this.bindingNavigator11.MoveLastItem = this.bindingNavigatorMoveLastItem10;
            this.bindingNavigator11.MoveNextItem = this.bindingNavigatorMoveNextItem10;
            this.bindingNavigator11.MovePreviousItem = this.bindingNavigatorMovePreviousItem10;
            this.bindingNavigator11.Name = "bindingNavigator11";
            this.bindingNavigator11.PositionItem = this.bindingNavigatorPositionItem10;
            this.bindingNavigator11.Size = new System.Drawing.Size(664, 25);
            this.bindingNavigator11.TabIndex = 3;
            this.bindingNavigator11.Text = "bindingNavigator11";
            // 
            // bindingNavigatorAddNewItem10
            // 
            this.bindingNavigatorAddNewItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem10.Image")));
            this.bindingNavigatorAddNewItem10.Name = "bindingNavigatorAddNewItem10";
            this.bindingNavigatorAddNewItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem10.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem10.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem10
            // 
            this.bindingNavigatorCountItem10.Name = "bindingNavigatorCountItem10";
            this.bindingNavigatorCountItem10.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem10.Text = "для {0}";
            this.bindingNavigatorCountItem10.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem10
            // 
            this.bindingNavigatorDeleteItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem10.Image")));
            this.bindingNavigatorDeleteItem10.Name = "bindingNavigatorDeleteItem10";
            this.bindingNavigatorDeleteItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem10.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem10.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem10
            // 
            this.bindingNavigatorMoveFirstItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem10.Image")));
            this.bindingNavigatorMoveFirstItem10.Name = "bindingNavigatorMoveFirstItem10";
            this.bindingNavigatorMoveFirstItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem10.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem10.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem10
            // 
            this.bindingNavigatorMovePreviousItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem10.Image")));
            this.bindingNavigatorMovePreviousItem10.Name = "bindingNavigatorMovePreviousItem10";
            this.bindingNavigatorMovePreviousItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem10.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem10.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator30
            // 
            this.bindingNavigatorSeparator30.Name = "bindingNavigatorSeparator30";
            this.bindingNavigatorSeparator30.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem10
            // 
            this.bindingNavigatorPositionItem10.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem10.AutoSize = false;
            this.bindingNavigatorPositionItem10.Name = "bindingNavigatorPositionItem10";
            this.bindingNavigatorPositionItem10.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem10.Text = "0";
            this.bindingNavigatorPositionItem10.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator31
            // 
            this.bindingNavigatorSeparator31.Name = "bindingNavigatorSeparator31";
            this.bindingNavigatorSeparator31.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem10
            // 
            this.bindingNavigatorMoveNextItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem10.Image")));
            this.bindingNavigatorMoveNextItem10.Name = "bindingNavigatorMoveNextItem10";
            this.bindingNavigatorMoveNextItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem10.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem10.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem10
            // 
            this.bindingNavigatorMoveLastItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem10.Image")));
            this.bindingNavigatorMoveLastItem10.Name = "bindingNavigatorMoveLastItem10";
            this.bindingNavigatorMoveLastItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem10.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem10.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator32
            // 
            this.bindingNavigatorSeparator32.Name = "bindingNavigatorSeparator32";
            this.bindingNavigatorSeparator32.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton10
            // 
            this.сохранитьToolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton10.Image")));
            this.сохранитьToolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton10.Name = "сохранитьToolStripButton10";
            this.сохранитьToolStripButton10.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton10.Text = "&Сохранить данные";
            this.сохранитьToolStripButton10.Click += new System.EventHandler(this.сохранитьToolStripButton10_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // dataGridView11
            // 
            this.dataGridView11.AutoGenerateColumns = false;
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.накладнойDataGridViewTextBoxColumn1,
            this.наименованиеПродуктаDataGridViewTextBoxColumn1,
            this.единицаИзмеренияDataGridViewTextBoxColumn1,
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn,
            this.количествоDataGridViewTextBoxColumn2});
            this.dataGridView11.DataSource = this.кПоставкеТоваровBindingSource;
            this.dataGridView11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView11.Location = new System.Drawing.Point(3, 16);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.Size = new System.Drawing.Size(664, 224);
            this.dataGridView11.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.dataGridView10);
            this.groupBox1.Controls.Add(this.bindingNavigator10);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(6, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(676, 157);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Сведения о накладных";
            // 
            // dataGridView10
            // 
            this.dataGridView10.AutoGenerateColumns = false;
            this.dataGridView10.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView10.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.накладнойDataGridViewTextBoxColumn,
            this.датаПоставкиDataGridViewTextBoxColumn,
            this.поставщикDataGridViewTextBoxColumn});
            this.dataGridView10.DataSource = this.поставкаТоваровBindingSource;
            this.dataGridView10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView10.Location = new System.Drawing.Point(3, 16);
            this.dataGridView10.Name = "dataGridView10";
            this.dataGridView10.Size = new System.Drawing.Size(670, 113);
            this.dataGridView10.TabIndex = 7;
            // 
            // bindingNavigator10
            // 
            this.bindingNavigator10.AddNewItem = this.bindingNavigatorAddNewItem9;
            this.bindingNavigator10.BindingSource = this.поставкаТоваровBindingSource;
            this.bindingNavigator10.CountItem = this.bindingNavigatorCountItem9;
            this.bindingNavigator10.DeleteItem = this.bindingNavigatorDeleteItem9;
            this.bindingNavigator10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator10.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem9,
            this.bindingNavigatorMovePreviousItem9,
            this.bindingNavigatorSeparator27,
            this.bindingNavigatorPositionItem9,
            this.bindingNavigatorCountItem9,
            this.bindingNavigatorSeparator28,
            this.bindingNavigatorMoveNextItem9,
            this.bindingNavigatorMoveLastItem9,
            this.bindingNavigatorSeparator29,
            this.bindingNavigatorAddNewItem9,
            this.bindingNavigatorDeleteItem9,
            this.сохранитьToolStripButton9,
            this.toolStripSeparator8});
            this.bindingNavigator10.Location = new System.Drawing.Point(3, 129);
            this.bindingNavigator10.MoveFirstItem = this.bindingNavigatorMoveFirstItem9;
            this.bindingNavigator10.MoveLastItem = this.bindingNavigatorMoveLastItem9;
            this.bindingNavigator10.MoveNextItem = this.bindingNavigatorMoveNextItem9;
            this.bindingNavigator10.MovePreviousItem = this.bindingNavigatorMovePreviousItem9;
            this.bindingNavigator10.Name = "bindingNavigator10";
            this.bindingNavigator10.PositionItem = this.bindingNavigatorPositionItem9;
            this.bindingNavigator10.Size = new System.Drawing.Size(670, 25);
            this.bindingNavigator10.TabIndex = 6;
            this.bindingNavigator10.Text = "bindingNavigator10";
            // 
            // bindingNavigatorAddNewItem9
            // 
            this.bindingNavigatorAddNewItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem9.Image")));
            this.bindingNavigatorAddNewItem9.Name = "bindingNavigatorAddNewItem9";
            this.bindingNavigatorAddNewItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem9.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem9.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem9
            // 
            this.bindingNavigatorCountItem9.Name = "bindingNavigatorCountItem9";
            this.bindingNavigatorCountItem9.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem9.Text = "для {0}";
            this.bindingNavigatorCountItem9.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem9
            // 
            this.bindingNavigatorDeleteItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem9.Image")));
            this.bindingNavigatorDeleteItem9.Name = "bindingNavigatorDeleteItem9";
            this.bindingNavigatorDeleteItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem9.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem9.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem9
            // 
            this.bindingNavigatorMoveFirstItem9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem9.Image")));
            this.bindingNavigatorMoveFirstItem9.Name = "bindingNavigatorMoveFirstItem9";
            this.bindingNavigatorMoveFirstItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem9.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem9.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem9
            // 
            this.bindingNavigatorMovePreviousItem9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem9.Image")));
            this.bindingNavigatorMovePreviousItem9.Name = "bindingNavigatorMovePreviousItem9";
            this.bindingNavigatorMovePreviousItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem9.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem9.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator27
            // 
            this.bindingNavigatorSeparator27.Name = "bindingNavigatorSeparator27";
            this.bindingNavigatorSeparator27.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem9
            // 
            this.bindingNavigatorPositionItem9.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem9.AutoSize = false;
            this.bindingNavigatorPositionItem9.Name = "bindingNavigatorPositionItem9";
            this.bindingNavigatorPositionItem9.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem9.Text = "0";
            this.bindingNavigatorPositionItem9.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator28
            // 
            this.bindingNavigatorSeparator28.Name = "bindingNavigatorSeparator28";
            this.bindingNavigatorSeparator28.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem9
            // 
            this.bindingNavigatorMoveNextItem9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem9.Image")));
            this.bindingNavigatorMoveNextItem9.Name = "bindingNavigatorMoveNextItem9";
            this.bindingNavigatorMoveNextItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem9.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem9.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem9
            // 
            this.bindingNavigatorMoveLastItem9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem9.Image")));
            this.bindingNavigatorMoveLastItem9.Name = "bindingNavigatorMoveLastItem9";
            this.bindingNavigatorMoveLastItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem9.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem9.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator29
            // 
            this.bindingNavigatorSeparator29.Name = "bindingNavigatorSeparator29";
            this.bindingNavigatorSeparator29.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton9
            // 
            this.сохранитьToolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton9.Image")));
            this.сохранитьToolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton9.Name = "сохранитьToolStripButton9";
            this.сохранитьToolStripButton9.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton9.Text = "&Сохранить данные";
            this.сохранитьToolStripButton9.Click += new System.EventHandler(this.сохранитьToolStripButton9_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.groupBox3);
            this.tabPage11.Controls.Add(this.groupBox4);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(688, 413);
            this.tabPage11.TabIndex = 1;
            this.tabPage11.Text = "Расход продуктов";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.dataGridView12);
            this.groupBox3.Controls.Add(this.bindingNavigator12);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(676, 157);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Сведения о расходных документах";
            // 
            // dataGridView12
            // 
            this.dataGridView12.AutoGenerateColumns = false;
            this.dataGridView12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView12.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.накладнойDataGridViewTextBoxColumn2,
            this.датаРасходаDataGridViewTextBoxColumn,
            this.типПитанияDataGridViewTextBoxColumn3,
            this.количествоУчащихсяDataGridViewTextBoxColumn});
            this.dataGridView12.DataSource = this.расходТоваровBindingSource;
            this.dataGridView12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView12.Location = new System.Drawing.Point(3, 16);
            this.dataGridView12.Name = "dataGridView12";
            this.dataGridView12.Size = new System.Drawing.Size(670, 113);
            this.dataGridView12.TabIndex = 7;
            // 
            // bindingNavigator12
            // 
            this.bindingNavigator12.AddNewItem = this.toolStripButton1;
            this.bindingNavigator12.BindingSource = this.расходТоваровBindingSource;
            this.bindingNavigator12.CountItem = this.toolStripLabel1;
            this.bindingNavigator12.DeleteItem = this.toolStripButton2;
            this.bindingNavigator12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator12.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator11,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator12,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripSeparator13,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton7,
            this.toolStripSeparator14});
            this.bindingNavigator12.Location = new System.Drawing.Point(3, 129);
            this.bindingNavigator12.MoveFirstItem = this.toolStripButton3;
            this.bindingNavigator12.MoveLastItem = this.toolStripButton6;
            this.bindingNavigator12.MoveNextItem = this.toolStripButton5;
            this.bindingNavigator12.MovePreviousItem = this.toolStripButton4;
            this.bindingNavigator12.Name = "bindingNavigator12";
            this.bindingNavigator12.PositionItem = this.toolStripTextBox1;
            this.bindingNavigator12.Size = new System.Drawing.Size(670, 25);
            this.bindingNavigator12.TabIndex = 6;
            this.bindingNavigator12.Text = "bindingNavigator12";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripButton1.Size = new System.Drawing.Size(119, 22);
            this.toolStripButton1.Text = "Добавить запись";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel1.Text = "для {0}";
            this.toolStripLabel1.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(111, 22);
            this.toolStripButton2.Text = "Удалить запись";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "Переместить в начало";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Переместить назад";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Положение";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "Переместить вперед";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton6.Text = "Переместить в конец";
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(129, 22);
            this.toolStripButton7.Text = "&Сохранить данные";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 25);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.dataGridView13);
            this.groupBox4.Controls.Add(this.bindingNavigator13);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox4.Location = new System.Drawing.Point(9, 163);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(670, 243);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Продукты в накладных";
            // 
            // dataGridView13
            // 
            this.dataGridView13.AutoGenerateColumns = false;
            this.dataGridView13.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView13.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.накладнойDataGridViewTextBoxColumn3,
            this.наименованиеПродуктаDataGridViewTextBoxColumn4,
            this.единицаИзмеренияDataGridViewTextBoxColumn3,
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2,
            this.количествоDataGridViewTextBoxColumn5});
            this.dataGridView13.DataSource = this.кРасходуBindingSource;
            this.dataGridView13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView13.Location = new System.Drawing.Point(3, 16);
            this.dataGridView13.Name = "dataGridView13";
            this.dataGridView13.Size = new System.Drawing.Size(664, 199);
            this.dataGridView13.TabIndex = 4;
            // 
            // bindingNavigator13
            // 
            this.bindingNavigator13.AddNewItem = this.toolStripButton8;
            this.bindingNavigator13.BindingSource = this.кРасходуBindingSource;
            this.bindingNavigator13.CountItem = this.toolStripLabel2;
            this.bindingNavigator13.DeleteItem = this.toolStripButton9;
            this.bindingNavigator13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator13.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton10,
            this.toolStripButton11,
            this.toolStripSeparator15,
            this.toolStripTextBox2,
            this.toolStripLabel2,
            this.toolStripSeparator16,
            this.toolStripButton12,
            this.toolStripButton13,
            this.toolStripSeparator17,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripButton14,
            this.toolStripSeparator18});
            this.bindingNavigator13.Location = new System.Drawing.Point(3, 215);
            this.bindingNavigator13.MoveFirstItem = this.toolStripButton10;
            this.bindingNavigator13.MoveLastItem = this.toolStripButton13;
            this.bindingNavigator13.MoveNextItem = this.toolStripButton12;
            this.bindingNavigator13.MovePreviousItem = this.toolStripButton11;
            this.bindingNavigator13.Name = "bindingNavigator13";
            this.bindingNavigator13.PositionItem = this.toolStripTextBox2;
            this.bindingNavigator13.Size = new System.Drawing.Size(664, 25);
            this.bindingNavigator13.TabIndex = 3;
            this.bindingNavigator13.Text = "bindingNavigator11";
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.RightToLeftAutoMirrorImage = true;
            this.toolStripButton8.Size = new System.Drawing.Size(119, 22);
            this.toolStripButton8.Text = "Добавить запись";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel2.Text = "для {0}";
            this.toolStripLabel2.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.RightToLeftAutoMirrorImage = true;
            this.toolStripButton9.Size = new System.Drawing.Size(111, 22);
            this.toolStripButton9.Text = "Удалить запись";
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.RightToLeftAutoMirrorImage = true;
            this.toolStripButton10.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton10.Text = "Переместить в начало";
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.RightToLeftAutoMirrorImage = true;
            this.toolStripButton11.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton11.Text = "Переместить назад";
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.AccessibleName = "Положение";
            this.toolStripTextBox2.AutoSize = false;
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox2.Text = "0";
            this.toolStripTextBox2.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.RightToLeftAutoMirrorImage = true;
            this.toolStripButton12.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton12.Text = "Переместить вперед";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.RightToLeftAutoMirrorImage = true;
            this.toolStripButton13.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton13.Text = "Переместить в конец";
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(129, 22);
            this.toolStripButton14.Text = "&Сохранить данные";
            this.toolStripButton14.Click += new System.EventHandler(this.toolStripButton14_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(6, 25);
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.bindingNavigator9);
            this.tabPage12.Controls.Add(this.dataGridView9);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(688, 413);
            this.tabPage12.TabIndex = 2;
            this.tabPage12.Text = "Затраты продуктов на порцию";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator9
            // 
            this.bindingNavigator9.AddNewItem = this.bindingNavigatorAddNewItem8;
            this.bindingNavigator9.BindingSource = this.затратыПродуктовBindingSource;
            this.bindingNavigator9.CountItem = this.bindingNavigatorCountItem8;
            this.bindingNavigator9.DeleteItem = this.bindingNavigatorDeleteItem8;
            this.bindingNavigator9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator9.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem8,
            this.bindingNavigatorMovePreviousItem8,
            this.bindingNavigatorSeparator24,
            this.bindingNavigatorPositionItem8,
            this.bindingNavigatorCountItem8,
            this.bindingNavigatorSeparator25,
            this.bindingNavigatorMoveNextItem8,
            this.bindingNavigatorMoveLastItem8,
            this.bindingNavigatorSeparator26,
            this.bindingNavigatorAddNewItem8,
            this.bindingNavigatorDeleteItem8,
            this.сохранитьToolStripButton8,
            this.toolStripSeparator9});
            this.bindingNavigator9.Location = new System.Drawing.Point(3, 385);
            this.bindingNavigator9.MoveFirstItem = this.bindingNavigatorMoveFirstItem8;
            this.bindingNavigator9.MoveLastItem = this.bindingNavigatorMoveLastItem8;
            this.bindingNavigator9.MoveNextItem = this.bindingNavigatorMoveNextItem8;
            this.bindingNavigator9.MovePreviousItem = this.bindingNavigatorMovePreviousItem8;
            this.bindingNavigator9.Name = "bindingNavigator9";
            this.bindingNavigator9.PositionItem = this.bindingNavigatorPositionItem8;
            this.bindingNavigator9.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator9.TabIndex = 1;
            this.bindingNavigator9.Text = "bindingNavigator9";
            // 
            // bindingNavigatorAddNewItem8
            // 
            this.bindingNavigatorAddNewItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem8.Image")));
            this.bindingNavigatorAddNewItem8.Name = "bindingNavigatorAddNewItem8";
            this.bindingNavigatorAddNewItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem8.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem8.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem8
            // 
            this.bindingNavigatorCountItem8.Name = "bindingNavigatorCountItem8";
            this.bindingNavigatorCountItem8.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem8.Text = "для {0}";
            this.bindingNavigatorCountItem8.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem8
            // 
            this.bindingNavigatorDeleteItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem8.Image")));
            this.bindingNavigatorDeleteItem8.Name = "bindingNavigatorDeleteItem8";
            this.bindingNavigatorDeleteItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem8.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem8.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem8
            // 
            this.bindingNavigatorMoveFirstItem8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem8.Image")));
            this.bindingNavigatorMoveFirstItem8.Name = "bindingNavigatorMoveFirstItem8";
            this.bindingNavigatorMoveFirstItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem8.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem8.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem8
            // 
            this.bindingNavigatorMovePreviousItem8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem8.Image")));
            this.bindingNavigatorMovePreviousItem8.Name = "bindingNavigatorMovePreviousItem8";
            this.bindingNavigatorMovePreviousItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem8.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem8.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator24
            // 
            this.bindingNavigatorSeparator24.Name = "bindingNavigatorSeparator24";
            this.bindingNavigatorSeparator24.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem8
            // 
            this.bindingNavigatorPositionItem8.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem8.AutoSize = false;
            this.bindingNavigatorPositionItem8.Name = "bindingNavigatorPositionItem8";
            this.bindingNavigatorPositionItem8.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem8.Text = "0";
            this.bindingNavigatorPositionItem8.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator25
            // 
            this.bindingNavigatorSeparator25.Name = "bindingNavigatorSeparator25";
            this.bindingNavigatorSeparator25.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem8
            // 
            this.bindingNavigatorMoveNextItem8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem8.Image")));
            this.bindingNavigatorMoveNextItem8.Name = "bindingNavigatorMoveNextItem8";
            this.bindingNavigatorMoveNextItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem8.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem8.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem8
            // 
            this.bindingNavigatorMoveLastItem8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem8.Image")));
            this.bindingNavigatorMoveLastItem8.Name = "bindingNavigatorMoveLastItem8";
            this.bindingNavigatorMoveLastItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem8.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem8.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator26
            // 
            this.bindingNavigatorSeparator26.Name = "bindingNavigatorSeparator26";
            this.bindingNavigatorSeparator26.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton8
            // 
            this.сохранитьToolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton8.Image")));
            this.сохранитьToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton8.Name = "сохранитьToolStripButton8";
            this.сохранитьToolStripButton8.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton8.Text = "&Сохранить данные";
            this.сохранитьToolStripButton8.Click += new System.EventHandler(this.сохранитьToolStripButton8_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // dataGridView9
            // 
            this.dataGridView9.AutoGenerateColumns = false;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаЗатратDataGridViewTextBoxColumn,
            this.продуктDataGridViewTextBoxColumn,
            this.количествоНаПорциюDataGridViewTextBoxColumn,
            this.единицаИзмеренияDataGridViewTextBoxColumn,
            this.ценаDataGridViewTextBoxColumn,
            this.типПитанияDataGridViewTextBoxColumn2});
            this.dataGridView9.DataSource = this.затратыПродуктовBindingSource;
            this.dataGridView9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView9.Location = new System.Drawing.Point(3, 3);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.Size = new System.Drawing.Size(682, 407);
            this.dataGridView9.TabIndex = 0;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.tabControl5);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(708, 451);
            this.tabPage13.TabIndex = 3;
            this.tabPage13.Text = "Питание";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            this.tabControl5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl5.Controls.Add(this.tabPage14);
            this.tabControl5.Controls.Add(this.tabPage15);
            this.tabControl5.Location = new System.Drawing.Point(6, 6);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(696, 439);
            this.tabControl5.TabIndex = 0;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.dataGridView7);
            this.tabPage14.Controls.Add(this.bindingNavigator7);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(688, 413);
            this.tabPage14.TabIndex = 0;
            this.tabPage14.Text = "Питание учителей";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // dataGridView7
            // 
            this.dataGridView7.AutoGenerateColumns = false;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.фИОУчителяDataGridViewTextBoxColumn1,
            this.датаDataGridViewTextBoxColumn,
            this.типПитанияDataGridViewTextBoxColumn,
            this.количествоDataGridViewTextBoxColumn,
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn});
            this.dataGridView7.DataSource = this.питаниеУчителейBindingSource;
            this.dataGridView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView7.Location = new System.Drawing.Point(3, 3);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(682, 382);
            this.dataGridView7.TabIndex = 2;
            // 
            // bindingNavigator7
            // 
            this.bindingNavigator7.AddNewItem = this.bindingNavigatorAddNewItem6;
            this.bindingNavigator7.BindingSource = this.питаниеУчителейBindingSource;
            this.bindingNavigator7.CountItem = this.bindingNavigatorCountItem6;
            this.bindingNavigator7.DeleteItem = this.bindingNavigatorDeleteItem6;
            this.bindingNavigator7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator7.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem6,
            this.bindingNavigatorMovePreviousItem6,
            this.bindingNavigatorSeparator18,
            this.bindingNavigatorPositionItem6,
            this.bindingNavigatorCountItem6,
            this.bindingNavigatorSeparator19,
            this.bindingNavigatorMoveNextItem6,
            this.bindingNavigatorMoveLastItem6,
            this.bindingNavigatorSeparator20,
            this.bindingNavigatorAddNewItem6,
            this.bindingNavigatorDeleteItem6,
            this.сохранитьToolStripButton6,
            this.toolStripSeparator6});
            this.bindingNavigator7.Location = new System.Drawing.Point(3, 385);
            this.bindingNavigator7.MoveFirstItem = this.bindingNavigatorMoveFirstItem6;
            this.bindingNavigator7.MoveLastItem = this.bindingNavigatorMoveLastItem6;
            this.bindingNavigator7.MoveNextItem = this.bindingNavigatorMoveNextItem6;
            this.bindingNavigator7.MovePreviousItem = this.bindingNavigatorMovePreviousItem6;
            this.bindingNavigator7.Name = "bindingNavigator7";
            this.bindingNavigator7.PositionItem = this.bindingNavigatorPositionItem6;
            this.bindingNavigator7.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator7.TabIndex = 1;
            this.bindingNavigator7.Text = "bindingNavigator7";
            // 
            // bindingNavigatorAddNewItem6
            // 
            this.bindingNavigatorAddNewItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem6.Image")));
            this.bindingNavigatorAddNewItem6.Name = "bindingNavigatorAddNewItem6";
            this.bindingNavigatorAddNewItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem6.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem6.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem6
            // 
            this.bindingNavigatorCountItem6.Name = "bindingNavigatorCountItem6";
            this.bindingNavigatorCountItem6.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem6.Text = "для {0}";
            this.bindingNavigatorCountItem6.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem6
            // 
            this.bindingNavigatorDeleteItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem6.Image")));
            this.bindingNavigatorDeleteItem6.Name = "bindingNavigatorDeleteItem6";
            this.bindingNavigatorDeleteItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem6.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem6.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem6
            // 
            this.bindingNavigatorMoveFirstItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem6.Image")));
            this.bindingNavigatorMoveFirstItem6.Name = "bindingNavigatorMoveFirstItem6";
            this.bindingNavigatorMoveFirstItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem6.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem6.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem6
            // 
            this.bindingNavigatorMovePreviousItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem6.Image")));
            this.bindingNavigatorMovePreviousItem6.Name = "bindingNavigatorMovePreviousItem6";
            this.bindingNavigatorMovePreviousItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem6.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem6.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator18
            // 
            this.bindingNavigatorSeparator18.Name = "bindingNavigatorSeparator18";
            this.bindingNavigatorSeparator18.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem6
            // 
            this.bindingNavigatorPositionItem6.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem6.AutoSize = false;
            this.bindingNavigatorPositionItem6.Name = "bindingNavigatorPositionItem6";
            this.bindingNavigatorPositionItem6.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem6.Text = "0";
            this.bindingNavigatorPositionItem6.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator19
            // 
            this.bindingNavigatorSeparator19.Name = "bindingNavigatorSeparator19";
            this.bindingNavigatorSeparator19.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem6
            // 
            this.bindingNavigatorMoveNextItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem6.Image")));
            this.bindingNavigatorMoveNextItem6.Name = "bindingNavigatorMoveNextItem6";
            this.bindingNavigatorMoveNextItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem6.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem6.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem6
            // 
            this.bindingNavigatorMoveLastItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem6.Image")));
            this.bindingNavigatorMoveLastItem6.Name = "bindingNavigatorMoveLastItem6";
            this.bindingNavigatorMoveLastItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem6.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem6.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator20
            // 
            this.bindingNavigatorSeparator20.Name = "bindingNavigatorSeparator20";
            this.bindingNavigatorSeparator20.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton6
            // 
            this.сохранитьToolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton6.Image")));
            this.сохранитьToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton6.Name = "сохранитьToolStripButton6";
            this.сохранитьToolStripButton6.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton6.Text = "&Сохранить данные";
            this.сохранитьToolStripButton6.Click += new System.EventHandler(this.сохранитьToolStripButton6_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.bindingNavigator8);
            this.tabPage15.Controls.Add(this.dataGridView8);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(688, 413);
            this.tabPage15.TabIndex = 1;
            this.tabPage15.Text = "Питание учащихся";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator8
            // 
            this.bindingNavigator8.AddNewItem = this.bindingNavigatorAddNewItem7;
            this.bindingNavigator8.BindingSource = this.питаниеУчениковBindingSource;
            this.bindingNavigator8.CountItem = this.bindingNavigatorCountItem7;
            this.bindingNavigator8.DeleteItem = this.bindingNavigatorDeleteItem7;
            this.bindingNavigator8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator8.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem7,
            this.bindingNavigatorMovePreviousItem7,
            this.bindingNavigatorSeparator21,
            this.bindingNavigatorPositionItem7,
            this.bindingNavigatorCountItem7,
            this.bindingNavigatorSeparator22,
            this.bindingNavigatorMoveNextItem7,
            this.bindingNavigatorMoveLastItem7,
            this.bindingNavigatorSeparator23,
            this.bindingNavigatorAddNewItem7,
            this.bindingNavigatorDeleteItem7,
            this.сохранитьToolStripButton7,
            this.toolStripSeparator7});
            this.bindingNavigator8.Location = new System.Drawing.Point(3, 385);
            this.bindingNavigator8.MoveFirstItem = this.bindingNavigatorMoveFirstItem7;
            this.bindingNavigator8.MoveLastItem = this.bindingNavigatorMoveLastItem7;
            this.bindingNavigator8.MoveNextItem = this.bindingNavigatorMoveNextItem7;
            this.bindingNavigator8.MovePreviousItem = this.bindingNavigatorMovePreviousItem7;
            this.bindingNavigator8.Name = "bindingNavigator8";
            this.bindingNavigator8.PositionItem = this.bindingNavigatorPositionItem7;
            this.bindingNavigator8.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator8.TabIndex = 1;
            this.bindingNavigator8.Text = "bindingNavigator8";
            // 
            // bindingNavigatorAddNewItem7
            // 
            this.bindingNavigatorAddNewItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem7.Image")));
            this.bindingNavigatorAddNewItem7.Name = "bindingNavigatorAddNewItem7";
            this.bindingNavigatorAddNewItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem7.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem7.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem7
            // 
            this.bindingNavigatorCountItem7.Name = "bindingNavigatorCountItem7";
            this.bindingNavigatorCountItem7.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem7.Text = "для {0}";
            this.bindingNavigatorCountItem7.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem7
            // 
            this.bindingNavigatorDeleteItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem7.Image")));
            this.bindingNavigatorDeleteItem7.Name = "bindingNavigatorDeleteItem7";
            this.bindingNavigatorDeleteItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem7.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem7.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem7
            // 
            this.bindingNavigatorMoveFirstItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem7.Image")));
            this.bindingNavigatorMoveFirstItem7.Name = "bindingNavigatorMoveFirstItem7";
            this.bindingNavigatorMoveFirstItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem7.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem7.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem7
            // 
            this.bindingNavigatorMovePreviousItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem7.Image")));
            this.bindingNavigatorMovePreviousItem7.Name = "bindingNavigatorMovePreviousItem7";
            this.bindingNavigatorMovePreviousItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem7.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem7.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator21
            // 
            this.bindingNavigatorSeparator21.Name = "bindingNavigatorSeparator21";
            this.bindingNavigatorSeparator21.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem7
            // 
            this.bindingNavigatorPositionItem7.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem7.AutoSize = false;
            this.bindingNavigatorPositionItem7.Name = "bindingNavigatorPositionItem7";
            this.bindingNavigatorPositionItem7.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem7.Text = "0";
            this.bindingNavigatorPositionItem7.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator22
            // 
            this.bindingNavigatorSeparator22.Name = "bindingNavigatorSeparator22";
            this.bindingNavigatorSeparator22.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem7
            // 
            this.bindingNavigatorMoveNextItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem7.Image")));
            this.bindingNavigatorMoveNextItem7.Name = "bindingNavigatorMoveNextItem7";
            this.bindingNavigatorMoveNextItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem7.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem7.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem7
            // 
            this.bindingNavigatorMoveLastItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem7.Image")));
            this.bindingNavigatorMoveLastItem7.Name = "bindingNavigatorMoveLastItem7";
            this.bindingNavigatorMoveLastItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem7.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem7.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator23
            // 
            this.bindingNavigatorSeparator23.Name = "bindingNavigatorSeparator23";
            this.bindingNavigatorSeparator23.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton7
            // 
            this.сохранитьToolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton7.Image")));
            this.сохранитьToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton7.Name = "сохранитьToolStripButton7";
            this.сохранитьToolStripButton7.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton7.Text = "&Сохранить данные";
            this.сохранитьToolStripButton7.Click += new System.EventHandler(this.сохранитьToolStripButton7_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // dataGridView8
            // 
            this.dataGridView8.AutoGenerateColumns = false;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.фИОУченикаDataGridViewTextBoxColumn1,
            this.датаDataGridViewTextBoxColumn1,
            this.типПитанияDataGridViewTextBoxColumn1,
            this.количествоDataGridViewTextBoxColumn1,
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn,
            this.классDataGridViewTextBoxColumn1});
            this.dataGridView8.DataSource = this.питаниеУчениковBindingSource;
            this.dataGridView8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView8.Location = new System.Drawing.Point(3, 3);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.Size = new System.Drawing.Size(682, 407);
            this.dataGridView8.TabIndex = 0;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.tabControl6);
            this.tabPage16.Location = new System.Drawing.Point(4, 22);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(708, 451);
            this.tabPage16.TabIndex = 4;
            this.tabPage16.Text = "Отчеты";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // tabControl6
            // 
            this.tabControl6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl6.Controls.Add(this.tabPage17);
            this.tabControl6.Controls.Add(this.tabPage18);
            this.tabControl6.Controls.Add(this.tabPage19);
            this.tabControl6.Controls.Add(this.tabPage20);
            this.tabControl6.Controls.Add(this.tabPage21);
            this.tabControl6.Controls.Add(this.tabPage22);
            this.tabControl6.Controls.Add(this.tabPage23);
            this.tabControl6.Controls.Add(this.tabPage24);
            this.tabControl6.Controls.Add(this.tabPage25);
            this.tabControl6.Controls.Add(this.tabPage26);
            this.tabControl6.Location = new System.Drawing.Point(6, 6);
            this.tabControl6.Multiline = true;
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(696, 439);
            this.tabControl6.TabIndex = 0;
            // 
            // tabPage17
            // 
            this.tabPage17.AutoScroll = true;
            this.tabPage17.Controls.Add(this.fillToolStrip1);
            this.tabPage17.Controls.Add(this.fillBy2ToolStrip);
            this.tabPage17.Controls.Add(this.fillBy1ToolStrip);
            this.tabPage17.Controls.Add(this.fillByToolStrip);
            this.tabPage17.Controls.Add(this.dataGridView17);
            this.tabPage17.Controls.Add(this.bindingNavigator18);
            this.tabPage17.Location = new System.Drawing.Point(4, 76);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(688, 359);
            this.tabPage17.TabIndex = 0;
            this.tabPage17.Text = "Ведомость о питании по классам";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // fillToolStrip1
            // 
            this.fillToolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fillToolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fillToolStripButton1});
            this.fillToolStrip1.Location = new System.Drawing.Point(3, 231);
            this.fillToolStrip1.Name = "fillToolStrip1";
            this.fillToolStrip1.Size = new System.Drawing.Size(682, 25);
            this.fillToolStrip1.TabIndex = 15;
            this.fillToolStrip1.Text = "fillToolStrip1";
            // 
            // fillToolStripButton1
            // 
            this.fillToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillToolStripButton1.Name = "fillToolStripButton1";
            this.fillToolStripButton1.Size = new System.Drawing.Size(71, 22);
            this.fillToolStripButton1.Text = "Все записи";
            this.fillToolStripButton1.Click += new System.EventHandler(this.fillToolStripButton1_Click);
            // 
            // fillBy2ToolStrip
            // 
            this.fillBy2ToolStrip.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fillBy2ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel3,
            this.param1ToolStripTextBox3,
            this.fillBy2ToolStripButton});
            this.fillBy2ToolStrip.Location = new System.Drawing.Point(3, 256);
            this.fillBy2ToolStrip.Name = "fillBy2ToolStrip";
            this.fillBy2ToolStrip.Size = new System.Drawing.Size(682, 25);
            this.fillBy2ToolStrip.TabIndex = 14;
            this.fillBy2ToolStrip.Text = "fillBy2ToolStrip";
            // 
            // param1ToolStripLabel3
            // 
            this.param1ToolStripLabel3.Name = "param1ToolStripLabel3";
            this.param1ToolStripLabel3.Size = new System.Drawing.Size(42, 22);
            this.param1ToolStripLabel3.Text = "Класс:";
            // 
            // param1ToolStripTextBox3
            // 
            this.param1ToolStripTextBox3.Name = "param1ToolStripTextBox3";
            this.param1ToolStripTextBox3.Size = new System.Drawing.Size(100, 25);
            // 
            // fillBy2ToolStripButton
            // 
            this.fillBy2ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy2ToolStripButton.Name = "fillBy2ToolStripButton";
            this.fillBy2ToolStripButton.Size = new System.Drawing.Size(52, 22);
            this.fillBy2ToolStripButton.Text = "Фильтр";
            this.fillBy2ToolStripButton.Click += new System.EventHandler(this.fillBy2ToolStripButton_Click);
            // 
            // fillBy1ToolStrip
            // 
            this.fillBy1ToolStrip.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fillBy1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel2,
            this.param1ToolStripTextBox2,
            this.fillBy1ToolStripButton});
            this.fillBy1ToolStrip.Location = new System.Drawing.Point(3, 281);
            this.fillBy1ToolStrip.Name = "fillBy1ToolStrip";
            this.fillBy1ToolStrip.Size = new System.Drawing.Size(682, 25);
            this.fillBy1ToolStrip.TabIndex = 13;
            this.fillBy1ToolStrip.Text = "fillBy1ToolStrip";
            // 
            // param1ToolStripLabel2
            // 
            this.param1ToolStripLabel2.Name = "param1ToolStripLabel2";
            this.param1ToolStripLabel2.Size = new System.Drawing.Size(29, 22);
            this.param1ToolStripLabel2.Text = "Год:";
            // 
            // param1ToolStripTextBox2
            // 
            this.param1ToolStripTextBox2.Name = "param1ToolStripTextBox2";
            this.param1ToolStripTextBox2.Size = new System.Drawing.Size(118, 25);
            // 
            // fillBy1ToolStripButton
            // 
            this.fillBy1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy1ToolStripButton.Name = "fillBy1ToolStripButton";
            this.fillBy1ToolStripButton.Size = new System.Drawing.Size(52, 22);
            this.fillBy1ToolStripButton.Text = "Фильтр";
            this.fillBy1ToolStripButton.Click += new System.EventHandler(this.fillBy1ToolStripButton_Click);
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel,
            this.param1ToolStripTextBox,
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(3, 306);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(682, 25);
            this.fillByToolStrip.TabIndex = 6;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // param1ToolStripLabel
            // 
            this.param1ToolStripLabel.Name = "param1ToolStripLabel";
            this.param1ToolStripLabel.Size = new System.Drawing.Size(46, 22);
            this.param1ToolStripLabel.Text = "Месяц:";
            // 
            // param1ToolStripTextBox
            // 
            this.param1ToolStripTextBox.Name = "param1ToolStripTextBox";
            this.param1ToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(52, 22);
            this.fillByToolStripButton.Text = "Фильтр";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click_1);
            // 
            // dataGridView17
            // 
            this.dataGridView17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView17.AutoGenerateColumns = false;
            this.dataGridView17.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView17.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Месяц,
            this.Год,
            this.названиеКлассаDataGridViewTextBoxColumn1,
            this.названиеТипаПитанияDataGridViewTextBoxColumn1,
            this.количествоDataGridViewTextBoxColumn6,
            this.ценаПитанияDataGridViewTextBoxColumn});
            this.dataGridView17.DataSource = this.view51BindingSource;
            this.dataGridView17.Location = new System.Drawing.Point(3, 3);
            this.dataGridView17.Name = "dataGridView17";
            this.dataGridView17.Size = new System.Drawing.Size(682, 216);
            this.dataGridView17.TabIndex = 1;
            // 
            // Месяц
            // 
            this.Месяц.DataPropertyName = "Месяц";
            this.Месяц.HeaderText = "Месяц";
            this.Месяц.Name = "Месяц";
            this.Месяц.ReadOnly = true;
            // 
            // Год
            // 
            this.Год.DataPropertyName = "Год";
            this.Год.HeaderText = "Год";
            this.Год.Name = "Год";
            this.Год.ReadOnly = true;
            // 
            // bindingNavigator18
            // 
            this.bindingNavigator18.AddNewItem = null;
            this.bindingNavigator18.BindingSource = this.view51BindingSource;
            this.bindingNavigator18.CountItem = this.bindingNavigatorCountItem15;
            this.bindingNavigator18.DeleteItem = null;
            this.bindingNavigator18.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator18.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem15,
            this.bindingNavigatorMovePreviousItem15,
            this.bindingNavigatorSeparator45,
            this.bindingNavigatorPositionItem15,
            this.bindingNavigatorCountItem15,
            this.bindingNavigatorSeparator46,
            this.bindingNavigatorMoveNextItem15,
            this.bindingNavigatorMoveLastItem15,
            this.bindingNavigatorSeparator47,
            this.toolStripButton15,
            this.toolStripButton23});
            this.bindingNavigator18.Location = new System.Drawing.Point(3, 331);
            this.bindingNavigator18.MoveFirstItem = this.bindingNavigatorMoveFirstItem15;
            this.bindingNavigator18.MoveLastItem = this.bindingNavigatorMoveLastItem15;
            this.bindingNavigator18.MoveNextItem = this.bindingNavigatorMoveNextItem15;
            this.bindingNavigator18.MovePreviousItem = this.bindingNavigatorMovePreviousItem15;
            this.bindingNavigator18.Name = "bindingNavigator18";
            this.bindingNavigator18.PositionItem = this.bindingNavigatorPositionItem15;
            this.bindingNavigator18.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator18.TabIndex = 0;
            this.bindingNavigator18.Text = "bindingNavigator18";
            // 
            // bindingNavigatorCountItem15
            // 
            this.bindingNavigatorCountItem15.Name = "bindingNavigatorCountItem15";
            this.bindingNavigatorCountItem15.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem15.Text = "для {0}";
            this.bindingNavigatorCountItem15.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem15
            // 
            this.bindingNavigatorMoveFirstItem15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem15.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem15.Image")));
            this.bindingNavigatorMoveFirstItem15.Name = "bindingNavigatorMoveFirstItem15";
            this.bindingNavigatorMoveFirstItem15.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem15.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem15.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem15
            // 
            this.bindingNavigatorMovePreviousItem15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem15.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem15.Image")));
            this.bindingNavigatorMovePreviousItem15.Name = "bindingNavigatorMovePreviousItem15";
            this.bindingNavigatorMovePreviousItem15.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem15.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem15.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator45
            // 
            this.bindingNavigatorSeparator45.Name = "bindingNavigatorSeparator45";
            this.bindingNavigatorSeparator45.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem15
            // 
            this.bindingNavigatorPositionItem15.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem15.AutoSize = false;
            this.bindingNavigatorPositionItem15.Name = "bindingNavigatorPositionItem15";
            this.bindingNavigatorPositionItem15.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem15.Text = "0";
            this.bindingNavigatorPositionItem15.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator46
            // 
            this.bindingNavigatorSeparator46.Name = "bindingNavigatorSeparator46";
            this.bindingNavigatorSeparator46.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem15
            // 
            this.bindingNavigatorMoveNextItem15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem15.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem15.Image")));
            this.bindingNavigatorMoveNextItem15.Name = "bindingNavigatorMoveNextItem15";
            this.bindingNavigatorMoveNextItem15.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem15.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem15.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem15
            // 
            this.bindingNavigatorMoveLastItem15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem15.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem15.Image")));
            this.bindingNavigatorMoveLastItem15.Name = "bindingNavigatorMoveLastItem15";
            this.bindingNavigatorMoveLastItem15.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem15.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem15.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator47
            // 
            this.bindingNavigatorSeparator47.Name = "bindingNavigatorSeparator47";
            this.bindingNavigatorSeparator47.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton15.Text = "Обновить данные";
            this.toolStripButton15.Click += new System.EventHandler(this.toolStripButton15_Click);
            // 
            // toolStripButton23
            // 
            this.toolStripButton23.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton23.Image")));
            this.toolStripButton23.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton23.Name = "toolStripButton23";
            this.toolStripButton23.Size = new System.Drawing.Size(110, 22);
            this.toolStripButton23.Text = "Экспорт в Excel";
            this.toolStripButton23.Click += new System.EventHandler(this.toolStripButton23_Click);
            // 
            // tabPage18
            // 
            this.tabPage18.AutoScroll = true;
            this.tabPage18.Controls.Add(this.dataGridView18);
            this.tabPage18.Controls.Add(this.bindingNavigator19);
            this.tabPage18.Location = new System.Drawing.Point(4, 76);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(688, 359);
            this.tabPage18.TabIndex = 1;
            this.tabPage18.Text = "Ведомость о питании педагогов";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // dataGridView18
            // 
            this.dataGridView18.AutoGenerateColumns = false;
            this.dataGridView18.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView18.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.фИОУчителяDataGridViewTextBoxColumn2,
            this.названиеТипаПитанияDataGridViewTextBoxColumn3,
            this.итогоКоличествоDataGridViewTextBoxColumn,
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn});
            this.dataGridView18.DataSource = this.view61BindingSource;
            this.dataGridView18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView18.Location = new System.Drawing.Point(3, 3);
            this.dataGridView18.Name = "dataGridView18";
            this.dataGridView18.Size = new System.Drawing.Size(682, 328);
            this.dataGridView18.TabIndex = 1;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Месяц";
            this.dataGridViewTextBoxColumn1.HeaderText = "Месяц";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Год";
            this.dataGridViewTextBoxColumn2.HeaderText = "Год";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // bindingNavigator19
            // 
            this.bindingNavigator19.AddNewItem = null;
            this.bindingNavigator19.BindingSource = this.view61BindingSource;
            this.bindingNavigator19.CountItem = this.bindingNavigatorCountItem16;
            this.bindingNavigator19.DeleteItem = null;
            this.bindingNavigator19.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator19.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem16,
            this.bindingNavigatorMovePreviousItem16,
            this.bindingNavigatorSeparator48,
            this.bindingNavigatorPositionItem16,
            this.bindingNavigatorCountItem16,
            this.bindingNavigatorSeparator49,
            this.bindingNavigatorMoveNextItem16,
            this.bindingNavigatorMoveLastItem16,
            this.bindingNavigatorSeparator50,
            this.toolStripButton16});
            this.bindingNavigator19.Location = new System.Drawing.Point(3, 331);
            this.bindingNavigator19.MoveFirstItem = this.bindingNavigatorMoveFirstItem16;
            this.bindingNavigator19.MoveLastItem = this.bindingNavigatorMoveLastItem16;
            this.bindingNavigator19.MoveNextItem = this.bindingNavigatorMoveNextItem16;
            this.bindingNavigator19.MovePreviousItem = this.bindingNavigatorMovePreviousItem16;
            this.bindingNavigator19.Name = "bindingNavigator19";
            this.bindingNavigator19.PositionItem = this.bindingNavigatorPositionItem16;
            this.bindingNavigator19.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator19.TabIndex = 0;
            this.bindingNavigator19.Text = "bindingNavigator19";
            // 
            // bindingNavigatorCountItem16
            // 
            this.bindingNavigatorCountItem16.Name = "bindingNavigatorCountItem16";
            this.bindingNavigatorCountItem16.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem16.Text = "для {0}";
            this.bindingNavigatorCountItem16.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem16
            // 
            this.bindingNavigatorMoveFirstItem16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem16.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem16.Image")));
            this.bindingNavigatorMoveFirstItem16.Name = "bindingNavigatorMoveFirstItem16";
            this.bindingNavigatorMoveFirstItem16.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem16.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem16.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem16
            // 
            this.bindingNavigatorMovePreviousItem16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem16.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem16.Image")));
            this.bindingNavigatorMovePreviousItem16.Name = "bindingNavigatorMovePreviousItem16";
            this.bindingNavigatorMovePreviousItem16.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem16.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem16.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator48
            // 
            this.bindingNavigatorSeparator48.Name = "bindingNavigatorSeparator48";
            this.bindingNavigatorSeparator48.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem16
            // 
            this.bindingNavigatorPositionItem16.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem16.AutoSize = false;
            this.bindingNavigatorPositionItem16.Name = "bindingNavigatorPositionItem16";
            this.bindingNavigatorPositionItem16.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem16.Text = "0";
            this.bindingNavigatorPositionItem16.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator49
            // 
            this.bindingNavigatorSeparator49.Name = "bindingNavigatorSeparator49";
            this.bindingNavigatorSeparator49.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem16
            // 
            this.bindingNavigatorMoveNextItem16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem16.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem16.Image")));
            this.bindingNavigatorMoveNextItem16.Name = "bindingNavigatorMoveNextItem16";
            this.bindingNavigatorMoveNextItem16.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem16.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem16.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem16
            // 
            this.bindingNavigatorMoveLastItem16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem16.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem16.Image")));
            this.bindingNavigatorMoveLastItem16.Name = "bindingNavigatorMoveLastItem16";
            this.bindingNavigatorMoveLastItem16.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem16.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem16.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator50
            // 
            this.bindingNavigatorSeparator50.Name = "bindingNavigatorSeparator50";
            this.bindingNavigatorSeparator50.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton16.Image")));
            this.toolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton16.Text = "Обновить данные";
            this.toolStripButton16.Click += new System.EventHandler(this.toolStripButton16_Click);
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.dataGridView19);
            this.tabPage19.Controls.Add(this.bindingNavigator20);
            this.tabPage19.Location = new System.Drawing.Point(4, 22);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(688, 413);
            this.tabPage19.TabIndex = 2;
            this.tabPage19.Text = "Табель посещаемости столовой учащимися за месяц";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // dataGridView19
            // 
            this.dataGridView19.AutoGenerateColumns = false;
            this.dataGridView19.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView19.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаDataGridViewTextBoxColumn2,
            this.названиеКлассаDataGridViewTextBoxColumn2,
            this.фИОУченикаDataGridViewTextBoxColumn2,
            this.названиеТипаПитанияDataGridViewTextBoxColumn4});
            this.dataGridView19.DataSource = this.viewBindingSource;
            this.dataGridView19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView19.Location = new System.Drawing.Point(3, 3);
            this.dataGridView19.Name = "dataGridView19";
            this.dataGridView19.Size = new System.Drawing.Size(682, 382);
            this.dataGridView19.TabIndex = 1;
            // 
            // bindingNavigator20
            // 
            this.bindingNavigator20.AddNewItem = null;
            this.bindingNavigator20.BindingSource = this.viewBindingSource;
            this.bindingNavigator20.CountItem = this.bindingNavigatorCountItem17;
            this.bindingNavigator20.DeleteItem = null;
            this.bindingNavigator20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator20.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem17,
            this.bindingNavigatorMovePreviousItem17,
            this.bindingNavigatorSeparator51,
            this.bindingNavigatorPositionItem17,
            this.bindingNavigatorCountItem17,
            this.bindingNavigatorSeparator52,
            this.bindingNavigatorMoveNextItem17,
            this.bindingNavigatorMoveLastItem17,
            this.bindingNavigatorSeparator53,
            this.toolStripButton20});
            this.bindingNavigator20.Location = new System.Drawing.Point(3, 385);
            this.bindingNavigator20.MoveFirstItem = this.bindingNavigatorMoveFirstItem17;
            this.bindingNavigator20.MoveLastItem = this.bindingNavigatorMoveLastItem17;
            this.bindingNavigator20.MoveNextItem = this.bindingNavigatorMoveNextItem17;
            this.bindingNavigator20.MovePreviousItem = this.bindingNavigatorMovePreviousItem17;
            this.bindingNavigator20.Name = "bindingNavigator20";
            this.bindingNavigator20.PositionItem = this.bindingNavigatorPositionItem17;
            this.bindingNavigator20.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator20.TabIndex = 0;
            this.bindingNavigator20.Text = "bindingNavigator20";
            // 
            // bindingNavigatorCountItem17
            // 
            this.bindingNavigatorCountItem17.Name = "bindingNavigatorCountItem17";
            this.bindingNavigatorCountItem17.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem17.Text = "для {0}";
            this.bindingNavigatorCountItem17.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem17
            // 
            this.bindingNavigatorMoveFirstItem17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem17.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem17.Image")));
            this.bindingNavigatorMoveFirstItem17.Name = "bindingNavigatorMoveFirstItem17";
            this.bindingNavigatorMoveFirstItem17.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem17.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem17.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem17
            // 
            this.bindingNavigatorMovePreviousItem17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem17.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem17.Image")));
            this.bindingNavigatorMovePreviousItem17.Name = "bindingNavigatorMovePreviousItem17";
            this.bindingNavigatorMovePreviousItem17.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem17.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem17.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator51
            // 
            this.bindingNavigatorSeparator51.Name = "bindingNavigatorSeparator51";
            this.bindingNavigatorSeparator51.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem17
            // 
            this.bindingNavigatorPositionItem17.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem17.AutoSize = false;
            this.bindingNavigatorPositionItem17.Name = "bindingNavigatorPositionItem17";
            this.bindingNavigatorPositionItem17.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem17.Text = "0";
            this.bindingNavigatorPositionItem17.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator52
            // 
            this.bindingNavigatorSeparator52.Name = "bindingNavigatorSeparator52";
            this.bindingNavigatorSeparator52.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem17
            // 
            this.bindingNavigatorMoveNextItem17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem17.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem17.Image")));
            this.bindingNavigatorMoveNextItem17.Name = "bindingNavigatorMoveNextItem17";
            this.bindingNavigatorMoveNextItem17.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem17.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem17.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem17
            // 
            this.bindingNavigatorMoveLastItem17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem17.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem17.Image")));
            this.bindingNavigatorMoveLastItem17.Name = "bindingNavigatorMoveLastItem17";
            this.bindingNavigatorMoveLastItem17.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem17.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem17.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator53
            // 
            this.bindingNavigatorSeparator53.Name = "bindingNavigatorSeparator53";
            this.bindingNavigatorSeparator53.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton20
            // 
            this.toolStripButton20.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton20.Image")));
            this.toolStripButton20.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton20.Name = "toolStripButton20";
            this.toolStripButton20.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton20.Text = "Обновить данные";
            this.toolStripButton20.Click += new System.EventHandler(this.toolStripButton20_Click);
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.dataGridView20);
            this.tabPage20.Controls.Add(this.bindingNavigator14);
            this.tabPage20.Location = new System.Drawing.Point(4, 40);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage20.Size = new System.Drawing.Size(688, 395);
            this.tabPage20.TabIndex = 3;
            this.tabPage20.Text = "Табель посещаемости столовой педагогом за месяц";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // dataGridView20
            // 
            this.dataGridView20.AutoGenerateColumns = false;
            this.dataGridView20.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView20.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаDataGridViewTextBoxColumn3,
            this.фИОУчителяDataGridViewTextBoxColumn3,
            this.названиеТипаПитанияDataGridViewTextBoxColumn5});
            this.dataGridView20.DataSource = this.view8BindingSource;
            this.dataGridView20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView20.Location = new System.Drawing.Point(3, 3);
            this.dataGridView20.Name = "dataGridView20";
            this.dataGridView20.Size = new System.Drawing.Size(682, 364);
            this.dataGridView20.TabIndex = 3;
            // 
            // bindingNavigator14
            // 
            this.bindingNavigator14.AddNewItem = null;
            this.bindingNavigator14.BindingSource = this.view8BindingSource;
            this.bindingNavigator14.CountItem = this.bindingNavigatorCountItem11;
            this.bindingNavigator14.DeleteItem = null;
            this.bindingNavigator14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator14.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem11,
            this.bindingNavigatorMovePreviousItem11,
            this.bindingNavigatorSeparator33,
            this.bindingNavigatorPositionItem11,
            this.bindingNavigatorCountItem11,
            this.bindingNavigatorSeparator34,
            this.bindingNavigatorMoveNextItem11,
            this.bindingNavigatorMoveLastItem11,
            this.bindingNavigatorSeparator35,
            this.toolStripButton21});
            this.bindingNavigator14.Location = new System.Drawing.Point(3, 367);
            this.bindingNavigator14.MoveFirstItem = this.bindingNavigatorMoveFirstItem11;
            this.bindingNavigator14.MoveLastItem = this.bindingNavigatorMoveLastItem11;
            this.bindingNavigator14.MoveNextItem = this.bindingNavigatorMoveNextItem11;
            this.bindingNavigator14.MovePreviousItem = this.bindingNavigatorMovePreviousItem11;
            this.bindingNavigator14.Name = "bindingNavigator14";
            this.bindingNavigator14.PositionItem = this.bindingNavigatorPositionItem11;
            this.bindingNavigator14.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator14.TabIndex = 1;
            this.bindingNavigator14.Text = "bindingNavigator14";
            // 
            // bindingNavigatorCountItem11
            // 
            this.bindingNavigatorCountItem11.Name = "bindingNavigatorCountItem11";
            this.bindingNavigatorCountItem11.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem11.Text = "для {0}";
            this.bindingNavigatorCountItem11.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem11
            // 
            this.bindingNavigatorMoveFirstItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem11.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem11.Image")));
            this.bindingNavigatorMoveFirstItem11.Name = "bindingNavigatorMoveFirstItem11";
            this.bindingNavigatorMoveFirstItem11.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem11.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem11.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem11
            // 
            this.bindingNavigatorMovePreviousItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem11.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem11.Image")));
            this.bindingNavigatorMovePreviousItem11.Name = "bindingNavigatorMovePreviousItem11";
            this.bindingNavigatorMovePreviousItem11.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem11.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem11.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator33
            // 
            this.bindingNavigatorSeparator33.Name = "bindingNavigatorSeparator33";
            this.bindingNavigatorSeparator33.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem11
            // 
            this.bindingNavigatorPositionItem11.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem11.AutoSize = false;
            this.bindingNavigatorPositionItem11.Name = "bindingNavigatorPositionItem11";
            this.bindingNavigatorPositionItem11.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem11.Text = "0";
            this.bindingNavigatorPositionItem11.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator34
            // 
            this.bindingNavigatorSeparator34.Name = "bindingNavigatorSeparator34";
            this.bindingNavigatorSeparator34.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem11
            // 
            this.bindingNavigatorMoveNextItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem11.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem11.Image")));
            this.bindingNavigatorMoveNextItem11.Name = "bindingNavigatorMoveNextItem11";
            this.bindingNavigatorMoveNextItem11.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem11.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem11.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem11
            // 
            this.bindingNavigatorMoveLastItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem11.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem11.Image")));
            this.bindingNavigatorMoveLastItem11.Name = "bindingNavigatorMoveLastItem11";
            this.bindingNavigatorMoveLastItem11.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem11.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem11.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator35
            // 
            this.bindingNavigatorSeparator35.Name = "bindingNavigatorSeparator35";
            this.bindingNavigatorSeparator35.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton21
            // 
            this.toolStripButton21.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton21.Image")));
            this.toolStripButton21.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton21.Name = "toolStripButton21";
            this.toolStripButton21.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton21.Text = "Обновить данные";
            this.toolStripButton21.Click += new System.EventHandler(this.toolStripButton21_Click);
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.dataGridView15);
            this.tabPage21.Controls.Add(this.bindingNavigator15);
            this.tabPage21.Location = new System.Drawing.Point(4, 40);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(688, 395);
            this.tabPage21.TabIndex = 4;
            this.tabPage21.Text = "Отчет по затратам на каждый тип питания за месяц";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // dataGridView15
            // 
            this.dataGridView15.AutoGenerateColumns = false;
            this.dataGridView15.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView15.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаЗатратDataGridViewTextBoxColumn1,
            this.наименованиеПродуктаDataGridViewTextBoxColumn2,
            this.количествоНаПорциюDataGridViewTextBoxColumn1,
            this.единицаИзмеренияDataGridViewTextBoxColumn2,
            this.ценаDataGridViewTextBoxColumn1,
            this.названиеТипаПитанияDataGridViewTextBoxColumn2});
            this.dataGridView15.DataSource = this.view2BindingSource;
            this.dataGridView15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView15.Location = new System.Drawing.Point(3, 3);
            this.dataGridView15.Name = "dataGridView15";
            this.dataGridView15.Size = new System.Drawing.Size(682, 364);
            this.dataGridView15.TabIndex = 2;
            // 
            // bindingNavigator15
            // 
            this.bindingNavigator15.AddNewItem = null;
            this.bindingNavigator15.BindingSource = this.view2BindingSource;
            this.bindingNavigator15.CountItem = this.bindingNavigatorCountItem12;
            this.bindingNavigator15.DeleteItem = null;
            this.bindingNavigator15.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator15.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem12,
            this.bindingNavigatorMovePreviousItem12,
            this.bindingNavigatorSeparator36,
            this.bindingNavigatorPositionItem12,
            this.bindingNavigatorCountItem12,
            this.bindingNavigatorSeparator37,
            this.bindingNavigatorMoveNextItem12,
            this.bindingNavigatorMoveLastItem12,
            this.bindingNavigatorSeparator38,
            this.toolStripButton17});
            this.bindingNavigator15.Location = new System.Drawing.Point(3, 367);
            this.bindingNavigator15.MoveFirstItem = this.bindingNavigatorMoveFirstItem12;
            this.bindingNavigator15.MoveLastItem = this.bindingNavigatorMoveLastItem12;
            this.bindingNavigator15.MoveNextItem = this.bindingNavigatorMoveNextItem12;
            this.bindingNavigator15.MovePreviousItem = this.bindingNavigatorMovePreviousItem12;
            this.bindingNavigator15.Name = "bindingNavigator15";
            this.bindingNavigator15.PositionItem = this.bindingNavigatorPositionItem12;
            this.bindingNavigator15.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator15.TabIndex = 1;
            this.bindingNavigator15.Text = "bindingNavigator15";
            // 
            // bindingNavigatorCountItem12
            // 
            this.bindingNavigatorCountItem12.Name = "bindingNavigatorCountItem12";
            this.bindingNavigatorCountItem12.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem12.Text = "для {0}";
            this.bindingNavigatorCountItem12.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem12
            // 
            this.bindingNavigatorMoveFirstItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem12.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem12.Image")));
            this.bindingNavigatorMoveFirstItem12.Name = "bindingNavigatorMoveFirstItem12";
            this.bindingNavigatorMoveFirstItem12.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem12.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem12.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem12
            // 
            this.bindingNavigatorMovePreviousItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem12.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem12.Image")));
            this.bindingNavigatorMovePreviousItem12.Name = "bindingNavigatorMovePreviousItem12";
            this.bindingNavigatorMovePreviousItem12.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem12.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem12.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator36
            // 
            this.bindingNavigatorSeparator36.Name = "bindingNavigatorSeparator36";
            this.bindingNavigatorSeparator36.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem12
            // 
            this.bindingNavigatorPositionItem12.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem12.AutoSize = false;
            this.bindingNavigatorPositionItem12.Name = "bindingNavigatorPositionItem12";
            this.bindingNavigatorPositionItem12.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem12.Text = "0";
            this.bindingNavigatorPositionItem12.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator37
            // 
            this.bindingNavigatorSeparator37.Name = "bindingNavigatorSeparator37";
            this.bindingNavigatorSeparator37.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem12
            // 
            this.bindingNavigatorMoveNextItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem12.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem12.Image")));
            this.bindingNavigatorMoveNextItem12.Name = "bindingNavigatorMoveNextItem12";
            this.bindingNavigatorMoveNextItem12.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem12.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem12.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem12
            // 
            this.bindingNavigatorMoveLastItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem12.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem12.Image")));
            this.bindingNavigatorMoveLastItem12.Name = "bindingNavigatorMoveLastItem12";
            this.bindingNavigatorMoveLastItem12.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem12.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem12.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator38
            // 
            this.bindingNavigatorSeparator38.Name = "bindingNavigatorSeparator38";
            this.bindingNavigatorSeparator38.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton17
            // 
            this.toolStripButton17.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton17.Image")));
            this.toolStripButton17.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton17.Text = "Обновить данные";
            this.toolStripButton17.Click += new System.EventHandler(this.toolStripButton17_Click);
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.dataGridView14);
            this.tabPage22.Controls.Add(this.bindingNavigator17);
            this.tabPage22.Location = new System.Drawing.Point(4, 58);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage22.Size = new System.Drawing.Size(688, 377);
            this.tabPage22.TabIndex = 5;
            this.tabPage22.Text = "Отчет о приходе продуктов за месяц";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // dataGridView14
            // 
            this.dataGridView14.AutoGenerateColumns = false;
            this.dataGridView14.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView14.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаПоставкиDataGridViewTextBoxColumn1,
            this.названиеПоставщикаDataGridViewTextBoxColumn1,
            this.наименованиеПродуктаDataGridViewTextBoxColumn5,
            this.единицаИзмеренияDataGridViewTextBoxColumn4,
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3,
            this.количествоDataGridViewTextBoxColumn3,
            this.итогоDataGridViewTextBoxColumn});
            this.dataGridView14.DataSource = this.view41BindingSource;
            this.dataGridView14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView14.Location = new System.Drawing.Point(3, 3);
            this.dataGridView14.Name = "dataGridView14";
            this.dataGridView14.Size = new System.Drawing.Size(682, 346);
            this.dataGridView14.TabIndex = 1;
            // 
            // bindingNavigator17
            // 
            this.bindingNavigator17.AddNewItem = null;
            this.bindingNavigator17.BindingSource = this.view41BindingSource;
            this.bindingNavigator17.CountItem = this.bindingNavigatorCountItem14;
            this.bindingNavigator17.DeleteItem = null;
            this.bindingNavigator17.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator17.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem14,
            this.bindingNavigatorMovePreviousItem14,
            this.bindingNavigatorSeparator42,
            this.bindingNavigatorPositionItem14,
            this.bindingNavigatorCountItem14,
            this.bindingNavigatorSeparator43,
            this.bindingNavigatorMoveNextItem14,
            this.bindingNavigatorMoveLastItem14,
            this.bindingNavigatorSeparator44,
            this.toolStripButton18});
            this.bindingNavigator17.Location = new System.Drawing.Point(3, 349);
            this.bindingNavigator17.MoveFirstItem = this.bindingNavigatorMoveFirstItem14;
            this.bindingNavigator17.MoveLastItem = this.bindingNavigatorMoveLastItem14;
            this.bindingNavigator17.MoveNextItem = this.bindingNavigatorMoveNextItem14;
            this.bindingNavigator17.MovePreviousItem = this.bindingNavigatorMovePreviousItem14;
            this.bindingNavigator17.Name = "bindingNavigator17";
            this.bindingNavigator17.PositionItem = this.bindingNavigatorPositionItem14;
            this.bindingNavigator17.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator17.TabIndex = 0;
            this.bindingNavigator17.Text = "bindingNavigator17";
            // 
            // bindingNavigatorCountItem14
            // 
            this.bindingNavigatorCountItem14.Name = "bindingNavigatorCountItem14";
            this.bindingNavigatorCountItem14.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem14.Text = "для {0}";
            this.bindingNavigatorCountItem14.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem14
            // 
            this.bindingNavigatorMoveFirstItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem14.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem14.Image")));
            this.bindingNavigatorMoveFirstItem14.Name = "bindingNavigatorMoveFirstItem14";
            this.bindingNavigatorMoveFirstItem14.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem14.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem14.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem14
            // 
            this.bindingNavigatorMovePreviousItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem14.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem14.Image")));
            this.bindingNavigatorMovePreviousItem14.Name = "bindingNavigatorMovePreviousItem14";
            this.bindingNavigatorMovePreviousItem14.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem14.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem14.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator42
            // 
            this.bindingNavigatorSeparator42.Name = "bindingNavigatorSeparator42";
            this.bindingNavigatorSeparator42.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem14
            // 
            this.bindingNavigatorPositionItem14.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem14.AutoSize = false;
            this.bindingNavigatorPositionItem14.Name = "bindingNavigatorPositionItem14";
            this.bindingNavigatorPositionItem14.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem14.Text = "0";
            this.bindingNavigatorPositionItem14.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator43
            // 
            this.bindingNavigatorSeparator43.Name = "bindingNavigatorSeparator43";
            this.bindingNavigatorSeparator43.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem14
            // 
            this.bindingNavigatorMoveNextItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem14.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem14.Image")));
            this.bindingNavigatorMoveNextItem14.Name = "bindingNavigatorMoveNextItem14";
            this.bindingNavigatorMoveNextItem14.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem14.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem14.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem14
            // 
            this.bindingNavigatorMoveLastItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem14.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem14.Image")));
            this.bindingNavigatorMoveLastItem14.Name = "bindingNavigatorMoveLastItem14";
            this.bindingNavigatorMoveLastItem14.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem14.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem14.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator44
            // 
            this.bindingNavigatorSeparator44.Name = "bindingNavigatorSeparator44";
            this.bindingNavigatorSeparator44.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton18
            // 
            this.toolStripButton18.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton18.Image")));
            this.toolStripButton18.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton18.Name = "toolStripButton18";
            this.toolStripButton18.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton18.Text = "Обновить данные";
            this.toolStripButton18.Click += new System.EventHandler(this.toolStripButton18_Click);
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.dataGridView16);
            this.tabPage23.Controls.Add(this.bindingNavigator16);
            this.tabPage23.Location = new System.Drawing.Point(4, 58);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(688, 377);
            this.tabPage23.TabIndex = 6;
            this.tabPage23.Text = "Отчет о расходе продуктов за месяц";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // dataGridView16
            // 
            this.dataGridView16.AutoGenerateColumns = false;
            this.dataGridView16.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView16.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаРасходаDataGridViewTextBoxColumn1,
            this.наименованиеПродуктаDataGridViewTextBoxColumn3,
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1,
            this.количествоDataGridViewTextBoxColumn4,
            this.общаяСуммаDataGridViewTextBoxColumn});
            this.dataGridView16.DataSource = this.view3BindingSource1;
            this.dataGridView16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView16.Location = new System.Drawing.Point(3, 3);
            this.dataGridView16.Name = "dataGridView16";
            this.dataGridView16.Size = new System.Drawing.Size(682, 346);
            this.dataGridView16.TabIndex = 1;
            // 
            // bindingNavigator16
            // 
            this.bindingNavigator16.AddNewItem = null;
            this.bindingNavigator16.BindingSource = this.view3BindingSource1;
            this.bindingNavigator16.CountItem = this.bindingNavigatorCountItem13;
            this.bindingNavigator16.DeleteItem = null;
            this.bindingNavigator16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator16.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem13,
            this.bindingNavigatorMovePreviousItem13,
            this.bindingNavigatorSeparator39,
            this.bindingNavigatorPositionItem13,
            this.bindingNavigatorCountItem13,
            this.bindingNavigatorSeparator40,
            this.bindingNavigatorMoveNextItem13,
            this.bindingNavigatorMoveLastItem13,
            this.bindingNavigatorSeparator41,
            this.toolStripButton19});
            this.bindingNavigator16.Location = new System.Drawing.Point(3, 349);
            this.bindingNavigator16.MoveFirstItem = this.bindingNavigatorMoveFirstItem13;
            this.bindingNavigator16.MoveLastItem = this.bindingNavigatorMoveLastItem13;
            this.bindingNavigator16.MoveNextItem = this.bindingNavigatorMoveNextItem13;
            this.bindingNavigator16.MovePreviousItem = this.bindingNavigatorMovePreviousItem13;
            this.bindingNavigator16.Name = "bindingNavigator16";
            this.bindingNavigator16.PositionItem = this.bindingNavigatorPositionItem13;
            this.bindingNavigator16.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator16.TabIndex = 0;
            this.bindingNavigator16.Text = "bindingNavigator16";
            // 
            // bindingNavigatorCountItem13
            // 
            this.bindingNavigatorCountItem13.Name = "bindingNavigatorCountItem13";
            this.bindingNavigatorCountItem13.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem13.Text = "для {0}";
            this.bindingNavigatorCountItem13.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem13
            // 
            this.bindingNavigatorMoveFirstItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem13.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem13.Image")));
            this.bindingNavigatorMoveFirstItem13.Name = "bindingNavigatorMoveFirstItem13";
            this.bindingNavigatorMoveFirstItem13.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem13.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem13.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem13
            // 
            this.bindingNavigatorMovePreviousItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem13.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem13.Image")));
            this.bindingNavigatorMovePreviousItem13.Name = "bindingNavigatorMovePreviousItem13";
            this.bindingNavigatorMovePreviousItem13.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem13.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem13.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator39
            // 
            this.bindingNavigatorSeparator39.Name = "bindingNavigatorSeparator39";
            this.bindingNavigatorSeparator39.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem13
            // 
            this.bindingNavigatorPositionItem13.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem13.AutoSize = false;
            this.bindingNavigatorPositionItem13.Name = "bindingNavigatorPositionItem13";
            this.bindingNavigatorPositionItem13.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem13.Text = "0";
            this.bindingNavigatorPositionItem13.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator40
            // 
            this.bindingNavigatorSeparator40.Name = "bindingNavigatorSeparator40";
            this.bindingNavigatorSeparator40.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem13
            // 
            this.bindingNavigatorMoveNextItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem13.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem13.Image")));
            this.bindingNavigatorMoveNextItem13.Name = "bindingNavigatorMoveNextItem13";
            this.bindingNavigatorMoveNextItem13.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem13.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem13.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem13
            // 
            this.bindingNavigatorMoveLastItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem13.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem13.Image")));
            this.bindingNavigatorMoveLastItem13.Name = "bindingNavigatorMoveLastItem13";
            this.bindingNavigatorMoveLastItem13.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem13.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem13.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator41
            // 
            this.bindingNavigatorSeparator41.Name = "bindingNavigatorSeparator41";
            this.bindingNavigatorSeparator41.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton19
            // 
            this.toolStripButton19.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton19.Image")));
            this.toolStripButton19.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton19.Name = "toolStripButton19";
            this.toolStripButton19.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton19.Text = "Обновить данные";
            this.toolStripButton19.Click += new System.EventHandler(this.toolStripButton19_Click);
            // 
            // tabPage24
            // 
            this.tabPage24.Controls.Add(this.bindingNavigator21);
            this.tabPage24.Controls.Add(this.dataGridView21);
            this.tabPage24.Location = new System.Drawing.Point(4, 58);
            this.tabPage24.Name = "tabPage24";
            this.tabPage24.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage24.Size = new System.Drawing.Size(688, 377);
            this.tabPage24.TabIndex = 7;
            this.tabPage24.Text = "Стоимость порции";
            this.tabPage24.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator21
            // 
            this.bindingNavigator21.AddNewItem = null;
            this.bindingNavigator21.BindingSource = this.view10BindingSource;
            this.bindingNavigator21.CountItem = this.bindingNavigatorCountItem18;
            this.bindingNavigator21.DeleteItem = null;
            this.bindingNavigator21.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator21.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem18,
            this.bindingNavigatorMovePreviousItem18,
            this.bindingNavigatorSeparator54,
            this.bindingNavigatorPositionItem18,
            this.bindingNavigatorCountItem18,
            this.bindingNavigatorSeparator55,
            this.bindingNavigatorMoveNextItem18,
            this.bindingNavigatorMoveLastItem18,
            this.bindingNavigatorSeparator56,
            this.toolStripButton22});
            this.bindingNavigator21.Location = new System.Drawing.Point(3, 349);
            this.bindingNavigator21.MoveFirstItem = this.bindingNavigatorMoveFirstItem18;
            this.bindingNavigator21.MoveLastItem = this.bindingNavigatorMoveLastItem18;
            this.bindingNavigator21.MoveNextItem = this.bindingNavigatorMoveNextItem18;
            this.bindingNavigator21.MovePreviousItem = this.bindingNavigatorMovePreviousItem18;
            this.bindingNavigator21.Name = "bindingNavigator21";
            this.bindingNavigator21.PositionItem = this.bindingNavigatorPositionItem18;
            this.bindingNavigator21.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator21.TabIndex = 1;
            this.bindingNavigator21.Text = "bindingNavigator21";
            // 
            // bindingNavigatorCountItem18
            // 
            this.bindingNavigatorCountItem18.Name = "bindingNavigatorCountItem18";
            this.bindingNavigatorCountItem18.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem18.Text = "для {0}";
            this.bindingNavigatorCountItem18.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem18
            // 
            this.bindingNavigatorMoveFirstItem18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem18.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem18.Image")));
            this.bindingNavigatorMoveFirstItem18.Name = "bindingNavigatorMoveFirstItem18";
            this.bindingNavigatorMoveFirstItem18.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem18.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem18.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem18
            // 
            this.bindingNavigatorMovePreviousItem18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem18.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem18.Image")));
            this.bindingNavigatorMovePreviousItem18.Name = "bindingNavigatorMovePreviousItem18";
            this.bindingNavigatorMovePreviousItem18.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem18.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem18.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator54
            // 
            this.bindingNavigatorSeparator54.Name = "bindingNavigatorSeparator54";
            this.bindingNavigatorSeparator54.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem18
            // 
            this.bindingNavigatorPositionItem18.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem18.AutoSize = false;
            this.bindingNavigatorPositionItem18.Name = "bindingNavigatorPositionItem18";
            this.bindingNavigatorPositionItem18.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem18.Text = "0";
            this.bindingNavigatorPositionItem18.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator55
            // 
            this.bindingNavigatorSeparator55.Name = "bindingNavigatorSeparator55";
            this.bindingNavigatorSeparator55.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem18
            // 
            this.bindingNavigatorMoveNextItem18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem18.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem18.Image")));
            this.bindingNavigatorMoveNextItem18.Name = "bindingNavigatorMoveNextItem18";
            this.bindingNavigatorMoveNextItem18.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem18.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem18.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem18
            // 
            this.bindingNavigatorMoveLastItem18.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem18.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem18.Image")));
            this.bindingNavigatorMoveLastItem18.Name = "bindingNavigatorMoveLastItem18";
            this.bindingNavigatorMoveLastItem18.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem18.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem18.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator56
            // 
            this.bindingNavigatorSeparator56.Name = "bindingNavigatorSeparator56";
            this.bindingNavigatorSeparator56.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton22
            // 
            this.toolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton22.Image")));
            this.toolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton22.Name = "toolStripButton22";
            this.toolStripButton22.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton22.Text = "Обновить данные";
            this.toolStripButton22.Click += new System.EventHandler(this.toolStripButton22_Click);
            // 
            // dataGridView21
            // 
            this.dataGridView21.AutoGenerateColumns = false;
            this.dataGridView21.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView21.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаЗатратDataGridViewTextBoxColumn2,
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn,
            this.названиеТипаПитанияDataGridViewTextBoxColumn6});
            this.dataGridView21.DataSource = this.view10BindingSource;
            this.dataGridView21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView21.Location = new System.Drawing.Point(3, 3);
            this.dataGridView21.Name = "dataGridView21";
            this.dataGridView21.Size = new System.Drawing.Size(682, 371);
            this.dataGridView21.TabIndex = 0;
            // 
            // tabPage25
            // 
            this.tabPage25.Controls.Add(this.bindingNavigator22);
            this.tabPage25.Controls.Add(this.dataGridView22);
            this.tabPage25.Location = new System.Drawing.Point(4, 76);
            this.tabPage25.Name = "tabPage25";
            this.tabPage25.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage25.Size = new System.Drawing.Size(688, 359);
            this.tabPage25.TabIndex = 8;
            this.tabPage25.Text = "Ведомость о питании учеников детализированная";
            this.tabPage25.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator22
            // 
            this.bindingNavigator22.AddNewItem = null;
            this.bindingNavigator22.BindingSource = this.view11BindingSource;
            this.bindingNavigator22.CountItem = this.bindingNavigatorCountItem19;
            this.bindingNavigator22.DeleteItem = null;
            this.bindingNavigator22.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator22.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem19,
            this.bindingNavigatorMovePreviousItem19,
            this.bindingNavigatorSeparator57,
            this.bindingNavigatorPositionItem19,
            this.bindingNavigatorCountItem19,
            this.bindingNavigatorSeparator58,
            this.bindingNavigatorMoveNextItem19,
            this.bindingNavigatorMoveLastItem19,
            this.bindingNavigatorSeparator59,
            this.toolStripButton24});
            this.bindingNavigator22.Location = new System.Drawing.Point(3, 331);
            this.bindingNavigator22.MoveFirstItem = this.bindingNavigatorMoveFirstItem19;
            this.bindingNavigator22.MoveLastItem = this.bindingNavigatorMoveLastItem19;
            this.bindingNavigator22.MoveNextItem = this.bindingNavigatorMoveNextItem19;
            this.bindingNavigator22.MovePreviousItem = this.bindingNavigatorMovePreviousItem19;
            this.bindingNavigator22.Name = "bindingNavigator22";
            this.bindingNavigator22.PositionItem = this.bindingNavigatorPositionItem19;
            this.bindingNavigator22.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator22.TabIndex = 1;
            this.bindingNavigator22.Text = "bindingNavigator22";
            // 
            // bindingNavigatorCountItem19
            // 
            this.bindingNavigatorCountItem19.Name = "bindingNavigatorCountItem19";
            this.bindingNavigatorCountItem19.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem19.Text = "для {0}";
            this.bindingNavigatorCountItem19.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem19
            // 
            this.bindingNavigatorMoveFirstItem19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem19.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem19.Image")));
            this.bindingNavigatorMoveFirstItem19.Name = "bindingNavigatorMoveFirstItem19";
            this.bindingNavigatorMoveFirstItem19.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem19.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem19.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem19
            // 
            this.bindingNavigatorMovePreviousItem19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem19.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem19.Image")));
            this.bindingNavigatorMovePreviousItem19.Name = "bindingNavigatorMovePreviousItem19";
            this.bindingNavigatorMovePreviousItem19.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem19.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem19.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator57
            // 
            this.bindingNavigatorSeparator57.Name = "bindingNavigatorSeparator57";
            this.bindingNavigatorSeparator57.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem19
            // 
            this.bindingNavigatorPositionItem19.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem19.AutoSize = false;
            this.bindingNavigatorPositionItem19.Name = "bindingNavigatorPositionItem19";
            this.bindingNavigatorPositionItem19.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem19.Text = "0";
            this.bindingNavigatorPositionItem19.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator58
            // 
            this.bindingNavigatorSeparator58.Name = "bindingNavigatorSeparator58";
            this.bindingNavigatorSeparator58.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem19
            // 
            this.bindingNavigatorMoveNextItem19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem19.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem19.Image")));
            this.bindingNavigatorMoveNextItem19.Name = "bindingNavigatorMoveNextItem19";
            this.bindingNavigatorMoveNextItem19.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem19.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem19.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem19
            // 
            this.bindingNavigatorMoveLastItem19.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem19.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem19.Image")));
            this.bindingNavigatorMoveLastItem19.Name = "bindingNavigatorMoveLastItem19";
            this.bindingNavigatorMoveLastItem19.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem19.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem19.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator59
            // 
            this.bindingNavigatorSeparator59.Name = "bindingNavigatorSeparator59";
            this.bindingNavigatorSeparator59.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton24
            // 
            this.toolStripButton24.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton24.Image")));
            this.toolStripButton24.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton24.Name = "toolStripButton24";
            this.toolStripButton24.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton24.Text = "Обновить данные";
            this.toolStripButton24.Click += new System.EventHandler(this.toolStripButton24_Click);
            // 
            // dataGridView22
            // 
            this.dataGridView22.AutoGenerateColumns = false;
            this.dataGridView22.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView22.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаDataGridViewTextBoxColumn4,
            this.фИОУченикаDataGridViewTextBoxColumn3,
            this.названиеКлассаDataGridViewTextBoxColumn3,
            this.названиеТипаПитанияDataGridViewTextBoxColumn7,
            this.количествоDataGridViewTextBoxColumn7,
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn1,
            this.итогоDataGridViewTextBoxColumn1});
            this.dataGridView22.DataSource = this.view11BindingSource;
            this.dataGridView22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView22.Location = new System.Drawing.Point(3, 3);
            this.dataGridView22.Name = "dataGridView22";
            this.dataGridView22.Size = new System.Drawing.Size(682, 353);
            this.dataGridView22.TabIndex = 0;
            // 
            // Close_Pr
            // 
            this.Close_Pr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Close_Pr.Location = new System.Drawing.Point(12, 461);
            this.Close_Pr.Name = "Close_Pr";
            this.Close_Pr.Size = new System.Drawing.Size(164, 23);
            this.Close_Pr.TabIndex = 3;
            this.Close_Pr.Text = "Закрыть приложение";
            this.Close_Pr.UseVisualStyleBackColor = true;
            this.Close_Pr.Click += new System.EventHandler(this.Close_Pr_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Школьное_питание.Properties.Resources.abiword_3424;
            this.pictureBox2.Location = new System.Drawing.Point(44, 293);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 98);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "№ накладной";
            this.dataGridViewTextBoxColumn3.HeaderText = "№ накладной";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn4.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle79.Format = "C2";
            dataGridViewCellStyle79.NullValue = null;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle79;
            this.dataGridViewTextBoxColumn5.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn6.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Наименование продукта";
            this.dataGridViewTextBoxColumn7.HeaderText = "Наименование продукта";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Код класса";
            this.dataGridViewTextBoxColumn8.HeaderText = "Код класса";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Название класса";
            this.dataGridViewTextBoxColumn9.HeaderText = "Название класса";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Код учителя";
            this.dataGridViewTextBoxColumn10.HeaderText = "Код учителя";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn11.DataPropertyName = "ФИО учителя";
            this.dataGridViewTextBoxColumn11.HeaderText = "ФИО учителя";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Домашний адрес";
            this.dataGridViewTextBoxColumn12.HeaderText = "Домашний адрес";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Телефон";
            this.dataGridViewTextBoxColumn13.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Предмет";
            this.dataGridViewTextBoxColumn14.HeaderText = "Предмет";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Код ученика";
            this.dataGridViewTextBoxColumn15.HeaderText = "Код ученика";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn16.DataPropertyName = "ФИО ученика";
            this.dataGridViewTextBoxColumn16.HeaderText = "ФИО ученика";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewComboBoxColumn1
            // 
            this.dataGridViewComboBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn1.DataPropertyName = "Класс";
            this.dataGridViewComboBoxColumn1.DataSource = this.справочникКлассовBindingSource;
            this.dataGridViewComboBoxColumn1.DisplayMember = "Название класса";
            this.dataGridViewComboBoxColumn1.HeaderText = "Класс";
            this.dataGridViewComboBoxColumn1.Name = "dataGridViewComboBoxColumn1";
            this.dataGridViewComboBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn1.ValueMember = "Код класса";
            // 
            // dataGridViewCalendarColumn1
            // 
            this.dataGridViewCalendarColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewCalendarColumn1.DataPropertyName = "Дата рождения";
            dataGridViewCellStyle80.Format = "D";
            this.dataGridViewCalendarColumn1.DefaultCellStyle = dataGridViewCellStyle80;
            this.dataGridViewCalendarColumn1.HeaderText = "Дата рождения";
            this.dataGridViewCalendarColumn1.Name = "dataGridViewCalendarColumn1";
            this.dataGridViewCalendarColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCalendarColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Домашний адрес";
            this.dataGridViewTextBoxColumn17.HeaderText = "Домашний адрес";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Телефон";
            this.dataGridViewTextBoxColumn18.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn19.DataPropertyName = "№ накладной";
            this.dataGridViewTextBoxColumn19.HeaderText = "№ накладной";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewComboBoxColumn2
            // 
            this.dataGridViewComboBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn2.DataPropertyName = "Наименование продукта";
            this.dataGridViewComboBoxColumn2.DataSource = this.справочникПродуктовBindingSource;
            this.dataGridViewComboBoxColumn2.DisplayMember = "Наименование продукта";
            this.dataGridViewComboBoxColumn2.HeaderText = "Наименование продукта";
            this.dataGridViewComboBoxColumn2.Name = "dataGridViewComboBoxColumn2";
            this.dataGridViewComboBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn2.ValueMember = "Код продукта";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn20.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle81.Format = "C2";
            dataGridViewCellStyle81.NullValue = null;
            this.dataGridViewTextBoxColumn21.DefaultCellStyle = dataGridViewCellStyle81;
            this.dataGridViewTextBoxColumn21.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn22.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn23.DataPropertyName = "№ накладной";
            this.dataGridViewTextBoxColumn23.HeaderText = "№ накладной";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewCalendarColumn2
            // 
            this.dataGridViewCalendarColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewCalendarColumn2.DataPropertyName = "Дата поставки";
            dataGridViewCellStyle82.Format = "D";
            this.dataGridViewCalendarColumn2.DefaultCellStyle = dataGridViewCellStyle82;
            this.dataGridViewCalendarColumn2.HeaderText = "Дата поставки";
            this.dataGridViewCalendarColumn2.Name = "dataGridViewCalendarColumn2";
            this.dataGridViewCalendarColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCalendarColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewComboBoxColumn3
            // 
            this.dataGridViewComboBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn3.DataPropertyName = "Поставщик";
            this.dataGridViewComboBoxColumn3.DataSource = this.справочникПоставщиковBindingSource;
            this.dataGridViewComboBoxColumn3.DisplayMember = "Название поставщика";
            this.dataGridViewComboBoxColumn3.HeaderText = "Поставщик";
            this.dataGridViewComboBoxColumn3.Name = "dataGridViewComboBoxColumn3";
            this.dataGridViewComboBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn3.ValueMember = "Код поставщика";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn24.DataPropertyName = "№ накладной";
            this.dataGridViewTextBoxColumn24.HeaderText = "№ накладной";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewCalendarColumn3
            // 
            this.dataGridViewCalendarColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewCalendarColumn3.DataPropertyName = "Дата расхода";
            dataGridViewCellStyle83.Format = "D";
            this.dataGridViewCalendarColumn3.DefaultCellStyle = dataGridViewCellStyle83;
            this.dataGridViewCalendarColumn3.HeaderText = "Дата расхода";
            this.dataGridViewCalendarColumn3.Name = "dataGridViewCalendarColumn3";
            this.dataGridViewCalendarColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCalendarColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewComboBoxColumn4
            // 
            this.dataGridViewComboBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn4.DataPropertyName = "Тип питания";
            this.dataGridViewComboBoxColumn4.DataSource = this.справочникТиповПитанияBindingSource;
            this.dataGridViewComboBoxColumn4.DisplayMember = "Название типа питания";
            this.dataGridViewComboBoxColumn4.HeaderText = "Тип питания";
            this.dataGridViewComboBoxColumn4.Name = "dataGridViewComboBoxColumn4";
            this.dataGridViewComboBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn4.ValueMember = "Код типа питания";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Количество учащихся";
            this.dataGridViewTextBoxColumn25.HeaderText = "Количество учащихся";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn26.DataPropertyName = "№ накладной";
            this.dataGridViewTextBoxColumn26.HeaderText = "№ накладной";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // dataGridViewComboBoxColumn5
            // 
            this.dataGridViewComboBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn5.DataPropertyName = "Наименование продукта";
            this.dataGridViewComboBoxColumn5.DataSource = this.справочникПродуктовBindingSource;
            this.dataGridViewComboBoxColumn5.DisplayMember = "Наименование продукта";
            this.dataGridViewComboBoxColumn5.HeaderText = "Наименование продукта";
            this.dataGridViewComboBoxColumn5.Name = "dataGridViewComboBoxColumn5";
            this.dataGridViewComboBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn5.ValueMember = "Код продукта";
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn27.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn28.DataPropertyName = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn28.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn29.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewComboBoxColumn6
            // 
            this.dataGridViewComboBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn6.DataPropertyName = "ФИО учителя";
            this.dataGridViewComboBoxColumn6.DataSource = this.учителяШколыBindingSource;
            this.dataGridViewComboBoxColumn6.DisplayMember = "ФИО учителя";
            this.dataGridViewComboBoxColumn6.HeaderText = "ФИО учителя";
            this.dataGridViewComboBoxColumn6.Name = "dataGridViewComboBoxColumn6";
            this.dataGridViewComboBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn6.ValueMember = "Код учителя";
            // 
            // dataGridViewCalendarColumn4
            // 
            this.dataGridViewCalendarColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewCalendarColumn4.DataPropertyName = "Дата";
            dataGridViewCellStyle84.Format = "D";
            this.dataGridViewCalendarColumn4.DefaultCellStyle = dataGridViewCellStyle84;
            this.dataGridViewCalendarColumn4.HeaderText = "Дата";
            this.dataGridViewCalendarColumn4.Name = "dataGridViewCalendarColumn4";
            this.dataGridViewCalendarColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCalendarColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewComboBoxColumn7
            // 
            this.dataGridViewComboBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn7.DataPropertyName = "Тип питания";
            this.dataGridViewComboBoxColumn7.DataSource = this.справочникТиповПитанияBindingSource;
            this.dataGridViewComboBoxColumn7.DisplayMember = "Название типа питания";
            this.dataGridViewComboBoxColumn7.HeaderText = "Тип питания";
            this.dataGridViewComboBoxColumn7.Name = "dataGridViewComboBoxColumn7";
            this.dataGridViewComboBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn7.ValueMember = "Код типа питания";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn30.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Стоимость единицы типа питания";
            dataGridViewCellStyle85.Format = "C2";
            dataGridViewCellStyle85.NullValue = null;
            this.dataGridViewTextBoxColumn31.DefaultCellStyle = dataGridViewCellStyle85;
            this.dataGridViewTextBoxColumn31.HeaderText = "Стоимость единицы типа питания";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            // 
            // dataGridViewComboBoxColumn8
            // 
            this.dataGridViewComboBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn8.DataPropertyName = "ФИО ученика";
            this.dataGridViewComboBoxColumn8.DataSource = this.ученикиШколыBindingSource;
            this.dataGridViewComboBoxColumn8.DisplayMember = "ФИО ученика";
            this.dataGridViewComboBoxColumn8.HeaderText = "ФИО ученика";
            this.dataGridViewComboBoxColumn8.Name = "dataGridViewComboBoxColumn8";
            this.dataGridViewComboBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn8.ValueMember = "Код ученика";
            // 
            // dataGridViewCalendarColumn5
            // 
            this.dataGridViewCalendarColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewCalendarColumn5.DataPropertyName = "Дата";
            dataGridViewCellStyle86.Format = "D";
            this.dataGridViewCalendarColumn5.DefaultCellStyle = dataGridViewCellStyle86;
            this.dataGridViewCalendarColumn5.HeaderText = "Дата";
            this.dataGridViewCalendarColumn5.Name = "dataGridViewCalendarColumn5";
            this.dataGridViewCalendarColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCalendarColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewComboBoxColumn9
            // 
            this.dataGridViewComboBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn9.DataPropertyName = "Тип питания";
            this.dataGridViewComboBoxColumn9.DataSource = this.справочникТиповПитанияBindingSource1;
            this.dataGridViewComboBoxColumn9.DisplayMember = "Название типа питания";
            this.dataGridViewComboBoxColumn9.HeaderText = "Тип питания";
            this.dataGridViewComboBoxColumn9.Name = "dataGridViewComboBoxColumn9";
            this.dataGridViewComboBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn9.ValueMember = "Код типа питания";
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn32.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn33.DataPropertyName = "Цена единицы типа питания";
            dataGridViewCellStyle87.Format = "C2";
            dataGridViewCellStyle87.NullValue = null;
            this.dataGridViewTextBoxColumn33.DefaultCellStyle = dataGridViewCellStyle87;
            this.dataGridViewTextBoxColumn33.HeaderText = "Цена единицы типа питания";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            // 
            // dataGridViewComboBoxColumn10
            // 
            this.dataGridViewComboBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn10.DataPropertyName = "Класс";
            this.dataGridViewComboBoxColumn10.DataSource = this.справочникКлассовBindingSource;
            this.dataGridViewComboBoxColumn10.DisplayMember = "Название класса";
            this.dataGridViewComboBoxColumn10.HeaderText = "Класс";
            this.dataGridViewComboBoxColumn10.Name = "dataGridViewComboBoxColumn10";
            this.dataGridViewComboBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn10.ValueMember = "Код класса";
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "Месяц";
            this.dataGridViewTextBoxColumn34.HeaderText = "Месяц";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            this.dataGridViewTextBoxColumn34.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "Год";
            this.dataGridViewTextBoxColumn35.HeaderText = "Год";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            this.dataGridViewTextBoxColumn35.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn36.DataPropertyName = "Название класса";
            this.dataGridViewTextBoxColumn36.HeaderText = "Название класса";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn37.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn37.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn38.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn38.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn39.DataPropertyName = "Цена питания";
            this.dataGridViewTextBoxColumn39.HeaderText = "Цена питания";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "Месяц";
            this.dataGridViewTextBoxColumn40.HeaderText = "Месяц";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            this.dataGridViewTextBoxColumn40.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.DataPropertyName = "Год";
            this.dataGridViewTextBoxColumn41.HeaderText = "Год";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            this.dataGridViewTextBoxColumn41.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn42.DataPropertyName = "ФИО учителя";
            this.dataGridViewTextBoxColumn42.HeaderText = "ФИО учителя";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn43.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn43.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn44.DataPropertyName = "Итого количество";
            this.dataGridViewTextBoxColumn44.HeaderText = "Итого количество";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn45.DataPropertyName = "Итого стоимость питания";
            dataGridViewCellStyle88.Format = "C2";
            dataGridViewCellStyle88.NullValue = null;
            this.dataGridViewTextBoxColumn45.DefaultCellStyle = dataGridViewCellStyle88;
            this.dataGridViewTextBoxColumn45.HeaderText = "Итого стоимость питания";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn46.DataPropertyName = "Дата";
            dataGridViewCellStyle89.Format = "D";
            dataGridViewCellStyle89.NullValue = null;
            this.dataGridViewTextBoxColumn46.DefaultCellStyle = dataGridViewCellStyle89;
            this.dataGridViewTextBoxColumn46.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn47.DataPropertyName = "Название класса";
            this.dataGridViewTextBoxColumn47.HeaderText = "Название класса";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn48.DataPropertyName = "ФИО ученика";
            this.dataGridViewTextBoxColumn48.HeaderText = "ФИО ученика";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn49.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn49.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn50.DataPropertyName = "Дата";
            dataGridViewCellStyle90.Format = "D";
            dataGridViewCellStyle90.NullValue = null;
            this.dataGridViewTextBoxColumn50.DefaultCellStyle = dataGridViewCellStyle90;
            this.dataGridViewTextBoxColumn50.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn51.DataPropertyName = "ФИО учителя";
            this.dataGridViewTextBoxColumn51.HeaderText = "ФИО учителя";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn52.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn52.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            // 
            // dataGridViewTextBoxColumn53
            // 
            this.dataGridViewTextBoxColumn53.DataPropertyName = "Дата затрат";
            this.dataGridViewTextBoxColumn53.HeaderText = "Дата затрат";
            this.dataGridViewTextBoxColumn53.Name = "dataGridViewTextBoxColumn53";
            // 
            // dataGridViewTextBoxColumn54
            // 
            this.dataGridViewTextBoxColumn54.DataPropertyName = "Наименование продукта";
            this.dataGridViewTextBoxColumn54.HeaderText = "Наименование продукта";
            this.dataGridViewTextBoxColumn54.Name = "dataGridViewTextBoxColumn54";
            // 
            // dataGridViewTextBoxColumn55
            // 
            this.dataGridViewTextBoxColumn55.DataPropertyName = "Количество на порцию ";
            this.dataGridViewTextBoxColumn55.HeaderText = "Количество на порцию ";
            this.dataGridViewTextBoxColumn55.Name = "dataGridViewTextBoxColumn55";
            // 
            // dataGridViewTextBoxColumn56
            // 
            this.dataGridViewTextBoxColumn56.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn56.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn56.Name = "dataGridViewTextBoxColumn56";
            // 
            // dataGridViewTextBoxColumn57
            // 
            this.dataGridViewTextBoxColumn57.DataPropertyName = "Цена";
            this.dataGridViewTextBoxColumn57.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn57.Name = "dataGridViewTextBoxColumn57";
            // 
            // dataGridViewTextBoxColumn58
            // 
            this.dataGridViewTextBoxColumn58.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn58.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn58.Name = "dataGridViewTextBoxColumn58";
            // 
            // dataGridViewTextBoxColumn59
            // 
            this.dataGridViewTextBoxColumn59.DataPropertyName = "Дата поставки";
            this.dataGridViewTextBoxColumn59.HeaderText = "Дата поставки";
            this.dataGridViewTextBoxColumn59.Name = "dataGridViewTextBoxColumn59";
            // 
            // dataGridViewTextBoxColumn60
            // 
            this.dataGridViewTextBoxColumn60.DataPropertyName = "Название поставщика";
            this.dataGridViewTextBoxColumn60.HeaderText = "Название поставщика";
            this.dataGridViewTextBoxColumn60.Name = "dataGridViewTextBoxColumn60";
            // 
            // dataGridViewTextBoxColumn61
            // 
            this.dataGridViewTextBoxColumn61.DataPropertyName = "Наименование продукта";
            this.dataGridViewTextBoxColumn61.HeaderText = "Наименование продукта";
            this.dataGridViewTextBoxColumn61.Name = "dataGridViewTextBoxColumn61";
            // 
            // dataGridViewTextBoxColumn62
            // 
            this.dataGridViewTextBoxColumn62.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn62.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn62.Name = "dataGridViewTextBoxColumn62";
            // 
            // dataGridViewTextBoxColumn63
            // 
            this.dataGridViewTextBoxColumn63.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle91.Format = "C2";
            dataGridViewCellStyle91.NullValue = null;
            this.dataGridViewTextBoxColumn63.DefaultCellStyle = dataGridViewCellStyle91;
            this.dataGridViewTextBoxColumn63.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn63.Name = "dataGridViewTextBoxColumn63";
            // 
            // dataGridViewTextBoxColumn64
            // 
            this.dataGridViewTextBoxColumn64.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn64.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn64.Name = "dataGridViewTextBoxColumn64";
            // 
            // dataGridViewTextBoxColumn65
            // 
            this.dataGridViewTextBoxColumn65.DataPropertyName = "Итого";
            this.dataGridViewTextBoxColumn65.HeaderText = "Итого";
            this.dataGridViewTextBoxColumn65.Name = "dataGridViewTextBoxColumn65";
            this.dataGridViewTextBoxColumn65.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn66
            // 
            this.dataGridViewTextBoxColumn66.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn66.DataPropertyName = "Дата расхода";
            this.dataGridViewTextBoxColumn66.HeaderText = "Дата расхода";
            this.dataGridViewTextBoxColumn66.Name = "dataGridViewTextBoxColumn66";
            // 
            // dataGridViewTextBoxColumn67
            // 
            this.dataGridViewTextBoxColumn67.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn67.DataPropertyName = "Наименование продукта";
            this.dataGridViewTextBoxColumn67.HeaderText = "Наименование продукта";
            this.dataGridViewTextBoxColumn67.Name = "dataGridViewTextBoxColumn67";
            // 
            // dataGridViewTextBoxColumn68
            // 
            this.dataGridViewTextBoxColumn68.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn68.DataPropertyName = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn68.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn68.Name = "dataGridViewTextBoxColumn68";
            // 
            // dataGridViewTextBoxColumn69
            // 
            this.dataGridViewTextBoxColumn69.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn69.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn69.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn69.Name = "dataGridViewTextBoxColumn69";
            // 
            // dataGridViewTextBoxColumn70
            // 
            this.dataGridViewTextBoxColumn70.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn70.DataPropertyName = "Общая сумма";
            this.dataGridViewTextBoxColumn70.HeaderText = "Общая сумма";
            this.dataGridViewTextBoxColumn70.Name = "dataGridViewTextBoxColumn70";
            // 
            // dataGridViewTextBoxColumn71
            // 
            this.dataGridViewTextBoxColumn71.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn71.DataPropertyName = "Дата затрат";
            this.dataGridViewTextBoxColumn71.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn71.Name = "dataGridViewTextBoxColumn71";
            // 
            // dataGridViewTextBoxColumn72
            // 
            this.dataGridViewTextBoxColumn72.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn72.DataPropertyName = "Стоимость типа питания";
            this.dataGridViewTextBoxColumn72.HeaderText = "Стоимость типа питания";
            this.dataGridViewTextBoxColumn72.Name = "dataGridViewTextBoxColumn72";
            this.dataGridViewTextBoxColumn72.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn73
            // 
            this.dataGridViewTextBoxColumn73.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn73.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn73.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn73.Name = "dataGridViewTextBoxColumn73";
            // 
            // справочникПоставщиковBindingSource
            // 
            this.справочникПоставщиковBindingSource.DataMember = "Справочник поставщиков";
            this.справочникПоставщиковBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // schoolFoodDataSet
            // 
            this.schoolFoodDataSet.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // кодПоставщикаDataGridViewTextBoxColumn
            // 
            this.кодПоставщикаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.кодПоставщикаDataGridViewTextBoxColumn.DataPropertyName = "Код поставщика";
            this.кодПоставщикаDataGridViewTextBoxColumn.HeaderText = "Код поставщика";
            this.кодПоставщикаDataGridViewTextBoxColumn.Name = "кодПоставщикаDataGridViewTextBoxColumn";
            // 
            // названиеПоставщикаDataGridViewTextBoxColumn
            // 
            this.названиеПоставщикаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеПоставщикаDataGridViewTextBoxColumn.DataPropertyName = "Название поставщика";
            this.названиеПоставщикаDataGridViewTextBoxColumn.HeaderText = "Название поставщика";
            this.названиеПоставщикаDataGridViewTextBoxColumn.Name = "названиеПоставщикаDataGridViewTextBoxColumn";
            // 
            // реквизитыПоставщикаDataGridViewTextBoxColumn
            // 
            this.реквизитыПоставщикаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.реквизитыПоставщикаDataGridViewTextBoxColumn.DataPropertyName = "Реквизиты поставщика";
            this.реквизитыПоставщикаDataGridViewTextBoxColumn.HeaderText = "Реквизиты поставщика";
            this.реквизитыПоставщикаDataGridViewTextBoxColumn.Name = "реквизитыПоставщикаDataGridViewTextBoxColumn";
            // 
            // справочникТиповПитанияBindingSource
            // 
            this.справочникТиповПитанияBindingSource.DataMember = "Справочник типов питания";
            this.справочникТиповПитанияBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // кодТипаПитанияDataGridViewTextBoxColumn
            // 
            this.кодТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.кодТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Код типа питания";
            this.кодТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Код типа питания";
            this.кодТипаПитанияDataGridViewTextBoxColumn.Name = "кодТипаПитанияDataGridViewTextBoxColumn";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn.Name = "названиеТипаПитанияDataGridViewTextBoxColumn";
            // 
            // справочникПродуктовBindingSource
            // 
            this.справочникПродуктовBindingSource.DataMember = "Справочник продуктов";
            this.справочникПродуктовBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // кодПродуктаDataGridViewTextBoxColumn
            // 
            this.кодПродуктаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.кодПродуктаDataGridViewTextBoxColumn.DataPropertyName = "Код продукта";
            this.кодПродуктаDataGridViewTextBoxColumn.HeaderText = "Код продукта";
            this.кодПродуктаDataGridViewTextBoxColumn.Name = "кодПродуктаDataGridViewTextBoxColumn";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.наименованиеПродуктаDataGridViewTextBoxColumn.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn.Name = "наименованиеПродуктаDataGridViewTextBoxColumn";
            // 
            // справочникКлассовBindingSource
            // 
            this.справочникКлассовBindingSource.DataMember = "Справочник классов";
            this.справочникКлассовBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // кодКлассаDataGridViewTextBoxColumn
            // 
            this.кодКлассаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.кодКлассаDataGridViewTextBoxColumn.DataPropertyName = "Код класса";
            this.кодКлассаDataGridViewTextBoxColumn.HeaderText = "Код класса";
            this.кодКлассаDataGridViewTextBoxColumn.Name = "кодКлассаDataGridViewTextBoxColumn";
            // 
            // названиеКлассаDataGridViewTextBoxColumn
            // 
            this.названиеКлассаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеКлассаDataGridViewTextBoxColumn.DataPropertyName = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn.HeaderText = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn.Name = "названиеКлассаDataGridViewTextBoxColumn";
            // 
            // учителяШколыBindingSource
            // 
            this.учителяШколыBindingSource.DataMember = "Учителя школы";
            this.учителяШколыBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // кодУчителяDataGridViewTextBoxColumn
            // 
            this.кодУчителяDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.кодУчителяDataGridViewTextBoxColumn.DataPropertyName = "Код учителя";
            this.кодУчителяDataGridViewTextBoxColumn.HeaderText = "Код учителя";
            this.кодУчителяDataGridViewTextBoxColumn.Name = "кодУчителяDataGridViewTextBoxColumn";
            // 
            // фИОУчителяDataGridViewTextBoxColumn
            // 
            this.фИОУчителяDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУчителяDataGridViewTextBoxColumn.DataPropertyName = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn.HeaderText = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn.Name = "фИОУчителяDataGridViewTextBoxColumn";
            // 
            // домашнийАдресDataGridViewTextBoxColumn
            // 
            this.домашнийАдресDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.домашнийАдресDataGridViewTextBoxColumn.DataPropertyName = "Домашний адрес";
            this.домашнийАдресDataGridViewTextBoxColumn.HeaderText = "Домашний адрес";
            this.домашнийАдресDataGridViewTextBoxColumn.Name = "домашнийАдресDataGridViewTextBoxColumn";
            // 
            // телефонDataGridViewTextBoxColumn
            // 
            this.телефонDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.телефонDataGridViewTextBoxColumn.DataPropertyName = "Телефон";
            this.телефонDataGridViewTextBoxColumn.HeaderText = "Телефон";
            this.телефонDataGridViewTextBoxColumn.Name = "телефонDataGridViewTextBoxColumn";
            // 
            // предметDataGridViewTextBoxColumn
            // 
            this.предметDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.предметDataGridViewTextBoxColumn.DataPropertyName = "Предмет";
            this.предметDataGridViewTextBoxColumn.HeaderText = "Предмет";
            this.предметDataGridViewTextBoxColumn.Name = "предметDataGridViewTextBoxColumn";
            // 
            // ученикиШколыBindingSource
            // 
            this.ученикиШколыBindingSource.DataMember = "Ученики школы";
            this.ученикиШколыBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // кодУченикаDataGridViewTextBoxColumn
            // 
            this.кодУченикаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.кодУченикаDataGridViewTextBoxColumn.DataPropertyName = "Код ученика";
            this.кодУченикаDataGridViewTextBoxColumn.HeaderText = "Код ученика";
            this.кодУченикаDataGridViewTextBoxColumn.Name = "кодУченикаDataGridViewTextBoxColumn";
            // 
            // фИОУченикаDataGridViewTextBoxColumn
            // 
            this.фИОУченикаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУченикаDataGridViewTextBoxColumn.DataPropertyName = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn.HeaderText = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn.Name = "фИОУченикаDataGridViewTextBoxColumn";
            // 
            // классDataGridViewTextBoxColumn
            // 
            this.классDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.классDataGridViewTextBoxColumn.DataPropertyName = "Класс";
            this.классDataGridViewTextBoxColumn.DataSource = this.справочникКлассовBindingSource;
            this.классDataGridViewTextBoxColumn.DisplayMember = "Название класса";
            this.классDataGridViewTextBoxColumn.HeaderText = "Класс";
            this.классDataGridViewTextBoxColumn.Name = "классDataGridViewTextBoxColumn";
            this.классDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.классDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.классDataGridViewTextBoxColumn.ValueMember = "Код класса";
            // 
            // датаРожденияDataGridViewTextBoxColumn
            // 
            this.датаРожденияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаРожденияDataGridViewTextBoxColumn.DataPropertyName = "Дата рождения";
            dataGridViewCellStyle92.Format = "D";
            this.датаРожденияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle92;
            this.датаРожденияDataGridViewTextBoxColumn.HeaderText = "Дата рождения";
            this.датаРожденияDataGridViewTextBoxColumn.Name = "датаРожденияDataGridViewTextBoxColumn";
            this.датаРожденияDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.датаРожденияDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // домашнийАдресDataGridViewTextBoxColumn1
            // 
            this.домашнийАдресDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.домашнийАдресDataGridViewTextBoxColumn1.DataPropertyName = "Домашний адрес";
            this.домашнийАдресDataGridViewTextBoxColumn1.HeaderText = "Домашний адрес";
            this.домашнийАдресDataGridViewTextBoxColumn1.Name = "домашнийАдресDataGridViewTextBoxColumn1";
            // 
            // телефонDataGridViewTextBoxColumn1
            // 
            this.телефонDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.телефонDataGridViewTextBoxColumn1.DataPropertyName = "Телефон";
            this.телефонDataGridViewTextBoxColumn1.HeaderText = "Телефон";
            this.телефонDataGridViewTextBoxColumn1.Name = "телефонDataGridViewTextBoxColumn1";
            // 
            // кПоставкеТоваровBindingSource
            // 
            this.кПоставкеТоваровBindingSource.DataMember = "К поставке товаров";
            this.кПоставкеТоваровBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // накладнойDataGridViewTextBoxColumn1
            // 
            this.накладнойDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.накладнойDataGridViewTextBoxColumn1.DataPropertyName = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn1.HeaderText = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn1.Name = "накладнойDataGridViewTextBoxColumn1";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn1
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.DataSource = this.справочникПродуктовBindingSource;
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.DisplayMember = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.Name = "наименованиеПродуктаDataGridViewTextBoxColumn1";
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.ValueMember = "Код продукта";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn1
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.единицаИзмеренияDataGridViewTextBoxColumn1.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn1.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn1.Name = "единицаИзмеренияDataGridViewTextBoxColumn1";
            // 
            // ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn
            // 
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle93.Format = "C2";
            dataGridViewCellStyle93.NullValue = null;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle93;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.HeaderText = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.Name = "ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn";
            // 
            // количествоDataGridViewTextBoxColumn2
            // 
            this.количествоDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn2.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn2.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn2.Name = "количествоDataGridViewTextBoxColumn2";
            // 
            // накладнойDataGridViewTextBoxColumn
            // 
            this.накладнойDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.накладнойDataGridViewTextBoxColumn.DataPropertyName = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn.HeaderText = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn.Name = "накладнойDataGridViewTextBoxColumn";
            this.накладнойDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // датаПоставкиDataGridViewTextBoxColumn
            // 
            this.датаПоставкиDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаПоставкиDataGridViewTextBoxColumn.DataPropertyName = "Дата поставки";
            dataGridViewCellStyle94.Format = "D";
            this.датаПоставкиDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle94;
            this.датаПоставкиDataGridViewTextBoxColumn.HeaderText = "Дата поставки";
            this.датаПоставкиDataGridViewTextBoxColumn.Name = "датаПоставкиDataGridViewTextBoxColumn";
            this.датаПоставкиDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.датаПоставкиDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // поставщикDataGridViewTextBoxColumn
            // 
            this.поставщикDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.поставщикDataGridViewTextBoxColumn.DataPropertyName = "Поставщик";
            this.поставщикDataGridViewTextBoxColumn.DataSource = this.справочникПоставщиковBindingSource;
            this.поставщикDataGridViewTextBoxColumn.DisplayMember = "Название поставщика";
            this.поставщикDataGridViewTextBoxColumn.HeaderText = "Поставщик";
            this.поставщикDataGridViewTextBoxColumn.Name = "поставщикDataGridViewTextBoxColumn";
            this.поставщикDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.поставщикDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.поставщикDataGridViewTextBoxColumn.ValueMember = "Код поставщика";
            // 
            // поставкаТоваровBindingSource
            // 
            this.поставкаТоваровBindingSource.DataMember = "Поставка товаров";
            this.поставкаТоваровBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // накладнойDataGridViewTextBoxColumn2
            // 
            this.накладнойDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.накладнойDataGridViewTextBoxColumn2.DataPropertyName = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn2.HeaderText = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn2.Name = "накладнойDataGridViewTextBoxColumn2";
            // 
            // датаРасходаDataGridViewTextBoxColumn
            // 
            this.датаРасходаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаРасходаDataGridViewTextBoxColumn.DataPropertyName = "Дата расхода";
            dataGridViewCellStyle95.Format = "D";
            this.датаРасходаDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle95;
            this.датаРасходаDataGridViewTextBoxColumn.HeaderText = "Дата расхода";
            this.датаРасходаDataGridViewTextBoxColumn.Name = "датаРасходаDataGridViewTextBoxColumn";
            this.датаРасходаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.датаРасходаDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // типПитанияDataGridViewTextBoxColumn3
            // 
            this.типПитанияDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.типПитанияDataGridViewTextBoxColumn3.DataPropertyName = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn3.DataSource = this.справочникТиповПитанияBindingSource;
            this.типПитанияDataGridViewTextBoxColumn3.DisplayMember = "Название типа питания";
            this.типПитанияDataGridViewTextBoxColumn3.HeaderText = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn3.Name = "типПитанияDataGridViewTextBoxColumn3";
            this.типПитанияDataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.типПитанияDataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.типПитанияDataGridViewTextBoxColumn3.ValueMember = "Код типа питания";
            // 
            // количествоУчащихсяDataGridViewTextBoxColumn
            // 
            this.количествоУчащихсяDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоУчащихсяDataGridViewTextBoxColumn.DataPropertyName = "Количество учащихся";
            this.количествоУчащихсяDataGridViewTextBoxColumn.HeaderText = "Количество учащихся";
            this.количествоУчащихсяDataGridViewTextBoxColumn.Name = "количествоУчащихсяDataGridViewTextBoxColumn";
            // 
            // расходТоваровBindingSource
            // 
            this.расходТоваровBindingSource.DataMember = "Расход товаров";
            this.расходТоваровBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // накладнойDataGridViewTextBoxColumn3
            // 
            this.накладнойDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.накладнойDataGridViewTextBoxColumn3.DataPropertyName = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn3.HeaderText = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn3.Name = "накладнойDataGridViewTextBoxColumn3";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn4
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.DataSource = this.справочникПродуктовBindingSource;
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.DisplayMember = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.Name = "наименованиеПродуктаDataGridViewTextBoxColumn4";
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.ValueMember = "Код продукта";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn3
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.единицаИзмеренияDataGridViewTextBoxColumn3.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn3.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn3.Name = "единицаИзмеренияDataGridViewTextBoxColumn3";
            // 
            // ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2
            // 
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2.DataPropertyName = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2.HeaderText = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2.Name = "ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2";
            // 
            // количествоDataGridViewTextBoxColumn5
            // 
            this.количествоDataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn5.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn5.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn5.Name = "количествоDataGridViewTextBoxColumn5";
            // 
            // кРасходуBindingSource
            // 
            this.кРасходуBindingSource.DataMember = "К расходу";
            this.кРасходуBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // затратыПродуктовBindingSource
            // 
            this.затратыПродуктовBindingSource.DataMember = "Затраты продуктов";
            this.затратыПродуктовBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // датаЗатратDataGridViewTextBoxColumn
            // 
            this.датаЗатратDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаЗатратDataGridViewTextBoxColumn.DataPropertyName = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn.HeaderText = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn.Name = "датаЗатратDataGridViewTextBoxColumn";
            this.датаЗатратDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.датаЗатратDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // продуктDataGridViewTextBoxColumn
            // 
            this.продуктDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.продуктDataGridViewTextBoxColumn.DataPropertyName = "Продукт";
            this.продуктDataGridViewTextBoxColumn.DataSource = this.справочникПродуктовBindingSource;
            this.продуктDataGridViewTextBoxColumn.DisplayMember = "Наименование продукта";
            this.продуктDataGridViewTextBoxColumn.HeaderText = "Продукт";
            this.продуктDataGridViewTextBoxColumn.Name = "продуктDataGridViewTextBoxColumn";
            this.продуктDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.продуктDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.продуктDataGridViewTextBoxColumn.ValueMember = "Код продукта";
            // 
            // количествоНаПорциюDataGridViewTextBoxColumn
            // 
            this.количествоНаПорциюDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоНаПорциюDataGridViewTextBoxColumn.DataPropertyName = "Количество на порцию ";
            this.количествоНаПорциюDataGridViewTextBoxColumn.HeaderText = "Количество на порцию ";
            this.количествоНаПорциюDataGridViewTextBoxColumn.Name = "количествоНаПорциюDataGridViewTextBoxColumn";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.единицаИзмеренияDataGridViewTextBoxColumn.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn.Name = "единицаИзмеренияDataGridViewTextBoxColumn";
            // 
            // ценаDataGridViewTextBoxColumn
            // 
            this.ценаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаDataGridViewTextBoxColumn.DataPropertyName = "Цена";
            dataGridViewCellStyle96.Format = "C2";
            dataGridViewCellStyle96.NullValue = null;
            this.ценаDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle96;
            this.ценаDataGridViewTextBoxColumn.HeaderText = "Цена";
            this.ценаDataGridViewTextBoxColumn.Name = "ценаDataGridViewTextBoxColumn";
            // 
            // типПитанияDataGridViewTextBoxColumn2
            // 
            this.типПитанияDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.типПитанияDataGridViewTextBoxColumn2.DataPropertyName = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn2.DataSource = this.справочникТиповПитанияBindingSource;
            this.типПитанияDataGridViewTextBoxColumn2.DisplayMember = "Название типа питания";
            this.типПитанияDataGridViewTextBoxColumn2.HeaderText = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn2.Name = "типПитанияDataGridViewTextBoxColumn2";
            this.типПитанияDataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.типПитанияDataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.типПитанияDataGridViewTextBoxColumn2.ValueMember = "Код типа питания";
            // 
            // фИОУчителяDataGridViewTextBoxColumn1
            // 
            this.фИОУчителяDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУчителяDataGridViewTextBoxColumn1.DataPropertyName = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn1.DataSource = this.учителяШколыBindingSource;
            this.фИОУчителяDataGridViewTextBoxColumn1.DisplayMember = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn1.HeaderText = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn1.Name = "фИОУчителяDataGridViewTextBoxColumn1";
            this.фИОУчителяDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.фИОУчителяDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.фИОУчителяDataGridViewTextBoxColumn1.ValueMember = "Код учителя";
            // 
            // датаDataGridViewTextBoxColumn
            // 
            this.датаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаDataGridViewTextBoxColumn.DataPropertyName = "Дата";
            dataGridViewCellStyle97.Format = "D";
            this.датаDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle97;
            this.датаDataGridViewTextBoxColumn.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn.Name = "датаDataGridViewTextBoxColumn";
            this.датаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.датаDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // типПитанияDataGridViewTextBoxColumn
            // 
            this.типПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.типПитанияDataGridViewTextBoxColumn.DataPropertyName = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn.DataSource = this.справочникТиповПитанияBindingSource;
            this.типПитанияDataGridViewTextBoxColumn.DisplayMember = "Название типа питания";
            this.типПитанияDataGridViewTextBoxColumn.HeaderText = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn.Name = "типПитанияDataGridViewTextBoxColumn";
            this.типПитанияDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.типПитанияDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.типПитанияDataGridViewTextBoxColumn.ValueMember = "Код типа питания";
            // 
            // количествоDataGridViewTextBoxColumn
            // 
            this.количествоDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn.Name = "количествоDataGridViewTextBoxColumn";
            // 
            // стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn
            // 
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Стоимость единицы типа питания";
            dataGridViewCellStyle98.Format = "C2";
            dataGridViewCellStyle98.NullValue = null;
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle98;
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Стоимость единицы типа питания";
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.Name = "стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn";
            // 
            // питаниеУчителейBindingSource
            // 
            this.питаниеУчителейBindingSource.DataMember = "Питание учителей";
            this.питаниеУчителейBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // питаниеУчениковBindingSource
            // 
            this.питаниеУчениковBindingSource.DataMember = "Питание учеников";
            this.питаниеУчениковBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // фИОУченикаDataGridViewTextBoxColumn1
            // 
            this.фИОУченикаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУченикаDataGridViewTextBoxColumn1.DataPropertyName = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn1.DataSource = this.ученикиШколыBindingSource;
            this.фИОУченикаDataGridViewTextBoxColumn1.DisplayMember = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn1.HeaderText = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn1.Name = "фИОУченикаDataGridViewTextBoxColumn1";
            this.фИОУченикаDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.фИОУченикаDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.фИОУченикаDataGridViewTextBoxColumn1.ValueMember = "Код ученика";
            // 
            // датаDataGridViewTextBoxColumn1
            // 
            this.датаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаDataGridViewTextBoxColumn1.DataPropertyName = "Дата";
            dataGridViewCellStyle99.Format = "D";
            this.датаDataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle99;
            this.датаDataGridViewTextBoxColumn1.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn1.Name = "датаDataGridViewTextBoxColumn1";
            this.датаDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.датаDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // типПитанияDataGridViewTextBoxColumn1
            // 
            this.типПитанияDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.типПитанияDataGridViewTextBoxColumn1.DataPropertyName = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn1.DataSource = this.справочникТиповПитанияBindingSource1;
            this.типПитанияDataGridViewTextBoxColumn1.DisplayMember = "Название типа питания";
            this.типПитанияDataGridViewTextBoxColumn1.HeaderText = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn1.Name = "типПитанияDataGridViewTextBoxColumn1";
            this.типПитанияDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.типПитанияDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.типПитанияDataGridViewTextBoxColumn1.ValueMember = "Код типа питания";
            // 
            // справочникТиповПитанияBindingSource1
            // 
            this.справочникТиповПитанияBindingSource1.DataMember = "Справочник типов питания";
            this.справочникТиповПитанияBindingSource1.DataSource = this.schoolFoodDataSet;
            // 
            // количествоDataGridViewTextBoxColumn1
            // 
            this.количествоDataGridViewTextBoxColumn1.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn1.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn1.Name = "количествоDataGridViewTextBoxColumn1";
            // 
            // ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn
            // 
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Цена единицы типа питания";
            dataGridViewCellStyle100.Format = "C2";
            dataGridViewCellStyle100.NullValue = null;
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle100;
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Цена единицы типа питания";
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.Name = "ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn";
            // 
            // классDataGridViewTextBoxColumn1
            // 
            this.классDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.классDataGridViewTextBoxColumn1.DataPropertyName = "Класс";
            this.классDataGridViewTextBoxColumn1.DataSource = this.справочникКлассовBindingSource;
            this.классDataGridViewTextBoxColumn1.DisplayMember = "Название класса";
            this.классDataGridViewTextBoxColumn1.HeaderText = "Класс";
            this.классDataGridViewTextBoxColumn1.Name = "классDataGridViewTextBoxColumn1";
            this.классDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.классDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.классDataGridViewTextBoxColumn1.ValueMember = "Код класса";
            // 
            // названиеКлассаDataGridViewTextBoxColumn1
            // 
            this.названиеКлассаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеКлассаDataGridViewTextBoxColumn1.DataPropertyName = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn1.HeaderText = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn1.Name = "названиеКлассаDataGridViewTextBoxColumn1";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn1
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn1.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn1.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn1.Name = "названиеТипаПитанияDataGridViewTextBoxColumn1";
            // 
            // количествоDataGridViewTextBoxColumn6
            // 
            this.количествоDataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn6.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn6.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn6.Name = "количествоDataGridViewTextBoxColumn6";
            // 
            // ценаПитанияDataGridViewTextBoxColumn
            // 
            this.ценаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Цена питания";
            this.ценаПитанияDataGridViewTextBoxColumn.HeaderText = "Цена питания";
            this.ценаПитанияDataGridViewTextBoxColumn.Name = "ценаПитанияDataGridViewTextBoxColumn";
            // 
            // view51BindingSource
            // 
            this.view51BindingSource.DataMember = "View51";
            this.view51BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // фИОУчителяDataGridViewTextBoxColumn2
            // 
            this.фИОУчителяDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУчителяDataGridViewTextBoxColumn2.DataPropertyName = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn2.HeaderText = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn2.Name = "фИОУчителяDataGridViewTextBoxColumn2";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn3
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn3.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn3.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn3.Name = "названиеТипаПитанияDataGridViewTextBoxColumn3";
            // 
            // итогоКоличествоDataGridViewTextBoxColumn
            // 
            this.итогоКоличествоDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.итогоКоличествоDataGridViewTextBoxColumn.DataPropertyName = "Итого количество";
            this.итогоКоличествоDataGridViewTextBoxColumn.HeaderText = "Итого количество";
            this.итогоКоличествоDataGridViewTextBoxColumn.Name = "итогоКоличествоDataGridViewTextBoxColumn";
            // 
            // итогоСтоимостьПитанияDataGridViewTextBoxColumn
            // 
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.DataPropertyName = "Итого стоимость питания";
            dataGridViewCellStyle101.Format = "C2";
            dataGridViewCellStyle101.NullValue = null;
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle101;
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.HeaderText = "Итого стоимость питания";
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.Name = "итогоСтоимостьПитанияDataGridViewTextBoxColumn";
            // 
            // view61BindingSource
            // 
            this.view61BindingSource.DataMember = "View61";
            this.view61BindingSource.DataSource = this.schoolFoodDataSet5;
            // 
            // schoolFoodDataSet5
            // 
            this.schoolFoodDataSet5.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // датаDataGridViewTextBoxColumn2
            // 
            this.датаDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаDataGridViewTextBoxColumn2.DataPropertyName = "Дата";
            dataGridViewCellStyle102.Format = "D";
            dataGridViewCellStyle102.NullValue = null;
            this.датаDataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle102;
            this.датаDataGridViewTextBoxColumn2.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn2.Name = "датаDataGridViewTextBoxColumn2";
            // 
            // названиеКлассаDataGridViewTextBoxColumn2
            // 
            this.названиеКлассаDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеКлассаDataGridViewTextBoxColumn2.DataPropertyName = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn2.HeaderText = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn2.Name = "названиеКлассаDataGridViewTextBoxColumn2";
            // 
            // фИОУченикаDataGridViewTextBoxColumn2
            // 
            this.фИОУченикаDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУченикаDataGridViewTextBoxColumn2.DataPropertyName = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn2.HeaderText = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn2.Name = "фИОУченикаDataGridViewTextBoxColumn2";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn4
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn4.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn4.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn4.Name = "названиеТипаПитанияDataGridViewTextBoxColumn4";
            // 
            // viewBindingSource
            // 
            this.viewBindingSource.DataMember = "View";
            this.viewBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // датаDataGridViewTextBoxColumn3
            // 
            this.датаDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаDataGridViewTextBoxColumn3.DataPropertyName = "Дата";
            dataGridViewCellStyle103.Format = "D";
            dataGridViewCellStyle103.NullValue = null;
            this.датаDataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle103;
            this.датаDataGridViewTextBoxColumn3.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn3.Name = "датаDataGridViewTextBoxColumn3";
            // 
            // фИОУчителяDataGridViewTextBoxColumn3
            // 
            this.фИОУчителяDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУчителяDataGridViewTextBoxColumn3.DataPropertyName = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn3.HeaderText = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn3.Name = "фИОУчителяDataGridViewTextBoxColumn3";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn5
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn5.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn5.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn5.Name = "названиеТипаПитанияDataGridViewTextBoxColumn5";
            // 
            // view8BindingSource
            // 
            this.view8BindingSource.DataMember = "View8";
            this.view8BindingSource.DataSource = this.schoolFoodDataSet6;
            // 
            // schoolFoodDataSet6
            // 
            this.schoolFoodDataSet6.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // датаЗатратDataGridViewTextBoxColumn1
            // 
            this.датаЗатратDataGridViewTextBoxColumn1.DataPropertyName = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn1.HeaderText = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn1.Name = "датаЗатратDataGridViewTextBoxColumn1";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn2
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn2.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn2.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn2.Name = "наименованиеПродуктаDataGridViewTextBoxColumn2";
            // 
            // количествоНаПорциюDataGridViewTextBoxColumn1
            // 
            this.количествоНаПорциюDataGridViewTextBoxColumn1.DataPropertyName = "Количество на порцию ";
            this.количествоНаПорциюDataGridViewTextBoxColumn1.HeaderText = "Количество на порцию ";
            this.количествоНаПорциюDataGridViewTextBoxColumn1.Name = "количествоНаПорциюDataGridViewTextBoxColumn1";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn2
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn2.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn2.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn2.Name = "единицаИзмеренияDataGridViewTextBoxColumn2";
            // 
            // ценаDataGridViewTextBoxColumn1
            // 
            this.ценаDataGridViewTextBoxColumn1.DataPropertyName = "Цена";
            this.ценаDataGridViewTextBoxColumn1.HeaderText = "Цена";
            this.ценаDataGridViewTextBoxColumn1.Name = "ценаDataGridViewTextBoxColumn1";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn2
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn2.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn2.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn2.Name = "названиеТипаПитанияDataGridViewTextBoxColumn2";
            // 
            // view2BindingSource
            // 
            this.view2BindingSource.DataMember = "View2";
            this.view2BindingSource.DataSource = this.schoolFoodDataSet3;
            // 
            // schoolFoodDataSet3
            // 
            this.schoolFoodDataSet3.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // датаПоставкиDataGridViewTextBoxColumn1
            // 
            this.датаПоставкиDataGridViewTextBoxColumn1.DataPropertyName = "Дата поставки";
            this.датаПоставкиDataGridViewTextBoxColumn1.HeaderText = "Дата поставки";
            this.датаПоставкиDataGridViewTextBoxColumn1.Name = "датаПоставкиDataGridViewTextBoxColumn1";
            // 
            // названиеПоставщикаDataGridViewTextBoxColumn1
            // 
            this.названиеПоставщикаDataGridViewTextBoxColumn1.DataPropertyName = "Название поставщика";
            this.названиеПоставщикаDataGridViewTextBoxColumn1.HeaderText = "Название поставщика";
            this.названиеПоставщикаDataGridViewTextBoxColumn1.Name = "названиеПоставщикаDataGridViewTextBoxColumn1";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn5
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn5.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn5.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn5.Name = "наименованиеПродуктаDataGridViewTextBoxColumn5";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn4
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn4.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn4.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn4.Name = "единицаИзмеренияDataGridViewTextBoxColumn4";
            // 
            // ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3
            // 
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle104.Format = "C2";
            dataGridViewCellStyle104.NullValue = null;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle104;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3.HeaderText = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3.Name = "ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3";
            // 
            // количествоDataGridViewTextBoxColumn3
            // 
            this.количествоDataGridViewTextBoxColumn3.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn3.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn3.Name = "количествоDataGridViewTextBoxColumn3";
            // 
            // итогоDataGridViewTextBoxColumn
            // 
            this.итогоDataGridViewTextBoxColumn.DataPropertyName = "Итого";
            this.итогоDataGridViewTextBoxColumn.HeaderText = "Итого";
            this.итогоDataGridViewTextBoxColumn.Name = "итогоDataGridViewTextBoxColumn";
            this.итогоDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // view41BindingSource
            // 
            this.view41BindingSource.DataMember = "View41";
            this.view41BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // датаРасходаDataGridViewTextBoxColumn1
            // 
            this.датаРасходаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаРасходаDataGridViewTextBoxColumn1.DataPropertyName = "Дата расхода";
            this.датаРасходаDataGridViewTextBoxColumn1.HeaderText = "Дата расхода";
            this.датаРасходаDataGridViewTextBoxColumn1.Name = "датаРасходаDataGridViewTextBoxColumn1";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn3
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.наименованиеПродуктаDataGridViewTextBoxColumn3.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn3.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn3.Name = "наименованиеПродуктаDataGridViewTextBoxColumn3";
            // 
            // ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1
            // 
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1.DataPropertyName = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1.HeaderText = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1.Name = "ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1";
            // 
            // количествоDataGridViewTextBoxColumn4
            // 
            this.количествоDataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn4.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn4.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn4.Name = "количествоDataGridViewTextBoxColumn4";
            // 
            // общаяСуммаDataGridViewTextBoxColumn
            // 
            this.общаяСуммаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.общаяСуммаDataGridViewTextBoxColumn.DataPropertyName = "Общая сумма";
            this.общаяСуммаDataGridViewTextBoxColumn.HeaderText = "Общая сумма";
            this.общаяСуммаDataGridViewTextBoxColumn.Name = "общаяСуммаDataGridViewTextBoxColumn";
            // 
            // view3BindingSource1
            // 
            this.view3BindingSource1.DataMember = "View3";
            this.view3BindingSource1.DataSource = this.schoolFoodDataSet4;
            // 
            // schoolFoodDataSet4
            // 
            this.schoolFoodDataSet4.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view10BindingSource
            // 
            this.view10BindingSource.DataMember = "View10";
            this.view10BindingSource.DataSource = this.schoolFoodDataSet7;
            // 
            // schoolFoodDataSet7
            // 
            this.schoolFoodDataSet7.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // датаЗатратDataGridViewTextBoxColumn2
            // 
            this.датаЗатратDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаЗатратDataGridViewTextBoxColumn2.DataPropertyName = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn2.HeaderText = "Дата";
            this.датаЗатратDataGridViewTextBoxColumn2.Name = "датаЗатратDataGridViewTextBoxColumn2";
            // 
            // стоимостьТипаПитанияDataGridViewTextBoxColumn
            // 
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Стоимость типа питания";
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Стоимость типа питания";
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.Name = "стоимостьТипаПитанияDataGridViewTextBoxColumn";
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn6
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn6.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn6.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn6.Name = "названиеТипаПитанияDataGridViewTextBoxColumn6";
            // 
            // датаDataGridViewTextBoxColumn4
            // 
            this.датаDataGridViewTextBoxColumn4.DataPropertyName = "Дата";
            this.датаDataGridViewTextBoxColumn4.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn4.Name = "датаDataGridViewTextBoxColumn4";
            // 
            // фИОУченикаDataGridViewTextBoxColumn3
            // 
            this.фИОУченикаDataGridViewTextBoxColumn3.DataPropertyName = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn3.HeaderText = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn3.Name = "фИОУченикаDataGridViewTextBoxColumn3";
            // 
            // названиеКлассаDataGridViewTextBoxColumn3
            // 
            this.названиеКлассаDataGridViewTextBoxColumn3.DataPropertyName = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn3.HeaderText = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn3.Name = "названиеКлассаDataGridViewTextBoxColumn3";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn7
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn7.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn7.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn7.Name = "названиеТипаПитанияDataGridViewTextBoxColumn7";
            // 
            // количествоDataGridViewTextBoxColumn7
            // 
            this.количествоDataGridViewTextBoxColumn7.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn7.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn7.Name = "количествоDataGridViewTextBoxColumn7";
            // 
            // ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn1
            // 
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn1.DataPropertyName = "Цена единицы типа питания";
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn1.HeaderText = "Цена единицы типа питания";
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn1.Name = "ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn1";
            // 
            // итогоDataGridViewTextBoxColumn1
            // 
            this.итогоDataGridViewTextBoxColumn1.DataPropertyName = "Итого";
            this.итогоDataGridViewTextBoxColumn1.HeaderText = "Итого";
            this.итогоDataGridViewTextBoxColumn1.Name = "итогоDataGridViewTextBoxColumn1";
            this.итогоDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // view11BindingSource
            // 
            this.view11BindingSource.DataMember = "View11";
            this.view11BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // schoolFoodDataSet2
            // 
            this.schoolFoodDataSet2.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // schoolFoodDataSet1
            // 
            this.schoolFoodDataSet1.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // справочник_поставщиковTableAdapter
            // 
            this.справочник_поставщиковTableAdapter.ClearBeforeFill = true;
            // 
            // справочник_типов_питанияTableAdapter
            // 
            this.справочник_типов_питанияTableAdapter.ClearBeforeFill = true;
            // 
            // справочник_продуктовTableAdapter
            // 
            this.справочник_продуктовTableAdapter.ClearBeforeFill = true;
            // 
            // справочник_классовTableAdapter
            // 
            this.справочник_классовTableAdapter.ClearBeforeFill = true;
            // 
            // учителя_школыTableAdapter
            // 
            this.учителя_школыTableAdapter.ClearBeforeFill = true;
            // 
            // ученики_школыTableAdapter
            // 
            this.ученики_школыTableAdapter.ClearBeforeFill = true;
            // 
            // питание_учителейTableAdapter
            // 
            this.питание_учителейTableAdapter.ClearBeforeFill = true;
            // 
            // питание_учениковTableAdapter
            // 
            this.питание_учениковTableAdapter.ClearBeforeFill = true;
            // 
            // затраты_продуктовTableAdapter
            // 
            this.затраты_продуктовTableAdapter.ClearBeforeFill = true;
            // 
            // поставка_товаровTableAdapter
            // 
            this.поставка_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // к_поставке_товаровTableAdapter
            // 
            this.к_поставке_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // расход_товаровTableAdapter
            // 
            this.расход_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // к_расходуTableAdapter
            // 
            this.к_расходуTableAdapter.ClearBeforeFill = true;
            // 
            // view4TableAdapter
            // 
            this.view4TableAdapter.ClearBeforeFill = true;
            // 
            // view2TableAdapter
            // 
            this.view2TableAdapter.ClearBeforeFill = true;
            // 
            // view41TableAdapter
            // 
            this.view41TableAdapter.ClearBeforeFill = true;
            // 
            // view3TableAdapter
            // 
            this.view3TableAdapter.ClearBeforeFill = true;
            // 
            // view51TableAdapter
            // 
            this.view51TableAdapter.ClearBeforeFill = true;
            // 
            // view61TableAdapter
            // 
            this.view61TableAdapter.ClearBeforeFill = true;
            // 
            // viewTableAdapter
            // 
            this.viewTableAdapter.ClearBeforeFill = true;
            // 
            // view8TableAdapter
            // 
            this.view8TableAdapter.ClearBeforeFill = true;
            // 
            // view1BindingSource
            // 
            this.view1BindingSource.DataMember = "View1";
            this.view1BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // view3BindingSource
            // 
            this.view3BindingSource.DataMember = "View3";
            this.view3BindingSource.DataSource = this.schoolFoodDataSet2;
            // 
            // view2BindingSource1
            // 
            this.view2BindingSource1.DataMember = "View2";
            this.view2BindingSource1.DataSource = this.schoolFoodDataSet;
            // 
            // view4BindingSource
            // 
            this.view4BindingSource.DataMember = "View4";
            this.view4BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // view10TableAdapter
            // 
            this.view10TableAdapter.ClearBeforeFill = true;
            // 
            // view11TableAdapter
            // 
            this.view11TableAdapter.ClearBeforeFill = true;
            // 
            // tabPage26
            // 
            this.tabPage26.Controls.Add(this.bindingNavigator23);
            this.tabPage26.Controls.Add(this.dataGridView23);
            this.tabPage26.Location = new System.Drawing.Point(4, 76);
            this.tabPage26.Name = "tabPage26";
            this.tabPage26.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage26.Size = new System.Drawing.Size(688, 359);
            this.tabPage26.TabIndex = 9;
            this.tabPage26.Text = "Ведомость о питании учеников обобщенная";
            this.tabPage26.UseVisualStyleBackColor = true;
            // 
            // dataGridView23
            // 
            this.dataGridView23.AutoGenerateColumns = false;
            this.dataGridView23.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView23.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.месяцDataGridViewTextBoxColumn,
            this.годDataGridViewTextBoxColumn,
            this.фИОУченикаDataGridViewTextBoxColumn4,
            this.названиеКлассаDataGridViewTextBoxColumn4,
            this.названиеТипаПитанияDataGridViewTextBoxColumn8,
            this.количествоDataGridViewTextBoxColumn8,
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn2,
            this.итогоDataGridViewTextBoxColumn2});
            this.dataGridView23.DataSource = this.view12BindingSource;
            this.dataGridView23.Location = new System.Drawing.Point(135, 36);
            this.dataGridView23.Name = "dataGridView23";
            this.dataGridView23.Size = new System.Drawing.Size(240, 150);
            this.dataGridView23.TabIndex = 0;
            // 
            // view12BindingSource
            // 
            this.view12BindingSource.DataMember = "View12";
            this.view12BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // view12TableAdapter
            // 
            this.view12TableAdapter.ClearBeforeFill = true;
            // 
            // месяцDataGridViewTextBoxColumn
            // 
            this.месяцDataGridViewTextBoxColumn.DataPropertyName = "Месяц";
            this.месяцDataGridViewTextBoxColumn.HeaderText = "Месяц";
            this.месяцDataGridViewTextBoxColumn.Name = "месяцDataGridViewTextBoxColumn";
            // 
            // годDataGridViewTextBoxColumn
            // 
            this.годDataGridViewTextBoxColumn.DataPropertyName = "Год";
            this.годDataGridViewTextBoxColumn.HeaderText = "Год";
            this.годDataGridViewTextBoxColumn.Name = "годDataGridViewTextBoxColumn";
            // 
            // фИОУченикаDataGridViewTextBoxColumn4
            // 
            this.фИОУченикаDataGridViewTextBoxColumn4.DataPropertyName = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn4.HeaderText = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn4.Name = "фИОУченикаDataGridViewTextBoxColumn4";
            // 
            // названиеКлассаDataGridViewTextBoxColumn4
            // 
            this.названиеКлассаDataGridViewTextBoxColumn4.DataPropertyName = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn4.HeaderText = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn4.Name = "названиеКлассаDataGridViewTextBoxColumn4";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn8
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn8.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn8.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn8.Name = "названиеТипаПитанияDataGridViewTextBoxColumn8";
            // 
            // количествоDataGridViewTextBoxColumn8
            // 
            this.количествоDataGridViewTextBoxColumn8.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn8.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn8.Name = "количествоDataGridViewTextBoxColumn8";
            // 
            // ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn2
            // 
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn2.DataPropertyName = "Цена единицы типа питания";
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn2.HeaderText = "Цена единицы типа питания";
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn2.Name = "ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn2";
            // 
            // итогоDataGridViewTextBoxColumn2
            // 
            this.итогоDataGridViewTextBoxColumn2.DataPropertyName = "Итого";
            this.итогоDataGridViewTextBoxColumn2.HeaderText = "Итого";
            this.итогоDataGridViewTextBoxColumn2.Name = "итогоDataGridViewTextBoxColumn2";
            // 
            // bindingNavigator23
            // 
            this.bindingNavigator23.AddNewItem = null;
            this.bindingNavigator23.CountItem = this.bindingNavigatorCountItem20;
            this.bindingNavigator23.DeleteItem = null;
            this.bindingNavigator23.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator23.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem20,
            this.bindingNavigatorMovePreviousItem20,
            this.bindingNavigatorSeparator60,
            this.bindingNavigatorPositionItem20,
            this.bindingNavigatorCountItem20,
            this.bindingNavigatorSeparator61,
            this.bindingNavigatorMoveNextItem20,
            this.bindingNavigatorMoveLastItem20,
            this.bindingNavigatorSeparator62,
            this.toolStripButton25});
            this.bindingNavigator23.Location = new System.Drawing.Point(3, 331);
            this.bindingNavigator23.MoveFirstItem = this.bindingNavigatorMoveFirstItem20;
            this.bindingNavigator23.MoveLastItem = this.bindingNavigatorMoveLastItem20;
            this.bindingNavigator23.MoveNextItem = this.bindingNavigatorMoveNextItem20;
            this.bindingNavigator23.MovePreviousItem = this.bindingNavigatorMovePreviousItem20;
            this.bindingNavigator23.Name = "bindingNavigator23";
            this.bindingNavigator23.PositionItem = this.bindingNavigatorPositionItem20;
            this.bindingNavigator23.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator23.TabIndex = 1;
            this.bindingNavigator23.Text = "bindingNavigator23";
            // 
            // bindingNavigatorMoveFirstItem20
            // 
            this.bindingNavigatorMoveFirstItem20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem20.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem20.Image")));
            this.bindingNavigatorMoveFirstItem20.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem20.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem20.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem20.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem20
            // 
            this.bindingNavigatorMovePreviousItem20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem20.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem20.Image")));
            this.bindingNavigatorMovePreviousItem20.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem20.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem20.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem20.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator60
            // 
            this.bindingNavigatorSeparator60.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator60.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem20
            // 
            this.bindingNavigatorPositionItem20.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem20.AutoSize = false;
            this.bindingNavigatorPositionItem20.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem20.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem20.Text = "0";
            this.bindingNavigatorPositionItem20.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem20
            // 
            this.bindingNavigatorCountItem20.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem20.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem20.Text = "для {0}";
            this.bindingNavigatorCountItem20.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator61
            // 
            this.bindingNavigatorSeparator61.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator61.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem20
            // 
            this.bindingNavigatorMoveNextItem20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem20.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem20.Image")));
            this.bindingNavigatorMoveNextItem20.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem20.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem20.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem20.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem20
            // 
            this.bindingNavigatorMoveLastItem20.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem20.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem20.Image")));
            this.bindingNavigatorMoveLastItem20.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem20.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem20.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem20.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator62
            // 
            this.bindingNavigatorSeparator62.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator62.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton25
            // 
            this.toolStripButton25.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton25.Image")));
            this.toolStripButton25.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton25.Name = "toolStripButton25";
            this.toolStripButton25.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton25.Text = "Обновить данные";
            this.toolStripButton25.Click += new System.EventHandler(this.toolStripButton25_Click);
            // 
            // Admin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 496);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Close_Pr);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Admin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Режим администратора";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Admin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).EndInit();
            this.bindingNavigator2.ResumeLayout(false);
            this.bindingNavigator2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator3)).EndInit();
            this.bindingNavigator3.ResumeLayout(false);
            this.bindingNavigator3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator4)).EndInit();
            this.bindingNavigator4.ResumeLayout(false);
            this.bindingNavigator4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator5)).EndInit();
            this.bindingNavigator5.ResumeLayout(false);
            this.bindingNavigator5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator6)).EndInit();
            this.bindingNavigator6.ResumeLayout(false);
            this.bindingNavigator6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabControl4.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator11)).EndInit();
            this.bindingNavigator11.ResumeLayout(false);
            this.bindingNavigator11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator10)).EndInit();
            this.bindingNavigator10.ResumeLayout(false);
            this.bindingNavigator10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator12)).EndInit();
            this.bindingNavigator12.ResumeLayout(false);
            this.bindingNavigator12.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator13)).EndInit();
            this.bindingNavigator13.ResumeLayout(false);
            this.bindingNavigator13.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator9)).EndInit();
            this.bindingNavigator9.ResumeLayout(false);
            this.bindingNavigator9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            this.tabPage13.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator7)).EndInit();
            this.bindingNavigator7.ResumeLayout(false);
            this.bindingNavigator7.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator8)).EndInit();
            this.bindingNavigator8.ResumeLayout(false);
            this.bindingNavigator8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            this.tabPage16.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.fillToolStrip1.ResumeLayout(false);
            this.fillToolStrip1.PerformLayout();
            this.fillBy2ToolStrip.ResumeLayout(false);
            this.fillBy2ToolStrip.PerformLayout();
            this.fillBy1ToolStrip.ResumeLayout(false);
            this.fillBy1ToolStrip.PerformLayout();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator18)).EndInit();
            this.bindingNavigator18.ResumeLayout(false);
            this.bindingNavigator18.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator19)).EndInit();
            this.bindingNavigator19.ResumeLayout(false);
            this.bindingNavigator19.PerformLayout();
            this.tabPage19.ResumeLayout(false);
            this.tabPage19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator20)).EndInit();
            this.bindingNavigator20.ResumeLayout(false);
            this.bindingNavigator20.PerformLayout();
            this.tabPage20.ResumeLayout(false);
            this.tabPage20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator14)).EndInit();
            this.bindingNavigator14.ResumeLayout(false);
            this.bindingNavigator14.PerformLayout();
            this.tabPage21.ResumeLayout(false);
            this.tabPage21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator15)).EndInit();
            this.bindingNavigator15.ResumeLayout(false);
            this.bindingNavigator15.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator17)).EndInit();
            this.bindingNavigator17.ResumeLayout(false);
            this.bindingNavigator17.PerformLayout();
            this.tabPage23.ResumeLayout(false);
            this.tabPage23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator16)).EndInit();
            this.bindingNavigator16.ResumeLayout(false);
            this.bindingNavigator16.PerformLayout();
            this.tabPage24.ResumeLayout(false);
            this.tabPage24.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator21)).EndInit();
            this.bindingNavigator21.ResumeLayout(false);
            this.bindingNavigator21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView21)).EndInit();
            this.tabPage25.ResumeLayout(false);
            this.tabPage25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator22)).EndInit();
            this.bindingNavigator22.ResumeLayout(false);
            this.bindingNavigator22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникПоставщиковBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникТиповПитанияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникПродуктовBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникКлассовBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.учителяШколыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ученикиШколыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.кПоставкеТоваровBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.поставкаТоваровBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расходТоваровBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.кРасходуBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.затратыПродуктовBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеУчителейBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеУчениковBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникТиповПитанияBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view51BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view61BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view8BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view41BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view10BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view11BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view4BindingSource)).EndInit();
            this.tabPage26.ResumeLayout(false);
            this.tabPage26.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view12BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator23)).EndInit();
            this.bindingNavigator23.ResumeLayout(false);
            this.bindingNavigator23.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button Close_Pr;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.TabPage tabPage15;
        private SchoolFoodDataSet schoolFoodDataSet;
        private System.Windows.Forms.BindingSource справочникПоставщиковBindingSource;
        private SchoolFoodDataSetTableAdapters.Справочник_поставщиковTableAdapter справочник_поставщиковTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource справочникТиповПитанияBindingSource;
        private SchoolFoodDataSetTableAdapters.Справочник_типов_питанияTableAdapter справочник_типов_питанияTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource справочникПродуктовBindingSource;
        private SchoolFoodDataSetTableAdapters.Справочник_продуктовTableAdapter справочник_продуктовTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодПродуктаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingSource справочникКлассовBindingSource;
        private SchoolFoodDataSetTableAdapters.Справочник_классовTableAdapter справочник_классовTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодКлассаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеКлассаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.BindingSource учителяШколыBindingSource;
        private SchoolFoodDataSetTableAdapters.Учителя_школыTableAdapter учителя_школыTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator5;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem4;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem4;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator12;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem4;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator13;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem4;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator14;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодУчителяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУчителяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn домашнийАдресDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn телефонDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn предметDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView6;
        private System.Windows.Forms.BindingSource ученикиШколыBindingSource;
        private SchoolFoodDataSetTableAdapters.Ученики_школыTableAdapter ученики_школыTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem5;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem5;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem5;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem5;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem5;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator15;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem5;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator16;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem5;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem5;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator17;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private SchoolFoodDataSetTableAdapters.Питание_учителейTableAdapter питание_учителейTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem6;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem6;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator18;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem6;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator19;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem6;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator20;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.BindingSource питаниеУчениковBindingSource;
        private SchoolFoodDataSetTableAdapters.Питание_учениковTableAdapter питание_учениковTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem7;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem7;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator21;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem7;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator22;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem7;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator23;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.BindingSource затратыПродуктовBindingSource;
        private SchoolFoodDataSetTableAdapters.Затраты_продуктовTableAdapter затраты_продуктовTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem8;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem8;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator24;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem8;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator25;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem8;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator26;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.BindingSource справочникТиповПитанияBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.BindingSource питаниеУчителейBindingSource;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.BindingSource поставкаТоваровBindingSource;
        private SchoolFoodDataSetTableAdapters.Поставка_товаровTableAdapter поставка_товаровTableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem9;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem9;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator27;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem9;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator28;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem9;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator29;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.BindingSource кПоставкеТоваровBindingSource;
        private SchoolFoodDataSetTableAdapters.К_поставке_товаровTableAdapter к_поставке_товаровTableAdapter;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.BindingNavigator bindingNavigator11;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem10;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem10;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator30;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem10;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator31;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem10;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator32;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.DataGridView dataGridView11;
        private System.Windows.Forms.DataGridViewTextBoxColumn накладнойDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView12;
        private System.Windows.Forms.BindingNavigator bindingNavigator12;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.BindingNavigator bindingNavigator13;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.BindingSource расходТоваровBindingSource;
        private SchoolFoodDataSetTableAdapters.Расход_товаровTableAdapter расход_товаровTableAdapter;
        private System.Windows.Forms.BindingSource кРасходуBindingSource;
        private SchoolFoodDataSetTableAdapters.К_расходуTableAdapter к_расходуTableAdapter;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.BindingSource view1BindingSource;
        private System.Windows.Forms.BindingNavigator bindingNavigator14;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem11;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem11;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem11;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator33;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem11;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator34;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem11;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem11;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator35;
        private SchoolFoodDataSet schoolFoodDataSet1;
        private System.Windows.Forms.BindingNavigator bindingNavigator15;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem12;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem12;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem12;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator36;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem12;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator37;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem12;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem12;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator38;
        private System.Windows.Forms.BindingNavigator bindingNavigator16;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem13;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem13;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem13;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator39;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem13;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator40;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem13;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem13;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator41;
        private SchoolFoodDataSet schoolFoodDataSet2;
        private System.Windows.Forms.BindingSource view3BindingSource;
        private System.Windows.Forms.DataGridView dataGridView13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.BindingNavigator bindingNavigator17;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem14;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem14;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem14;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator42;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem14;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator43;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem14;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem14;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator44;
        private System.Windows.Forms.BindingSource view2BindingSource1;
        private SchoolFoodDataSetTableAdapters.View4TableAdapter view4TableAdapter;
        private System.Windows.Forms.DataGridView dataGridView15;
        private SchoolFoodDataSet schoolFoodDataSet3;
        private System.Windows.Forms.BindingSource view2BindingSource;
        private SchoolFoodDataSetTableAdapters.View2TableAdapter view2TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗатратDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоНаПорциюDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridView dataGridView16;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаРасходаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn общаяСуммаDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource view4BindingSource;
        private System.Windows.Forms.DataGridView dataGridView14;
        private System.Windows.Forms.BindingSource view41BindingSource;
        private SchoolFoodDataSetTableAdapters.View41TableAdapter view41TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаПоставкиDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеПоставщикаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn итогоDataGridViewTextBoxColumn;
        private SchoolFoodDataSet schoolFoodDataSet4;
        private System.Windows.Forms.BindingSource view3BindingSource1;
        private SchoolFoodDataSetTableAdapters.View3TableAdapter view3TableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator18;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem15;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem15;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem15;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator45;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem15;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator46;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem15;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem15;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator47;
        private System.Windows.Forms.BindingSource view51BindingSource;
        private SchoolFoodDataSetTableAdapters.View51TableAdapter view51TableAdapter;
        private System.Windows.Forms.DataGridView dataGridView18;
        private System.Windows.Forms.BindingNavigator bindingNavigator19;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem16;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem16;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem16;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator48;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem16;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator49;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem16;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem16;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator50;
        private SchoolFoodDataSet schoolFoodDataSet5;
        private System.Windows.Forms.BindingSource view61BindingSource;
        private SchoolFoodDataSetTableAdapters.View61TableAdapter view61TableAdapter;
        private System.Windows.Forms.DataGridView dataGridView19;
        private System.Windows.Forms.BindingNavigator bindingNavigator20;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem17;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem17;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem17;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator51;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem17;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator52;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem17;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem17;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator53;
        private System.Windows.Forms.BindingSource viewBindingSource;
        private SchoolFoodDataSetTableAdapters.ViewTableAdapter viewTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеКлассаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУченикаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridView dataGridView20;
        private SchoolFoodDataSet schoolFoodDataSet6;
        private System.Windows.Forms.BindingSource view8BindingSource;
        private SchoolFoodDataSetTableAdapters.View8TableAdapter view8TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУчителяDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодПоставщикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеПоставщикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn реквизитыПоставщикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.BindingNavigator bindingNavigator2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator3;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator5;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.BindingNavigator bindingNavigator3;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem2;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem2;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator6;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem2;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem2;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator8;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.BindingNavigator bindingNavigator4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem3;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem3;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem3;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem3;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem3;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator9;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem3;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem3;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem3;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator11;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DataGridView dataGridView10;
        private System.Windows.Forms.DataGridViewTextBoxColumn накладнойDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCalendarColumn датаПоставкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn поставщикDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn накладнойDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewCalendarColumn датаРасходаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn типПитанияDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоУчащихсяDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn накладнойDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewCalendarColumn датаЗатратDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn продуктDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоНаПорциюDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn типПитанияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn фИОУчителяDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCalendarColumn датаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn типПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn фИОУченикаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewCalendarColumn датаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn типПитанияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn классDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодУченикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУченикаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn классDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCalendarColumn датаРожденияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn домашнийАдресDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn телефонDataGridViewTextBoxColumn1;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private System.Windows.Forms.ToolStripButton toolStripButton18;
        private System.Windows.Forms.ToolStripButton toolStripButton19;
        private System.Windows.Forms.ToolStripButton toolStripButton20;
        private System.Windows.Forms.ToolStripButton toolStripButton21;
        private System.Windows.Forms.TabPage tabPage24;
        private System.Windows.Forms.BindingNavigator bindingNavigator21;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem18;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem18;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem18;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator54;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem18;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator55;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem18;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem18;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator56;
        private System.Windows.Forms.DataGridView dataGridView21;
        private SchoolFoodDataSet schoolFoodDataSet7;
        private System.Windows.Forms.BindingSource view10BindingSource;
        private SchoolFoodDataSetTableAdapters.View10TableAdapter view10TableAdapter;
        private System.Windows.Forms.ToolStripButton toolStripButton22;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗатратDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn стоимостьТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridView dataGridView17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Месяц;
        private System.Windows.Forms.DataGridViewTextBoxColumn Год;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеКлассаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУчителяDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn итогоКоличествоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn итогоСтоимостьПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton toolStripButton23;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
        private System.Windows.Forms.ToolStrip fillBy1ToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel2;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox2;
        private System.Windows.Forms.ToolStripButton fillBy1ToolStripButton;
        private System.Windows.Forms.ToolStrip fillBy2ToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel3;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox3;
        private System.Windows.Forms.ToolStripButton fillBy2ToolStripButton;
        private System.Windows.Forms.ToolStrip fillToolStrip1;
        private System.Windows.Forms.ToolStripButton fillToolStripButton1;
        private System.Windows.Forms.TabPage tabPage25;
        private System.Windows.Forms.DataGridView dataGridView22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn1;
        private System.Windows.Forms.DataGridViewCalendarColumn dataGridViewCalendarColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewCalendarColumn dataGridViewCalendarColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewCalendarColumn dataGridViewCalendarColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn6;
        private System.Windows.Forms.DataGridViewCalendarColumn dataGridViewCalendarColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn8;
        private System.Windows.Forms.DataGridViewCalendarColumn dataGridViewCalendarColumn5;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn53;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn54;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn55;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn56;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn57;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn59;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn60;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn61;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn62;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn63;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn64;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn65;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn66;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn67;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn68;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn69;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn70;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn71;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn72;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn73;
        private System.Windows.Forms.BindingSource view11BindingSource;
        private SchoolFoodDataSetTableAdapters.View11TableAdapter view11TableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator22;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem19;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem19;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem19;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator57;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem19;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator58;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem19;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem19;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator59;
        private System.Windows.Forms.ToolStripButton toolStripButton24;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУченикаDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеКлассаDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn итогоDataGridViewTextBoxColumn1;
        private System.Windows.Forms.TabPage tabPage26;
        private System.Windows.Forms.DataGridView dataGridView23;
        private System.Windows.Forms.BindingSource view12BindingSource;
        private SchoolFoodDataSetTableAdapters.View12TableAdapter view12TableAdapter;
        private System.Windows.Forms.BindingNavigator bindingNavigator23;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem20;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem20;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem20;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator60;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem20;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator61;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem20;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem20;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator62;
        private System.Windows.Forms.ToolStripButton toolStripButton25;
        private System.Windows.Forms.DataGridViewTextBoxColumn месяцDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn годDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУченикаDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеКлассаDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn итогоDataGridViewTextBoxColumn2;
    }
}