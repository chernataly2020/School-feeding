﻿namespace Школьное_питание
{
    partial class Cooker
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cooker));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle176 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle177 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle178 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle179 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle180 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle181 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle182 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle183 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle184 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle185 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle186 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle187 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle188 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle189 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle190 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle191 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle192 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle193 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle194 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle195 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle196 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle197 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle198 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle199 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle200 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.Close_Pr = new System.Windows.Forms.Button();
            this.tabPage21 = new System.Windows.Forms.TabPage();
            this.dataGridView15 = new System.Windows.Forms.DataGridView();
            this.датаЗатратDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоНаПорциюDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet3 = new Школьное_питание.SchoolFoodDataSet();
            this.bindingNavigator15 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem12 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem12 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem12 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator36 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem12 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator37 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem12 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem12 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator38 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton25 = new System.Windows.Forms.ToolStripButton();
            this.tabPage22 = new System.Windows.Forms.TabPage();
            this.dataGridView14 = new System.Windows.Forms.DataGridView();
            this.датаПоставкиDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеПоставщикаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.итогоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view41BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet = new Школьное_питание.SchoolFoodDataSet();
            this.bindingNavigator17 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem14 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem14 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem14 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator42 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem14 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator43 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem14 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem14 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator44 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton18 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton26 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator41 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveLastItem13 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveNextItem13 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator40 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem13 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator39 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMovePreviousItem13 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem13 = new System.Windows.Forms.ToolStripLabel();
            this.tabPage18 = new System.Windows.Forms.TabPage();
            this.dataGridView18 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУчителяDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.итогоКоличествоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view61BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet5 = new Школьное_питание.SchoolFoodDataSet();
            this.bindingNavigator19 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem16 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem16 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem16 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator48 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem16 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator49 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem16 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem16 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator50 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton24 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem13 = new System.Windows.Forms.ToolStripButton();
            this.tabPage19 = new System.Windows.Forms.TabPage();
            this.dataGridView19 = new System.Windows.Forms.DataGridView();
            this.датаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеКлассаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУченикаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator20 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem17 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem17 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem17 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator51 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem17 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator52 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem17 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem17 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator53 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton20 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton28 = new System.Windows.Forms.ToolStripButton();
            this.tabPage20 = new System.Windows.Forms.TabPage();
            this.dataGridView20 = new System.Windows.Forms.DataGridView();
            this.датаDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фИОУчителяDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view8BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet6 = new Школьное_питание.SchoolFoodDataSet();
            this.bindingNavigator14 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem11 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem11 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem11 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator33 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem11 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator34 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem11 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem11 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator35 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton21 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton29 = new System.Windows.Forms.ToolStripButton();
            this.tabPage23 = new System.Windows.Forms.TabPage();
            this.dataGridView16 = new System.Windows.Forms.DataGridView();
            this.датаРасходаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.общаяСуммаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view3BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.schoolFoodDataSet4 = new Школьное_питание.SchoolFoodDataSet();
            this.bindingNavigator16 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton19 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton27 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator47 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveLastItem15 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveNextItem15 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator46 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem15 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator45 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveFirstItem15 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem15 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem15 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem10 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorAddNewItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigator11 = new System.Windows.Forms.BindingNavigator(this.components);
            this.кПоставкеТоваровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorMovePreviousItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator30 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem10 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator31 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem10 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator32 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dataGridView11 = new System.Windows.Forms.DataGridView();
            this.накладнойDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.справочникПродуктовBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.единицаИзмеренияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.накладнойDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаПоставкиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.поставщикDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.справочникПоставщиковBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.поставкаТоваровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator10 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem9 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator27 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem9 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator28 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem9 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator29 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.tabControl4 = new System.Windows.Forms.TabControl();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView12 = new System.Windows.Forms.DataGridView();
            this.накладнойDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаРасходаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типПитанияDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.справочникТиповПитанияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.количествоУчащихсяDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.расходТоваровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator12 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator11 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator12 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator13 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator14 = new System.Windows.Forms.ToolStripSeparator();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridView13 = new System.Windows.Forms.DataGridView();
            this.накладнойDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.наименованиеПродуктаDataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.общаяСуммаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кРасходуBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator13 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton10 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator15 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox2 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator16 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator17 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.bindingNavigator9 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem8 = new System.Windows.Forms.ToolStripButton();
            this.затратыПродуктовBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorCountItem8 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator24 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem8 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator25 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem8 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator26 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridView9 = new System.Windows.Forms.DataGridView();
            this.датаЗатратDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.продуктDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.количествоНаПорциюDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.единицаИзмеренияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типПитанияDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.tabControl5 = new System.Windows.Forms.TabControl();
            this.tabPage14 = new System.Windows.Forms.TabPage();
            this.dataGridView7 = new System.Windows.Forms.DataGridView();
            this.фИОУчителяDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.учителяШколыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.датаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.количествоDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.питаниеУчителейBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator7 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem6 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator18 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem6 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator19 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem6 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator20 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.tabPage15 = new System.Windows.Forms.TabPage();
            this.bindingNavigator8 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem7 = new System.Windows.Forms.ToolStripButton();
            this.питаниеУчениковBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigatorCountItem7 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator21 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem7 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator22 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem7 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator23 = new System.Windows.Forms.ToolStripSeparator();
            this.сохранитьToolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.dataGridView8 = new System.Windows.Forms.DataGridView();
            this.фИОУченикаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.ученикиШколыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.датаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.типПитанияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.справочникТиповПитанияBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.количествоDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.классDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.справочникКлассовBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage16 = new System.Windows.Forms.TabPage();
            this.tabControl6 = new System.Windows.Forms.TabControl();
            this.tabPage17 = new System.Windows.Forms.TabPage();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripButton23 = new System.Windows.Forms.ToolStripButton();
            this.fillBy3ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.param2ToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.param2ToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy3ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.fillBy2ToolStrip = new System.Windows.Forms.ToolStrip();
            this.param1ToolStripLabel3 = new System.Windows.Forms.ToolStripLabel();
            this.param1ToolStripTextBox3 = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy2ToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.dataGridView17 = new System.Windows.Forms.DataGridView();
            this.Месяц = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Год = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеКлассаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.количествоDataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ценаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view51BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator18 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton22 = new System.Windows.Forms.ToolStripButton();
            this.dataGridViewComboBoxColumn1 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn2 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn4 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn6 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewComboBoxColumn7 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn8 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn9 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn10 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewComboBoxColumn11 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn42 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn43 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn44 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn45 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn46 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn54 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn57 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn58 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn60 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn61 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.view2TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View2TableAdapter();
            this.view2BindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.к_расходуTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.К_расходуTableAdapter();
            this.расход_товаровTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Расход_товаровTableAdapter();
            this.к_поставке_товаровTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.К_поставке_товаровTableAdapter();
            this.поставка_товаровTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Поставка_товаровTableAdapter();
            this.затраты_продуктовTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Затраты_продуктовTableAdapter();
            this.питание_учениковTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Питание_учениковTableAdapter();
            this.питание_учителейTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Питание_учителейTableAdapter();
            this.ученики_школыTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Ученики_школыTableAdapter();
            this.учителя_школыTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Учителя_школыTableAdapter();
            this.справочник_классовTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Справочник_классовTableAdapter();
            this.view4TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View4TableAdapter();
            this.справочник_продуктовTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Справочник_продуктовTableAdapter();
            this.справочник_поставщиковTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Справочник_поставщиковTableAdapter();
            this.schoolFoodDataSet1 = new Школьное_питание.SchoolFoodDataSet();
            this.schoolFoodDataSet2 = new Школьное_питание.SchoolFoodDataSet();
            this.view3BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.справочник_типов_питанияTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.Справочник_типов_питанияTableAdapter();
            this.view4BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view8TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View8TableAdapter();
            this.viewTableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.ViewTableAdapter();
            this.view61TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View61TableAdapter();
            this.view51TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View51TableAdapter();
            this.view3TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View3TableAdapter();
            this.view41TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View41TableAdapter();
            this.view1BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.поставкаТоваровBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dataGridView21 = new System.Windows.Forms.DataGridView();
            this.view10BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.view10TableAdapter = new Школьное_питание.SchoolFoodDataSetTableAdapters.View10TableAdapter();
            this.датаЗатратDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеТипаПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator15)).BeginInit();
            this.bindingNavigator15.SuspendLayout();
            this.tabPage22.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view41BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator17)).BeginInit();
            this.bindingNavigator17.SuspendLayout();
            this.tabPage18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view61BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator19)).BeginInit();
            this.bindingNavigator19.SuspendLayout();
            this.tabPage19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator20)).BeginInit();
            this.bindingNavigator20.SuspendLayout();
            this.tabPage20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view8BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator14)).BeginInit();
            this.bindingNavigator14.SuspendLayout();
            this.tabPage23.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator16)).BeginInit();
            this.bindingNavigator16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator11)).BeginInit();
            this.bindingNavigator11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.кПоставкеТоваровBindingSource)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникПродуктовBindingSource)).BeginInit();
            this.tabPage10.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникПоставщиковBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.поставкаТоваровBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator10)).BeginInit();
            this.bindingNavigator10.SuspendLayout();
            this.tabControl4.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникТиповПитанияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.расходТоваровBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator12)).BeginInit();
            this.bindingNavigator12.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.кРасходуBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator13)).BeginInit();
            this.bindingNavigator13.SuspendLayout();
            this.tabPage12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator9)).BeginInit();
            this.bindingNavigator9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.затратыПродуктовBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).BeginInit();
            this.tabPage9.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage13.SuspendLayout();
            this.tabControl5.SuspendLayout();
            this.tabPage14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.учителяШколыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеУчителейBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator7)).BeginInit();
            this.bindingNavigator7.SuspendLayout();
            this.tabPage15.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator8)).BeginInit();
            this.bindingNavigator8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеУчениковBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ученикиШколыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникТиповПитанияBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникКлассовBindingSource)).BeginInit();
            this.tabPage16.SuspendLayout();
            this.tabControl6.SuspendLayout();
            this.tabPage17.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.fillBy3ToolStrip.SuspendLayout();
            this.fillBy2ToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view51BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator18)).BeginInit();
            this.bindingNavigator18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view4BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view1BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.поставкаТоваровBindingSource1)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.view10BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Школьное_питание.Properties.Resources.coffecup_8796;
            this.pictureBox1.Location = new System.Drawing.Point(12, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 101);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(12, 122);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 4;
            // 
            // Close_Pr
            // 
            this.Close_Pr.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Close_Pr.Location = new System.Drawing.Point(12, 429);
            this.Close_Pr.Name = "Close_Pr";
            this.Close_Pr.Size = new System.Drawing.Size(164, 23);
            this.Close_Pr.TabIndex = 6;
            this.Close_Pr.Text = "Закрыть приложение";
            this.Close_Pr.UseVisualStyleBackColor = true;
            this.Close_Pr.Click += new System.EventHandler(this.Close_Pr_Click);
            // 
            // tabPage21
            // 
            this.tabPage21.Controls.Add(this.dataGridView15);
            this.tabPage21.Controls.Add(this.bindingNavigator15);
            this.tabPage21.Location = new System.Drawing.Point(4, 58);
            this.tabPage21.Name = "tabPage21";
            this.tabPage21.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage21.Size = new System.Drawing.Size(688, 342);
            this.tabPage21.TabIndex = 4;
            this.tabPage21.Text = "Отчет по затратам на каждый тип питания за месяц";
            this.tabPage21.UseVisualStyleBackColor = true;
            // 
            // dataGridView15
            // 
            this.dataGridView15.AutoGenerateColumns = false;
            this.dataGridView15.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView15.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаЗатратDataGridViewTextBoxColumn1,
            this.наименованиеПродуктаDataGridViewTextBoxColumn2,
            this.количествоНаПорциюDataGridViewTextBoxColumn1,
            this.единицаИзмеренияDataGridViewTextBoxColumn2,
            this.ценаDataGridViewTextBoxColumn1,
            this.названиеТипаПитанияDataGridViewTextBoxColumn2});
            this.dataGridView15.DataSource = this.view2BindingSource;
            this.dataGridView15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView15.Location = new System.Drawing.Point(3, 3);
            this.dataGridView15.Name = "dataGridView15";
            this.dataGridView15.Size = new System.Drawing.Size(682, 311);
            this.dataGridView15.TabIndex = 2;
            // 
            // датаЗатратDataGridViewTextBoxColumn1
            // 
            this.датаЗатратDataGridViewTextBoxColumn1.DataPropertyName = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn1.HeaderText = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn1.Name = "датаЗатратDataGridViewTextBoxColumn1";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn2
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn2.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn2.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn2.Name = "наименованиеПродуктаDataGridViewTextBoxColumn2";
            // 
            // количествоНаПорциюDataGridViewTextBoxColumn1
            // 
            this.количествоНаПорциюDataGridViewTextBoxColumn1.DataPropertyName = "Количество на порцию ";
            this.количествоНаПорциюDataGridViewTextBoxColumn1.HeaderText = "Количество на порцию ";
            this.количествоНаПорциюDataGridViewTextBoxColumn1.Name = "количествоНаПорциюDataGridViewTextBoxColumn1";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn2
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn2.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn2.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn2.Name = "единицаИзмеренияDataGridViewTextBoxColumn2";
            // 
            // ценаDataGridViewTextBoxColumn1
            // 
            this.ценаDataGridViewTextBoxColumn1.DataPropertyName = "Цена";
            this.ценаDataGridViewTextBoxColumn1.HeaderText = "Цена";
            this.ценаDataGridViewTextBoxColumn1.Name = "ценаDataGridViewTextBoxColumn1";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn2
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn2.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn2.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn2.Name = "названиеТипаПитанияDataGridViewTextBoxColumn2";
            // 
            // view2BindingSource
            // 
            this.view2BindingSource.DataMember = "View2";
            this.view2BindingSource.DataSource = this.schoolFoodDataSet3;
            // 
            // schoolFoodDataSet3
            // 
            this.schoolFoodDataSet3.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigator15
            // 
            this.bindingNavigator15.AddNewItem = null;
            this.bindingNavigator15.BindingSource = this.view2BindingSource;
            this.bindingNavigator15.CountItem = this.bindingNavigatorCountItem12;
            this.bindingNavigator15.DeleteItem = null;
            this.bindingNavigator15.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator15.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem12,
            this.bindingNavigatorMovePreviousItem12,
            this.bindingNavigatorSeparator36,
            this.bindingNavigatorPositionItem12,
            this.bindingNavigatorCountItem12,
            this.bindingNavigatorSeparator37,
            this.bindingNavigatorMoveNextItem12,
            this.bindingNavigatorMoveLastItem12,
            this.bindingNavigatorSeparator38,
            this.toolStripButton17,
            this.toolStripButton25});
            this.bindingNavigator15.Location = new System.Drawing.Point(3, 314);
            this.bindingNavigator15.MoveFirstItem = this.bindingNavigatorMoveFirstItem12;
            this.bindingNavigator15.MoveLastItem = this.bindingNavigatorMoveLastItem12;
            this.bindingNavigator15.MoveNextItem = this.bindingNavigatorMoveNextItem12;
            this.bindingNavigator15.MovePreviousItem = this.bindingNavigatorMovePreviousItem12;
            this.bindingNavigator15.Name = "bindingNavigator15";
            this.bindingNavigator15.PositionItem = this.bindingNavigatorPositionItem12;
            this.bindingNavigator15.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator15.TabIndex = 1;
            this.bindingNavigator15.Text = "bindingNavigator15";
            // 
            // bindingNavigatorCountItem12
            // 
            this.bindingNavigatorCountItem12.Name = "bindingNavigatorCountItem12";
            this.bindingNavigatorCountItem12.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem12.Text = "для {0}";
            this.bindingNavigatorCountItem12.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem12
            // 
            this.bindingNavigatorMoveFirstItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem12.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem12.Image")));
            this.bindingNavigatorMoveFirstItem12.Name = "bindingNavigatorMoveFirstItem12";
            this.bindingNavigatorMoveFirstItem12.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem12.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem12.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem12
            // 
            this.bindingNavigatorMovePreviousItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem12.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem12.Image")));
            this.bindingNavigatorMovePreviousItem12.Name = "bindingNavigatorMovePreviousItem12";
            this.bindingNavigatorMovePreviousItem12.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem12.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem12.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator36
            // 
            this.bindingNavigatorSeparator36.Name = "bindingNavigatorSeparator36";
            this.bindingNavigatorSeparator36.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem12
            // 
            this.bindingNavigatorPositionItem12.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem12.AutoSize = false;
            this.bindingNavigatorPositionItem12.Name = "bindingNavigatorPositionItem12";
            this.bindingNavigatorPositionItem12.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem12.Text = "0";
            this.bindingNavigatorPositionItem12.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator37
            // 
            this.bindingNavigatorSeparator37.Name = "bindingNavigatorSeparator37";
            this.bindingNavigatorSeparator37.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem12
            // 
            this.bindingNavigatorMoveNextItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem12.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem12.Image")));
            this.bindingNavigatorMoveNextItem12.Name = "bindingNavigatorMoveNextItem12";
            this.bindingNavigatorMoveNextItem12.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem12.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem12.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem12
            // 
            this.bindingNavigatorMoveLastItem12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem12.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem12.Image")));
            this.bindingNavigatorMoveLastItem12.Name = "bindingNavigatorMoveLastItem12";
            this.bindingNavigatorMoveLastItem12.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem12.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem12.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator38
            // 
            this.bindingNavigatorSeparator38.Name = "bindingNavigatorSeparator38";
            this.bindingNavigatorSeparator38.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton17
            // 
            this.toolStripButton17.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton17.Image")));
            this.toolStripButton17.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton17.Text = "Обновить данные";
            this.toolStripButton17.Click += new System.EventHandler(this.toolStripButton17_Click);
            // 
            // toolStripButton25
            // 
            this.toolStripButton25.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton25.Image")));
            this.toolStripButton25.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton25.Name = "toolStripButton25";
            this.toolStripButton25.Size = new System.Drawing.Size(110, 22);
            this.toolStripButton25.Text = "Экспорт в Excel";
            this.toolStripButton25.Click += new System.EventHandler(this.toolStripButton25_Click);
            // 
            // tabPage22
            // 
            this.tabPage22.Controls.Add(this.dataGridView14);
            this.tabPage22.Controls.Add(this.bindingNavigator17);
            this.tabPage22.Location = new System.Drawing.Point(4, 58);
            this.tabPage22.Name = "tabPage22";
            this.tabPage22.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage22.Size = new System.Drawing.Size(688, 342);
            this.tabPage22.TabIndex = 5;
            this.tabPage22.Text = "Отчет о приходе продуктов за месяц";
            this.tabPage22.UseVisualStyleBackColor = true;
            // 
            // dataGridView14
            // 
            this.dataGridView14.AutoGenerateColumns = false;
            this.dataGridView14.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView14.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаПоставкиDataGridViewTextBoxColumn1,
            this.названиеПоставщикаDataGridViewTextBoxColumn1,
            this.наименованиеПродуктаDataGridViewTextBoxColumn5,
            this.единицаИзмеренияDataGridViewTextBoxColumn4,
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3,
            this.количествоDataGridViewTextBoxColumn3,
            this.итогоDataGridViewTextBoxColumn});
            this.dataGridView14.DataSource = this.view41BindingSource;
            this.dataGridView14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView14.Location = new System.Drawing.Point(3, 3);
            this.dataGridView14.Name = "dataGridView14";
            this.dataGridView14.Size = new System.Drawing.Size(682, 311);
            this.dataGridView14.TabIndex = 1;
            // 
            // датаПоставкиDataGridViewTextBoxColumn1
            // 
            this.датаПоставкиDataGridViewTextBoxColumn1.DataPropertyName = "Дата поставки";
            this.датаПоставкиDataGridViewTextBoxColumn1.HeaderText = "Дата поставки";
            this.датаПоставкиDataGridViewTextBoxColumn1.Name = "датаПоставкиDataGridViewTextBoxColumn1";
            // 
            // названиеПоставщикаDataGridViewTextBoxColumn1
            // 
            this.названиеПоставщикаDataGridViewTextBoxColumn1.DataPropertyName = "Название поставщика";
            this.названиеПоставщикаDataGridViewTextBoxColumn1.HeaderText = "Название поставщика";
            this.названиеПоставщикаDataGridViewTextBoxColumn1.Name = "названиеПоставщикаDataGridViewTextBoxColumn1";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn5
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn5.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn5.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn5.Name = "наименованиеПродуктаDataGridViewTextBoxColumn5";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn4
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn4.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn4.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn4.Name = "единицаИзмеренияDataGridViewTextBoxColumn4";
            // 
            // ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3
            // 
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle176.Format = "C2";
            dataGridViewCellStyle176.NullValue = null;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle176;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3.HeaderText = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3.Name = "ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3";
            // 
            // количествоDataGridViewTextBoxColumn3
            // 
            this.количествоDataGridViewTextBoxColumn3.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn3.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn3.Name = "количествоDataGridViewTextBoxColumn3";
            // 
            // итогоDataGridViewTextBoxColumn
            // 
            this.итогоDataGridViewTextBoxColumn.DataPropertyName = "Итого";
            this.итогоDataGridViewTextBoxColumn.HeaderText = "Итого";
            this.итогоDataGridViewTextBoxColumn.Name = "итогоDataGridViewTextBoxColumn";
            this.итогоDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // view41BindingSource
            // 
            this.view41BindingSource.DataMember = "View41";
            this.view41BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // schoolFoodDataSet
            // 
            this.schoolFoodDataSet.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigator17
            // 
            this.bindingNavigator17.AddNewItem = null;
            this.bindingNavigator17.BindingSource = this.view41BindingSource;
            this.bindingNavigator17.CountItem = this.bindingNavigatorCountItem14;
            this.bindingNavigator17.DeleteItem = null;
            this.bindingNavigator17.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator17.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem14,
            this.bindingNavigatorMovePreviousItem14,
            this.bindingNavigatorSeparator42,
            this.bindingNavigatorPositionItem14,
            this.bindingNavigatorCountItem14,
            this.bindingNavigatorSeparator43,
            this.bindingNavigatorMoveNextItem14,
            this.bindingNavigatorMoveLastItem14,
            this.bindingNavigatorSeparator44,
            this.toolStripButton18,
            this.toolStripButton26});
            this.bindingNavigator17.Location = new System.Drawing.Point(3, 314);
            this.bindingNavigator17.MoveFirstItem = this.bindingNavigatorMoveFirstItem14;
            this.bindingNavigator17.MoveLastItem = this.bindingNavigatorMoveLastItem14;
            this.bindingNavigator17.MoveNextItem = this.bindingNavigatorMoveNextItem14;
            this.bindingNavigator17.MovePreviousItem = this.bindingNavigatorMovePreviousItem14;
            this.bindingNavigator17.Name = "bindingNavigator17";
            this.bindingNavigator17.PositionItem = this.bindingNavigatorPositionItem14;
            this.bindingNavigator17.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator17.TabIndex = 0;
            this.bindingNavigator17.Text = "bindingNavigator17";
            // 
            // bindingNavigatorCountItem14
            // 
            this.bindingNavigatorCountItem14.Name = "bindingNavigatorCountItem14";
            this.bindingNavigatorCountItem14.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem14.Text = "для {0}";
            this.bindingNavigatorCountItem14.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem14
            // 
            this.bindingNavigatorMoveFirstItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem14.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem14.Image")));
            this.bindingNavigatorMoveFirstItem14.Name = "bindingNavigatorMoveFirstItem14";
            this.bindingNavigatorMoveFirstItem14.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem14.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem14.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem14
            // 
            this.bindingNavigatorMovePreviousItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem14.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem14.Image")));
            this.bindingNavigatorMovePreviousItem14.Name = "bindingNavigatorMovePreviousItem14";
            this.bindingNavigatorMovePreviousItem14.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem14.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem14.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator42
            // 
            this.bindingNavigatorSeparator42.Name = "bindingNavigatorSeparator42";
            this.bindingNavigatorSeparator42.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem14
            // 
            this.bindingNavigatorPositionItem14.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem14.AutoSize = false;
            this.bindingNavigatorPositionItem14.Name = "bindingNavigatorPositionItem14";
            this.bindingNavigatorPositionItem14.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem14.Text = "0";
            this.bindingNavigatorPositionItem14.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator43
            // 
            this.bindingNavigatorSeparator43.Name = "bindingNavigatorSeparator43";
            this.bindingNavigatorSeparator43.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem14
            // 
            this.bindingNavigatorMoveNextItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem14.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem14.Image")));
            this.bindingNavigatorMoveNextItem14.Name = "bindingNavigatorMoveNextItem14";
            this.bindingNavigatorMoveNextItem14.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem14.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem14.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem14
            // 
            this.bindingNavigatorMoveLastItem14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem14.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem14.Image")));
            this.bindingNavigatorMoveLastItem14.Name = "bindingNavigatorMoveLastItem14";
            this.bindingNavigatorMoveLastItem14.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem14.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem14.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator44
            // 
            this.bindingNavigatorSeparator44.Name = "bindingNavigatorSeparator44";
            this.bindingNavigatorSeparator44.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton18
            // 
            this.toolStripButton18.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton18.Image")));
            this.toolStripButton18.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton18.Name = "toolStripButton18";
            this.toolStripButton18.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton18.Text = "Обновить данные";
            this.toolStripButton18.Click += new System.EventHandler(this.toolStripButton18_Click);
            // 
            // toolStripButton26
            // 
            this.toolStripButton26.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton26.Image")));
            this.toolStripButton26.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton26.Name = "toolStripButton26";
            this.toolStripButton26.Size = new System.Drawing.Size(110, 22);
            this.toolStripButton26.Text = "Экспорт в Excel";
            this.toolStripButton26.Click += new System.EventHandler(this.toolStripButton26_Click);
            // 
            // bindingNavigatorSeparator41
            // 
            this.bindingNavigatorSeparator41.Name = "bindingNavigatorSeparator41";
            this.bindingNavigatorSeparator41.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveLastItem13
            // 
            this.bindingNavigatorMoveLastItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem13.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem13.Image")));
            this.bindingNavigatorMoveLastItem13.Name = "bindingNavigatorMoveLastItem13";
            this.bindingNavigatorMoveLastItem13.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem13.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem13.Text = "Переместить в конец";
            // 
            // bindingNavigatorMoveNextItem13
            // 
            this.bindingNavigatorMoveNextItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem13.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem13.Image")));
            this.bindingNavigatorMoveNextItem13.Name = "bindingNavigatorMoveNextItem13";
            this.bindingNavigatorMoveNextItem13.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem13.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem13.Text = "Переместить вперед";
            // 
            // bindingNavigatorSeparator40
            // 
            this.bindingNavigatorSeparator40.Name = "bindingNavigatorSeparator40";
            this.bindingNavigatorSeparator40.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem13
            // 
            this.bindingNavigatorPositionItem13.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem13.AutoSize = false;
            this.bindingNavigatorPositionItem13.Name = "bindingNavigatorPositionItem13";
            this.bindingNavigatorPositionItem13.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem13.Text = "0";
            this.bindingNavigatorPositionItem13.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator39
            // 
            this.bindingNavigatorSeparator39.Name = "bindingNavigatorSeparator39";
            this.bindingNavigatorSeparator39.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMovePreviousItem13
            // 
            this.bindingNavigatorMovePreviousItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem13.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem13.Image")));
            this.bindingNavigatorMovePreviousItem13.Name = "bindingNavigatorMovePreviousItem13";
            this.bindingNavigatorMovePreviousItem13.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem13.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem13.Text = "Переместить назад";
            // 
            // bindingNavigatorCountItem13
            // 
            this.bindingNavigatorCountItem13.Name = "bindingNavigatorCountItem13";
            this.bindingNavigatorCountItem13.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem13.Text = "для {0}";
            this.bindingNavigatorCountItem13.ToolTipText = "Общее число элементов";
            // 
            // tabPage18
            // 
            this.tabPage18.AutoScroll = true;
            this.tabPage18.Controls.Add(this.dataGridView18);
            this.tabPage18.Controls.Add(this.bindingNavigator19);
            this.tabPage18.Location = new System.Drawing.Point(4, 58);
            this.tabPage18.Name = "tabPage18";
            this.tabPage18.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage18.Size = new System.Drawing.Size(688, 342);
            this.tabPage18.TabIndex = 1;
            this.tabPage18.Text = "Ведомость о питании педагогов";
            this.tabPage18.UseVisualStyleBackColor = true;
            // 
            // dataGridView18
            // 
            this.dataGridView18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView18.AutoGenerateColumns = false;
            this.dataGridView18.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView18.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.фИОУчителяDataGridViewTextBoxColumn2,
            this.названиеТипаПитанияDataGridViewTextBoxColumn3,
            this.итогоКоличествоDataGridViewTextBoxColumn,
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn});
            this.dataGridView18.DataSource = this.view61BindingSource;
            this.dataGridView18.Location = new System.Drawing.Point(3, 3);
            this.dataGridView18.Name = "dataGridView18";
            this.dataGridView18.Size = new System.Drawing.Size(682, 270);
            this.dataGridView18.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Месяц";
            this.dataGridViewTextBoxColumn1.HeaderText = "Месяц";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Год";
            this.dataGridViewTextBoxColumn2.HeaderText = "Год";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // фИОУчителяDataGridViewTextBoxColumn2
            // 
            this.фИОУчителяDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУчителяDataGridViewTextBoxColumn2.DataPropertyName = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn2.HeaderText = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn2.Name = "фИОУчителяDataGridViewTextBoxColumn2";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn3
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn3.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn3.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn3.Name = "названиеТипаПитанияDataGridViewTextBoxColumn3";
            // 
            // итогоКоличествоDataGridViewTextBoxColumn
            // 
            this.итогоКоличествоDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.итогоКоличествоDataGridViewTextBoxColumn.DataPropertyName = "Итого количество";
            this.итогоКоличествоDataGridViewTextBoxColumn.HeaderText = "Итого количество";
            this.итогоКоличествоDataGridViewTextBoxColumn.Name = "итогоКоличествоDataGridViewTextBoxColumn";
            // 
            // итогоСтоимостьПитанияDataGridViewTextBoxColumn
            // 
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.DataPropertyName = "Итого стоимость питания";
            dataGridViewCellStyle177.Format = "C2";
            dataGridViewCellStyle177.NullValue = null;
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle177;
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.HeaderText = "Итого стоимость питания";
            this.итогоСтоимостьПитанияDataGridViewTextBoxColumn.Name = "итогоСтоимостьПитанияDataGridViewTextBoxColumn";
            // 
            // view61BindingSource
            // 
            this.view61BindingSource.DataMember = "View61";
            this.view61BindingSource.DataSource = this.schoolFoodDataSet5;
            // 
            // schoolFoodDataSet5
            // 
            this.schoolFoodDataSet5.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigator19
            // 
            this.bindingNavigator19.AddNewItem = null;
            this.bindingNavigator19.BindingSource = this.view61BindingSource;
            this.bindingNavigator19.CountItem = this.bindingNavigatorCountItem16;
            this.bindingNavigator19.DeleteItem = null;
            this.bindingNavigator19.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator19.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem16,
            this.bindingNavigatorMovePreviousItem16,
            this.bindingNavigatorSeparator48,
            this.bindingNavigatorPositionItem16,
            this.bindingNavigatorCountItem16,
            this.bindingNavigatorSeparator49,
            this.bindingNavigatorMoveNextItem16,
            this.bindingNavigatorMoveLastItem16,
            this.bindingNavigatorSeparator50,
            this.toolStripButton16,
            this.toolStripButton24});
            this.bindingNavigator19.Location = new System.Drawing.Point(3, 314);
            this.bindingNavigator19.MoveFirstItem = this.bindingNavigatorMoveFirstItem16;
            this.bindingNavigator19.MoveLastItem = this.bindingNavigatorMoveLastItem16;
            this.bindingNavigator19.MoveNextItem = this.bindingNavigatorMoveNextItem16;
            this.bindingNavigator19.MovePreviousItem = this.bindingNavigatorMovePreviousItem16;
            this.bindingNavigator19.Name = "bindingNavigator19";
            this.bindingNavigator19.PositionItem = this.bindingNavigatorPositionItem16;
            this.bindingNavigator19.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator19.TabIndex = 0;
            this.bindingNavigator19.Text = "bindingNavigator19";
            // 
            // bindingNavigatorCountItem16
            // 
            this.bindingNavigatorCountItem16.Name = "bindingNavigatorCountItem16";
            this.bindingNavigatorCountItem16.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem16.Text = "для {0}";
            this.bindingNavigatorCountItem16.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem16
            // 
            this.bindingNavigatorMoveFirstItem16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem16.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem16.Image")));
            this.bindingNavigatorMoveFirstItem16.Name = "bindingNavigatorMoveFirstItem16";
            this.bindingNavigatorMoveFirstItem16.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem16.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem16.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem16
            // 
            this.bindingNavigatorMovePreviousItem16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem16.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem16.Image")));
            this.bindingNavigatorMovePreviousItem16.Name = "bindingNavigatorMovePreviousItem16";
            this.bindingNavigatorMovePreviousItem16.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem16.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem16.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator48
            // 
            this.bindingNavigatorSeparator48.Name = "bindingNavigatorSeparator48";
            this.bindingNavigatorSeparator48.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem16
            // 
            this.bindingNavigatorPositionItem16.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem16.AutoSize = false;
            this.bindingNavigatorPositionItem16.Name = "bindingNavigatorPositionItem16";
            this.bindingNavigatorPositionItem16.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem16.Text = "0";
            this.bindingNavigatorPositionItem16.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator49
            // 
            this.bindingNavigatorSeparator49.Name = "bindingNavigatorSeparator49";
            this.bindingNavigatorSeparator49.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem16
            // 
            this.bindingNavigatorMoveNextItem16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem16.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem16.Image")));
            this.bindingNavigatorMoveNextItem16.Name = "bindingNavigatorMoveNextItem16";
            this.bindingNavigatorMoveNextItem16.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem16.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem16.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem16
            // 
            this.bindingNavigatorMoveLastItem16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem16.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem16.Image")));
            this.bindingNavigatorMoveLastItem16.Name = "bindingNavigatorMoveLastItem16";
            this.bindingNavigatorMoveLastItem16.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem16.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem16.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator50
            // 
            this.bindingNavigatorSeparator50.Name = "bindingNavigatorSeparator50";
            this.bindingNavigatorSeparator50.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton16.Image")));
            this.toolStripButton16.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton16.Text = "Обновить данные";
            this.toolStripButton16.Click += new System.EventHandler(this.toolStripButton16_Click);
            // 
            // toolStripButton24
            // 
            this.toolStripButton24.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton24.Image")));
            this.toolStripButton24.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton24.Name = "toolStripButton24";
            this.toolStripButton24.Size = new System.Drawing.Size(110, 22);
            this.toolStripButton24.Text = "Экспорт в Excel";
            this.toolStripButton24.Click += new System.EventHandler(this.toolStripButton24_Click);
            // 
            // bindingNavigatorMoveFirstItem13
            // 
            this.bindingNavigatorMoveFirstItem13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem13.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem13.Image")));
            this.bindingNavigatorMoveFirstItem13.Name = "bindingNavigatorMoveFirstItem13";
            this.bindingNavigatorMoveFirstItem13.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem13.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem13.Text = "Переместить в начало";
            // 
            // tabPage19
            // 
            this.tabPage19.Controls.Add(this.dataGridView19);
            this.tabPage19.Controls.Add(this.bindingNavigator20);
            this.tabPage19.Location = new System.Drawing.Point(4, 40);
            this.tabPage19.Name = "tabPage19";
            this.tabPage19.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage19.Size = new System.Drawing.Size(688, 360);
            this.tabPage19.TabIndex = 2;
            this.tabPage19.Text = "Табель посещаемости столовой учащимися за месяц";
            this.tabPage19.UseVisualStyleBackColor = true;
            // 
            // dataGridView19
            // 
            this.dataGridView19.AutoGenerateColumns = false;
            this.dataGridView19.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView19.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаDataGridViewTextBoxColumn2,
            this.названиеКлассаDataGridViewTextBoxColumn2,
            this.фИОУченикаDataGridViewTextBoxColumn2,
            this.названиеТипаПитанияDataGridViewTextBoxColumn4});
            this.dataGridView19.DataSource = this.viewBindingSource;
            this.dataGridView19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView19.Location = new System.Drawing.Point(3, 3);
            this.dataGridView19.Name = "dataGridView19";
            this.dataGridView19.Size = new System.Drawing.Size(682, 329);
            this.dataGridView19.TabIndex = 1;
            // 
            // датаDataGridViewTextBoxColumn2
            // 
            this.датаDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаDataGridViewTextBoxColumn2.DataPropertyName = "Дата";
            dataGridViewCellStyle178.Format = "D";
            dataGridViewCellStyle178.NullValue = null;
            this.датаDataGridViewTextBoxColumn2.DefaultCellStyle = dataGridViewCellStyle178;
            this.датаDataGridViewTextBoxColumn2.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn2.Name = "датаDataGridViewTextBoxColumn2";
            // 
            // названиеКлассаDataGridViewTextBoxColumn2
            // 
            this.названиеКлассаDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеКлассаDataGridViewTextBoxColumn2.DataPropertyName = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn2.HeaderText = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn2.Name = "названиеКлассаDataGridViewTextBoxColumn2";
            // 
            // фИОУченикаDataGridViewTextBoxColumn2
            // 
            this.фИОУченикаDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУченикаDataGridViewTextBoxColumn2.DataPropertyName = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn2.HeaderText = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn2.Name = "фИОУченикаDataGridViewTextBoxColumn2";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn4
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn4.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn4.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn4.Name = "названиеТипаПитанияDataGridViewTextBoxColumn4";
            // 
            // viewBindingSource
            // 
            this.viewBindingSource.DataMember = "View";
            this.viewBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigator20
            // 
            this.bindingNavigator20.AddNewItem = null;
            this.bindingNavigator20.BindingSource = this.viewBindingSource;
            this.bindingNavigator20.CountItem = this.bindingNavigatorCountItem17;
            this.bindingNavigator20.DeleteItem = null;
            this.bindingNavigator20.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator20.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem17,
            this.bindingNavigatorMovePreviousItem17,
            this.bindingNavigatorSeparator51,
            this.bindingNavigatorPositionItem17,
            this.bindingNavigatorCountItem17,
            this.bindingNavigatorSeparator52,
            this.bindingNavigatorMoveNextItem17,
            this.bindingNavigatorMoveLastItem17,
            this.bindingNavigatorSeparator53,
            this.toolStripButton20,
            this.toolStripButton28});
            this.bindingNavigator20.Location = new System.Drawing.Point(3, 332);
            this.bindingNavigator20.MoveFirstItem = this.bindingNavigatorMoveFirstItem17;
            this.bindingNavigator20.MoveLastItem = this.bindingNavigatorMoveLastItem17;
            this.bindingNavigator20.MoveNextItem = this.bindingNavigatorMoveNextItem17;
            this.bindingNavigator20.MovePreviousItem = this.bindingNavigatorMovePreviousItem17;
            this.bindingNavigator20.Name = "bindingNavigator20";
            this.bindingNavigator20.PositionItem = this.bindingNavigatorPositionItem17;
            this.bindingNavigator20.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator20.TabIndex = 0;
            this.bindingNavigator20.Text = "bindingNavigator20";
            // 
            // bindingNavigatorCountItem17
            // 
            this.bindingNavigatorCountItem17.Name = "bindingNavigatorCountItem17";
            this.bindingNavigatorCountItem17.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem17.Text = "для {0}";
            this.bindingNavigatorCountItem17.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem17
            // 
            this.bindingNavigatorMoveFirstItem17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem17.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem17.Image")));
            this.bindingNavigatorMoveFirstItem17.Name = "bindingNavigatorMoveFirstItem17";
            this.bindingNavigatorMoveFirstItem17.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem17.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem17.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem17
            // 
            this.bindingNavigatorMovePreviousItem17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem17.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem17.Image")));
            this.bindingNavigatorMovePreviousItem17.Name = "bindingNavigatorMovePreviousItem17";
            this.bindingNavigatorMovePreviousItem17.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem17.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem17.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator51
            // 
            this.bindingNavigatorSeparator51.Name = "bindingNavigatorSeparator51";
            this.bindingNavigatorSeparator51.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem17
            // 
            this.bindingNavigatorPositionItem17.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem17.AutoSize = false;
            this.bindingNavigatorPositionItem17.Name = "bindingNavigatorPositionItem17";
            this.bindingNavigatorPositionItem17.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem17.Text = "0";
            this.bindingNavigatorPositionItem17.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator52
            // 
            this.bindingNavigatorSeparator52.Name = "bindingNavigatorSeparator52";
            this.bindingNavigatorSeparator52.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem17
            // 
            this.bindingNavigatorMoveNextItem17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem17.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem17.Image")));
            this.bindingNavigatorMoveNextItem17.Name = "bindingNavigatorMoveNextItem17";
            this.bindingNavigatorMoveNextItem17.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem17.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem17.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem17
            // 
            this.bindingNavigatorMoveLastItem17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem17.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem17.Image")));
            this.bindingNavigatorMoveLastItem17.Name = "bindingNavigatorMoveLastItem17";
            this.bindingNavigatorMoveLastItem17.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem17.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem17.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator53
            // 
            this.bindingNavigatorSeparator53.Name = "bindingNavigatorSeparator53";
            this.bindingNavigatorSeparator53.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton20
            // 
            this.toolStripButton20.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton20.Image")));
            this.toolStripButton20.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton20.Name = "toolStripButton20";
            this.toolStripButton20.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton20.Text = "Обновить данные";
            this.toolStripButton20.Click += new System.EventHandler(this.toolStripButton20_Click);
            // 
            // toolStripButton28
            // 
            this.toolStripButton28.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton28.Image")));
            this.toolStripButton28.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton28.Name = "toolStripButton28";
            this.toolStripButton28.Size = new System.Drawing.Size(110, 22);
            this.toolStripButton28.Text = "Экспорт в Excel";
            this.toolStripButton28.Click += new System.EventHandler(this.toolStripButton28_Click);
            // 
            // tabPage20
            // 
            this.tabPage20.Controls.Add(this.dataGridView20);
            this.tabPage20.Controls.Add(this.bindingNavigator14);
            this.tabPage20.Location = new System.Drawing.Point(4, 40);
            this.tabPage20.Name = "tabPage20";
            this.tabPage20.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage20.Size = new System.Drawing.Size(688, 360);
            this.tabPage20.TabIndex = 3;
            this.tabPage20.Text = "Табель посещаемости столовой педагогом за месяц";
            this.tabPage20.UseVisualStyleBackColor = true;
            // 
            // dataGridView20
            // 
            this.dataGridView20.AutoGenerateColumns = false;
            this.dataGridView20.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView20.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаDataGridViewTextBoxColumn3,
            this.фИОУчителяDataGridViewTextBoxColumn3,
            this.названиеТипаПитанияDataGridViewTextBoxColumn5});
            this.dataGridView20.DataSource = this.view8BindingSource;
            this.dataGridView20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView20.Location = new System.Drawing.Point(3, 3);
            this.dataGridView20.Name = "dataGridView20";
            this.dataGridView20.Size = new System.Drawing.Size(682, 329);
            this.dataGridView20.TabIndex = 3;
            // 
            // датаDataGridViewTextBoxColumn3
            // 
            this.датаDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаDataGridViewTextBoxColumn3.DataPropertyName = "Дата";
            dataGridViewCellStyle179.Format = "D";
            dataGridViewCellStyle179.NullValue = null;
            this.датаDataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle179;
            this.датаDataGridViewTextBoxColumn3.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn3.Name = "датаDataGridViewTextBoxColumn3";
            // 
            // фИОУчителяDataGridViewTextBoxColumn3
            // 
            this.фИОУчителяDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУчителяDataGridViewTextBoxColumn3.DataPropertyName = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn3.HeaderText = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn3.Name = "фИОУчителяDataGridViewTextBoxColumn3";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn5
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn5.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn5.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn5.Name = "названиеТипаПитанияDataGridViewTextBoxColumn5";
            // 
            // view8BindingSource
            // 
            this.view8BindingSource.DataMember = "View8";
            this.view8BindingSource.DataSource = this.schoolFoodDataSet6;
            // 
            // schoolFoodDataSet6
            // 
            this.schoolFoodDataSet6.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigator14
            // 
            this.bindingNavigator14.AddNewItem = null;
            this.bindingNavigator14.BindingSource = this.view8BindingSource;
            this.bindingNavigator14.CountItem = this.bindingNavigatorCountItem11;
            this.bindingNavigator14.DeleteItem = null;
            this.bindingNavigator14.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator14.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem11,
            this.bindingNavigatorMovePreviousItem11,
            this.bindingNavigatorSeparator33,
            this.bindingNavigatorPositionItem11,
            this.bindingNavigatorCountItem11,
            this.bindingNavigatorSeparator34,
            this.bindingNavigatorMoveNextItem11,
            this.bindingNavigatorMoveLastItem11,
            this.bindingNavigatorSeparator35,
            this.toolStripButton21,
            this.toolStripButton29});
            this.bindingNavigator14.Location = new System.Drawing.Point(3, 332);
            this.bindingNavigator14.MoveFirstItem = this.bindingNavigatorMoveFirstItem11;
            this.bindingNavigator14.MoveLastItem = this.bindingNavigatorMoveLastItem11;
            this.bindingNavigator14.MoveNextItem = this.bindingNavigatorMoveNextItem11;
            this.bindingNavigator14.MovePreviousItem = this.bindingNavigatorMovePreviousItem11;
            this.bindingNavigator14.Name = "bindingNavigator14";
            this.bindingNavigator14.PositionItem = this.bindingNavigatorPositionItem11;
            this.bindingNavigator14.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator14.TabIndex = 1;
            this.bindingNavigator14.Text = "bindingNavigator14";
            // 
            // bindingNavigatorCountItem11
            // 
            this.bindingNavigatorCountItem11.Name = "bindingNavigatorCountItem11";
            this.bindingNavigatorCountItem11.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem11.Text = "для {0}";
            this.bindingNavigatorCountItem11.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem11
            // 
            this.bindingNavigatorMoveFirstItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem11.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem11.Image")));
            this.bindingNavigatorMoveFirstItem11.Name = "bindingNavigatorMoveFirstItem11";
            this.bindingNavigatorMoveFirstItem11.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem11.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem11.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem11
            // 
            this.bindingNavigatorMovePreviousItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem11.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem11.Image")));
            this.bindingNavigatorMovePreviousItem11.Name = "bindingNavigatorMovePreviousItem11";
            this.bindingNavigatorMovePreviousItem11.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem11.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem11.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator33
            // 
            this.bindingNavigatorSeparator33.Name = "bindingNavigatorSeparator33";
            this.bindingNavigatorSeparator33.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem11
            // 
            this.bindingNavigatorPositionItem11.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem11.AutoSize = false;
            this.bindingNavigatorPositionItem11.Name = "bindingNavigatorPositionItem11";
            this.bindingNavigatorPositionItem11.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem11.Text = "0";
            this.bindingNavigatorPositionItem11.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator34
            // 
            this.bindingNavigatorSeparator34.Name = "bindingNavigatorSeparator34";
            this.bindingNavigatorSeparator34.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem11
            // 
            this.bindingNavigatorMoveNextItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem11.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem11.Image")));
            this.bindingNavigatorMoveNextItem11.Name = "bindingNavigatorMoveNextItem11";
            this.bindingNavigatorMoveNextItem11.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem11.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem11.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem11
            // 
            this.bindingNavigatorMoveLastItem11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem11.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem11.Image")));
            this.bindingNavigatorMoveLastItem11.Name = "bindingNavigatorMoveLastItem11";
            this.bindingNavigatorMoveLastItem11.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem11.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem11.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator35
            // 
            this.bindingNavigatorSeparator35.Name = "bindingNavigatorSeparator35";
            this.bindingNavigatorSeparator35.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton21
            // 
            this.toolStripButton21.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton21.Image")));
            this.toolStripButton21.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton21.Name = "toolStripButton21";
            this.toolStripButton21.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton21.Text = "Обновить данные";
            this.toolStripButton21.Click += new System.EventHandler(this.toolStripButton21_Click);
            // 
            // toolStripButton29
            // 
            this.toolStripButton29.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton29.Image")));
            this.toolStripButton29.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton29.Name = "toolStripButton29";
            this.toolStripButton29.Size = new System.Drawing.Size(110, 22);
            this.toolStripButton29.Text = "Экспорт в Excel";
            this.toolStripButton29.Click += new System.EventHandler(this.toolStripButton29_Click);
            // 
            // tabPage23
            // 
            this.tabPage23.Controls.Add(this.dataGridView16);
            this.tabPage23.Controls.Add(this.bindingNavigator16);
            this.tabPage23.Location = new System.Drawing.Point(4, 58);
            this.tabPage23.Name = "tabPage23";
            this.tabPage23.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage23.Size = new System.Drawing.Size(688, 342);
            this.tabPage23.TabIndex = 6;
            this.tabPage23.Text = "Отчет о расходе продуктов за месяц";
            this.tabPage23.UseVisualStyleBackColor = true;
            // 
            // dataGridView16
            // 
            this.dataGridView16.AutoGenerateColumns = false;
            this.dataGridView16.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView16.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаРасходаDataGridViewTextBoxColumn1,
            this.наименованиеПродуктаDataGridViewTextBoxColumn3,
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1,
            this.количествоDataGridViewTextBoxColumn4,
            this.общаяСуммаDataGridViewTextBoxColumn});
            this.dataGridView16.DataSource = this.view3BindingSource1;
            this.dataGridView16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView16.Location = new System.Drawing.Point(3, 3);
            this.dataGridView16.Name = "dataGridView16";
            this.dataGridView16.Size = new System.Drawing.Size(682, 311);
            this.dataGridView16.TabIndex = 1;
            // 
            // датаРасходаDataGridViewTextBoxColumn1
            // 
            this.датаРасходаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаРасходаDataGridViewTextBoxColumn1.DataPropertyName = "Дата расхода";
            this.датаРасходаDataGridViewTextBoxColumn1.HeaderText = "Дата расхода";
            this.датаРасходаDataGridViewTextBoxColumn1.Name = "датаРасходаDataGridViewTextBoxColumn1";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn3
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.наименованиеПродуктаDataGridViewTextBoxColumn3.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn3.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn3.Name = "наименованиеПродуктаDataGridViewTextBoxColumn3";
            // 
            // ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1
            // 
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1.DataPropertyName = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1.HeaderText = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1.Name = "ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1";
            // 
            // количествоDataGridViewTextBoxColumn4
            // 
            this.количествоDataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn4.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn4.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn4.Name = "количествоDataGridViewTextBoxColumn4";
            // 
            // общаяСуммаDataGridViewTextBoxColumn
            // 
            this.общаяСуммаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.общаяСуммаDataGridViewTextBoxColumn.DataPropertyName = "Общая сумма";
            this.общаяСуммаDataGridViewTextBoxColumn.HeaderText = "Общая сумма";
            this.общаяСуммаDataGridViewTextBoxColumn.Name = "общаяСуммаDataGridViewTextBoxColumn";
            // 
            // view3BindingSource1
            // 
            this.view3BindingSource1.DataMember = "View3";
            this.view3BindingSource1.DataSource = this.schoolFoodDataSet4;
            // 
            // schoolFoodDataSet4
            // 
            this.schoolFoodDataSet4.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigator16
            // 
            this.bindingNavigator16.AddNewItem = null;
            this.bindingNavigator16.BindingSource = this.view3BindingSource1;
            this.bindingNavigator16.CountItem = this.bindingNavigatorCountItem13;
            this.bindingNavigator16.DeleteItem = null;
            this.bindingNavigator16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator16.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem13,
            this.bindingNavigatorMovePreviousItem13,
            this.bindingNavigatorSeparator39,
            this.bindingNavigatorPositionItem13,
            this.bindingNavigatorCountItem13,
            this.bindingNavigatorSeparator40,
            this.bindingNavigatorMoveNextItem13,
            this.bindingNavigatorMoveLastItem13,
            this.bindingNavigatorSeparator41,
            this.toolStripButton19,
            this.toolStripButton27});
            this.bindingNavigator16.Location = new System.Drawing.Point(3, 314);
            this.bindingNavigator16.MoveFirstItem = this.bindingNavigatorMoveFirstItem13;
            this.bindingNavigator16.MoveLastItem = this.bindingNavigatorMoveLastItem13;
            this.bindingNavigator16.MoveNextItem = this.bindingNavigatorMoveNextItem13;
            this.bindingNavigator16.MovePreviousItem = this.bindingNavigatorMovePreviousItem13;
            this.bindingNavigator16.Name = "bindingNavigator16";
            this.bindingNavigator16.PositionItem = this.bindingNavigatorPositionItem13;
            this.bindingNavigator16.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator16.TabIndex = 0;
            this.bindingNavigator16.Text = "bindingNavigator16";
            // 
            // toolStripButton19
            // 
            this.toolStripButton19.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton19.Image")));
            this.toolStripButton19.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton19.Name = "toolStripButton19";
            this.toolStripButton19.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton19.Text = "Обновить данные";
            this.toolStripButton19.Click += new System.EventHandler(this.toolStripButton19_Click);
            // 
            // toolStripButton27
            // 
            this.toolStripButton27.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton27.Image")));
            this.toolStripButton27.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton27.Name = "toolStripButton27";
            this.toolStripButton27.Size = new System.Drawing.Size(110, 22);
            this.toolStripButton27.Text = "Экспорт в Excel";
            this.toolStripButton27.Click += new System.EventHandler(this.toolStripButton27_Click);
            // 
            // bindingNavigatorSeparator47
            // 
            this.bindingNavigatorSeparator47.Name = "bindingNavigatorSeparator47";
            this.bindingNavigatorSeparator47.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveLastItem15
            // 
            this.bindingNavigatorMoveLastItem15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem15.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem15.Image")));
            this.bindingNavigatorMoveLastItem15.Name = "bindingNavigatorMoveLastItem15";
            this.bindingNavigatorMoveLastItem15.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem15.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem15.Text = "Переместить в конец";
            // 
            // bindingNavigatorMoveNextItem15
            // 
            this.bindingNavigatorMoveNextItem15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem15.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem15.Image")));
            this.bindingNavigatorMoveNextItem15.Name = "bindingNavigatorMoveNextItem15";
            this.bindingNavigatorMoveNextItem15.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem15.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem15.Text = "Переместить вперед";
            // 
            // bindingNavigatorSeparator46
            // 
            this.bindingNavigatorSeparator46.Name = "bindingNavigatorSeparator46";
            this.bindingNavigatorSeparator46.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem15
            // 
            this.bindingNavigatorPositionItem15.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem15.AutoSize = false;
            this.bindingNavigatorPositionItem15.Name = "bindingNavigatorPositionItem15";
            this.bindingNavigatorPositionItem15.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem15.Text = "0";
            this.bindingNavigatorPositionItem15.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator45
            // 
            this.bindingNavigatorSeparator45.Name = "bindingNavigatorSeparator45";
            this.bindingNavigatorSeparator45.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveFirstItem15
            // 
            this.bindingNavigatorMoveFirstItem15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem15.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem15.Image")));
            this.bindingNavigatorMoveFirstItem15.Name = "bindingNavigatorMoveFirstItem15";
            this.bindingNavigatorMoveFirstItem15.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem15.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem15.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem15
            // 
            this.bindingNavigatorMovePreviousItem15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem15.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem15.Image")));
            this.bindingNavigatorMovePreviousItem15.Name = "bindingNavigatorMovePreviousItem15";
            this.bindingNavigatorMovePreviousItem15.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem15.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem15.Text = "Переместить назад";
            // 
            // bindingNavigatorCountItem15
            // 
            this.bindingNavigatorCountItem15.Name = "bindingNavigatorCountItem15";
            this.bindingNavigatorCountItem15.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem15.Text = "для {0}";
            this.bindingNavigatorCountItem15.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorMoveFirstItem10
            // 
            this.bindingNavigatorMoveFirstItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem10.Image")));
            this.bindingNavigatorMoveFirstItem10.Name = "bindingNavigatorMoveFirstItem10";
            this.bindingNavigatorMoveFirstItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem10.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem10.Text = "Переместить в начало";
            // 
            // bindingNavigatorDeleteItem10
            // 
            this.bindingNavigatorDeleteItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem10.Image")));
            this.bindingNavigatorDeleteItem10.Name = "bindingNavigatorDeleteItem10";
            this.bindingNavigatorDeleteItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem10.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem10.Text = "Удалить запись";
            // 
            // bindingNavigatorCountItem10
            // 
            this.bindingNavigatorCountItem10.Name = "bindingNavigatorCountItem10";
            this.bindingNavigatorCountItem10.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem10.Text = "для {0}";
            this.bindingNavigatorCountItem10.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorAddNewItem10
            // 
            this.bindingNavigatorAddNewItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem10.Image")));
            this.bindingNavigatorAddNewItem10.Name = "bindingNavigatorAddNewItem10";
            this.bindingNavigatorAddNewItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem10.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem10.Text = "Добавить запись";
            // 
            // bindingNavigator11
            // 
            this.bindingNavigator11.AddNewItem = this.bindingNavigatorAddNewItem10;
            this.bindingNavigator11.BindingSource = this.кПоставкеТоваровBindingSource;
            this.bindingNavigator11.CountItem = this.bindingNavigatorCountItem10;
            this.bindingNavigator11.DeleteItem = this.bindingNavigatorDeleteItem10;
            this.bindingNavigator11.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator11.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem10,
            this.bindingNavigatorMovePreviousItem10,
            this.bindingNavigatorSeparator30,
            this.bindingNavigatorPositionItem10,
            this.bindingNavigatorCountItem10,
            this.bindingNavigatorSeparator31,
            this.bindingNavigatorMoveNextItem10,
            this.bindingNavigatorMoveLastItem10,
            this.bindingNavigatorSeparator32,
            this.bindingNavigatorAddNewItem10,
            this.bindingNavigatorDeleteItem10,
            this.сохранитьToolStripButton10,
            this.toolStripSeparator10});
            this.bindingNavigator11.Location = new System.Drawing.Point(3, 180);
            this.bindingNavigator11.MoveFirstItem = this.bindingNavigatorMoveFirstItem10;
            this.bindingNavigator11.MoveLastItem = this.bindingNavigatorMoveLastItem10;
            this.bindingNavigator11.MoveNextItem = this.bindingNavigatorMoveNextItem10;
            this.bindingNavigator11.MovePreviousItem = this.bindingNavigatorMovePreviousItem10;
            this.bindingNavigator11.Name = "bindingNavigator11";
            this.bindingNavigator11.PositionItem = this.bindingNavigatorPositionItem10;
            this.bindingNavigator11.Size = new System.Drawing.Size(664, 25);
            this.bindingNavigator11.TabIndex = 3;
            this.bindingNavigator11.Text = "bindingNavigator11";
            // 
            // кПоставкеТоваровBindingSource
            // 
            this.кПоставкеТоваровBindingSource.DataMember = "К поставке товаров";
            this.кПоставкеТоваровBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigatorMovePreviousItem10
            // 
            this.bindingNavigatorMovePreviousItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem10.Image")));
            this.bindingNavigatorMovePreviousItem10.Name = "bindingNavigatorMovePreviousItem10";
            this.bindingNavigatorMovePreviousItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem10.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem10.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator30
            // 
            this.bindingNavigatorSeparator30.Name = "bindingNavigatorSeparator30";
            this.bindingNavigatorSeparator30.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem10
            // 
            this.bindingNavigatorPositionItem10.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem10.AutoSize = false;
            this.bindingNavigatorPositionItem10.Name = "bindingNavigatorPositionItem10";
            this.bindingNavigatorPositionItem10.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem10.Text = "0";
            this.bindingNavigatorPositionItem10.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator31
            // 
            this.bindingNavigatorSeparator31.Name = "bindingNavigatorSeparator31";
            this.bindingNavigatorSeparator31.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem10
            // 
            this.bindingNavigatorMoveNextItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem10.Image")));
            this.bindingNavigatorMoveNextItem10.Name = "bindingNavigatorMoveNextItem10";
            this.bindingNavigatorMoveNextItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem10.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem10.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem10
            // 
            this.bindingNavigatorMoveLastItem10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem10.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem10.Image")));
            this.bindingNavigatorMoveLastItem10.Name = "bindingNavigatorMoveLastItem10";
            this.bindingNavigatorMoveLastItem10.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem10.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem10.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator32
            // 
            this.bindingNavigatorSeparator32.Name = "bindingNavigatorSeparator32";
            this.bindingNavigatorSeparator32.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton10
            // 
            this.сохранитьToolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton10.Image")));
            this.сохранитьToolStripButton10.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton10.Name = "сохранитьToolStripButton10";
            this.сохранитьToolStripButton10.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton10.Text = "&Сохранить данные";
            this.сохранитьToolStripButton10.Click += new System.EventHandler(this.сохранитьToolStripButton10_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(6, 25);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.bindingNavigator11);
            this.groupBox2.Controls.Add(this.dataGridView11);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox2.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox2.Location = new System.Drawing.Point(9, 164);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(670, 208);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Продукты в накладных";
            // 
            // dataGridView11
            // 
            this.dataGridView11.AutoGenerateColumns = false;
            this.dataGridView11.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView11.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.накладнойDataGridViewTextBoxColumn1,
            this.наименованиеПродуктаDataGridViewTextBoxColumn1,
            this.единицаИзмеренияDataGridViewTextBoxColumn1,
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn,
            this.количествоDataGridViewTextBoxColumn2});
            this.dataGridView11.DataSource = this.кПоставкеТоваровBindingSource;
            this.dataGridView11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView11.Location = new System.Drawing.Point(3, 16);
            this.dataGridView11.Name = "dataGridView11";
            this.dataGridView11.Size = new System.Drawing.Size(664, 189);
            this.dataGridView11.TabIndex = 2;
            // 
            // накладнойDataGridViewTextBoxColumn1
            // 
            this.накладнойDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.накладнойDataGridViewTextBoxColumn1.DataPropertyName = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn1.HeaderText = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn1.Name = "накладнойDataGridViewTextBoxColumn1";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn1
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.DataSource = this.справочникПродуктовBindingSource;
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.DisplayMember = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.Name = "наименованиеПродуктаDataGridViewTextBoxColumn1";
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.наименованиеПродуктаDataGridViewTextBoxColumn1.ValueMember = "Код продукта";
            // 
            // справочникПродуктовBindingSource
            // 
            this.справочникПродуктовBindingSource.DataMember = "Справочник продуктов";
            this.справочникПродуктовBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn1
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.единицаИзмеренияDataGridViewTextBoxColumn1.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn1.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn1.Name = "единицаИзмеренияDataGridViewTextBoxColumn1";
            // 
            // ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn
            // 
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle180.Format = "C2";
            dataGridViewCellStyle180.NullValue = null;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle180;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.HeaderText = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn.Name = "ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn";
            // 
            // количествоDataGridViewTextBoxColumn2
            // 
            this.количествоDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn2.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn2.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn2.Name = "количествоDataGridViewTextBoxColumn2";
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.groupBox2);
            this.tabPage10.Controls.Add(this.groupBox1);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(688, 378);
            this.tabPage10.TabIndex = 0;
            this.tabPage10.Text = "Поставка продуктов";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.bindingNavigator10);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox1.Location = new System.Drawing.Point(6, 7);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(676, 157);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Сведения о накладных";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.накладнойDataGridViewTextBoxColumn,
            this.датаПоставкиDataGridViewTextBoxColumn,
            this.поставщикDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.поставкаТоваровBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(3, 16);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(670, 113);
            this.dataGridView1.TabIndex = 7;
            // 
            // накладнойDataGridViewTextBoxColumn
            // 
            this.накладнойDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.накладнойDataGridViewTextBoxColumn.DataPropertyName = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn.HeaderText = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn.Name = "накладнойDataGridViewTextBoxColumn";
            // 
            // датаПоставкиDataGridViewTextBoxColumn
            // 
            this.датаПоставкиDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаПоставкиDataGridViewTextBoxColumn.DataPropertyName = "Дата поставки";
            dataGridViewCellStyle181.Format = "D";
            dataGridViewCellStyle181.NullValue = null;
            this.датаПоставкиDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle181;
            this.датаПоставкиDataGridViewTextBoxColumn.HeaderText = "Дата поставки";
            this.датаПоставкиDataGridViewTextBoxColumn.Name = "датаПоставкиDataGridViewTextBoxColumn";
            // 
            // поставщикDataGridViewTextBoxColumn
            // 
            this.поставщикDataGridViewTextBoxColumn.DataPropertyName = "Поставщик";
            this.поставщикDataGridViewTextBoxColumn.DataSource = this.справочникПоставщиковBindingSource;
            this.поставщикDataGridViewTextBoxColumn.DisplayMember = "Название поставщика";
            this.поставщикDataGridViewTextBoxColumn.HeaderText = "Поставщик";
            this.поставщикDataGridViewTextBoxColumn.Name = "поставщикDataGridViewTextBoxColumn";
            this.поставщикDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.поставщикDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.поставщикDataGridViewTextBoxColumn.ValueMember = "Код поставщика";
            // 
            // справочникПоставщиковBindingSource
            // 
            this.справочникПоставщиковBindingSource.DataMember = "Справочник поставщиков";
            this.справочникПоставщиковBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // поставкаТоваровBindingSource
            // 
            this.поставкаТоваровBindingSource.DataMember = "Поставка товаров";
            this.поставкаТоваровBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigator10
            // 
            this.bindingNavigator10.AddNewItem = this.bindingNavigatorAddNewItem9;
            this.bindingNavigator10.BindingSource = this.поставкаТоваровBindingSource;
            this.bindingNavigator10.CountItem = this.bindingNavigatorCountItem9;
            this.bindingNavigator10.DeleteItem = this.bindingNavigatorDeleteItem9;
            this.bindingNavigator10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator10.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem9,
            this.bindingNavigatorMovePreviousItem9,
            this.bindingNavigatorSeparator27,
            this.bindingNavigatorPositionItem9,
            this.bindingNavigatorCountItem9,
            this.bindingNavigatorSeparator28,
            this.bindingNavigatorMoveNextItem9,
            this.bindingNavigatorMoveLastItem9,
            this.bindingNavigatorSeparator29,
            this.bindingNavigatorAddNewItem9,
            this.bindingNavigatorDeleteItem9,
            this.сохранитьToolStripButton9,
            this.toolStripSeparator8});
            this.bindingNavigator10.Location = new System.Drawing.Point(3, 129);
            this.bindingNavigator10.MoveFirstItem = this.bindingNavigatorMoveFirstItem9;
            this.bindingNavigator10.MoveLastItem = this.bindingNavigatorMoveLastItem9;
            this.bindingNavigator10.MoveNextItem = this.bindingNavigatorMoveNextItem9;
            this.bindingNavigator10.MovePreviousItem = this.bindingNavigatorMovePreviousItem9;
            this.bindingNavigator10.Name = "bindingNavigator10";
            this.bindingNavigator10.PositionItem = this.bindingNavigatorPositionItem9;
            this.bindingNavigator10.Size = new System.Drawing.Size(670, 25);
            this.bindingNavigator10.TabIndex = 6;
            this.bindingNavigator10.Text = "bindingNavigator10";
            // 
            // bindingNavigatorAddNewItem9
            // 
            this.bindingNavigatorAddNewItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem9.Image")));
            this.bindingNavigatorAddNewItem9.Name = "bindingNavigatorAddNewItem9";
            this.bindingNavigatorAddNewItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem9.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem9.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem9
            // 
            this.bindingNavigatorCountItem9.Name = "bindingNavigatorCountItem9";
            this.bindingNavigatorCountItem9.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem9.Text = "для {0}";
            this.bindingNavigatorCountItem9.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem9
            // 
            this.bindingNavigatorDeleteItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem9.Image")));
            this.bindingNavigatorDeleteItem9.Name = "bindingNavigatorDeleteItem9";
            this.bindingNavigatorDeleteItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem9.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem9.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem9
            // 
            this.bindingNavigatorMoveFirstItem9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem9.Image")));
            this.bindingNavigatorMoveFirstItem9.Name = "bindingNavigatorMoveFirstItem9";
            this.bindingNavigatorMoveFirstItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem9.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem9.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem9
            // 
            this.bindingNavigatorMovePreviousItem9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem9.Image")));
            this.bindingNavigatorMovePreviousItem9.Name = "bindingNavigatorMovePreviousItem9";
            this.bindingNavigatorMovePreviousItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem9.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem9.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator27
            // 
            this.bindingNavigatorSeparator27.Name = "bindingNavigatorSeparator27";
            this.bindingNavigatorSeparator27.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem9
            // 
            this.bindingNavigatorPositionItem9.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem9.AutoSize = false;
            this.bindingNavigatorPositionItem9.Name = "bindingNavigatorPositionItem9";
            this.bindingNavigatorPositionItem9.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem9.Text = "0";
            this.bindingNavigatorPositionItem9.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator28
            // 
            this.bindingNavigatorSeparator28.Name = "bindingNavigatorSeparator28";
            this.bindingNavigatorSeparator28.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem9
            // 
            this.bindingNavigatorMoveNextItem9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem9.Image")));
            this.bindingNavigatorMoveNextItem9.Name = "bindingNavigatorMoveNextItem9";
            this.bindingNavigatorMoveNextItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem9.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem9.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem9
            // 
            this.bindingNavigatorMoveLastItem9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem9.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem9.Image")));
            this.bindingNavigatorMoveLastItem9.Name = "bindingNavigatorMoveLastItem9";
            this.bindingNavigatorMoveLastItem9.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem9.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem9.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator29
            // 
            this.bindingNavigatorSeparator29.Name = "bindingNavigatorSeparator29";
            this.bindingNavigatorSeparator29.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton9
            // 
            this.сохранитьToolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton9.Image")));
            this.сохранитьToolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton9.Name = "сохранитьToolStripButton9";
            this.сохранитьToolStripButton9.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton9.Text = "&Сохранить данные";
            this.сохранитьToolStripButton9.Click += new System.EventHandler(this.сохранитьToolStripButton9_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 25);
            // 
            // tabControl4
            // 
            this.tabControl4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl4.Controls.Add(this.tabPage10);
            this.tabControl4.Controls.Add(this.tabPage11);
            this.tabControl4.Controls.Add(this.tabPage12);
            this.tabControl4.Location = new System.Drawing.Point(6, 6);
            this.tabControl4.Name = "tabControl4";
            this.tabControl4.SelectedIndex = 0;
            this.tabControl4.Size = new System.Drawing.Size(696, 404);
            this.tabControl4.TabIndex = 0;
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.groupBox3);
            this.tabPage11.Controls.Add(this.groupBox4);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(688, 378);
            this.tabPage11.TabIndex = 1;
            this.tabPage11.Text = "Расход продуктов";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox3.Controls.Add(this.dataGridView12);
            this.groupBox3.Controls.Add(this.bindingNavigator12);
            this.groupBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox3.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(676, 157);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Сведения о расходных документах";
            // 
            // dataGridView12
            // 
            this.dataGridView12.AutoGenerateColumns = false;
            this.dataGridView12.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView12.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.накладнойDataGridViewTextBoxColumn2,
            this.датаРасходаDataGridViewTextBoxColumn,
            this.типПитанияDataGridViewTextBoxColumn3,
            this.количествоУчащихсяDataGridViewTextBoxColumn});
            this.dataGridView12.DataSource = this.расходТоваровBindingSource;
            this.dataGridView12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView12.Location = new System.Drawing.Point(3, 16);
            this.dataGridView12.Name = "dataGridView12";
            this.dataGridView12.Size = new System.Drawing.Size(670, 113);
            this.dataGridView12.TabIndex = 7;
            // 
            // накладнойDataGridViewTextBoxColumn2
            // 
            this.накладнойDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.накладнойDataGridViewTextBoxColumn2.DataPropertyName = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn2.HeaderText = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn2.Name = "накладнойDataGridViewTextBoxColumn2";
            // 
            // датаРасходаDataGridViewTextBoxColumn
            // 
            this.датаРасходаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаРасходаDataGridViewTextBoxColumn.DataPropertyName = "Дата расхода";
            dataGridViewCellStyle182.Format = "D";
            dataGridViewCellStyle182.NullValue = null;
            this.датаРасходаDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle182;
            this.датаРасходаDataGridViewTextBoxColumn.HeaderText = "Дата расхода";
            this.датаРасходаDataGridViewTextBoxColumn.Name = "датаРасходаDataGridViewTextBoxColumn";
            // 
            // типПитанияDataGridViewTextBoxColumn3
            // 
            this.типПитанияDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.типПитанияDataGridViewTextBoxColumn3.DataPropertyName = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn3.DataSource = this.справочникТиповПитанияBindingSource;
            this.типПитанияDataGridViewTextBoxColumn3.DisplayMember = "Название типа питания";
            this.типПитанияDataGridViewTextBoxColumn3.HeaderText = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn3.Name = "типПитанияDataGridViewTextBoxColumn3";
            this.типПитанияDataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.типПитанияDataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.типПитанияDataGridViewTextBoxColumn3.ValueMember = "Код типа питания";
            // 
            // справочникТиповПитанияBindingSource
            // 
            this.справочникТиповПитанияBindingSource.DataMember = "Справочник типов питания";
            this.справочникТиповПитанияBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // количествоУчащихсяDataGridViewTextBoxColumn
            // 
            this.количествоУчащихсяDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоУчащихсяDataGridViewTextBoxColumn.DataPropertyName = "Количество учащихся";
            this.количествоУчащихсяDataGridViewTextBoxColumn.HeaderText = "Количество учащихся";
            this.количествоУчащихсяDataGridViewTextBoxColumn.Name = "количествоУчащихсяDataGridViewTextBoxColumn";
            // 
            // расходТоваровBindingSource
            // 
            this.расходТоваровBindingSource.DataMember = "Расход товаров";
            this.расходТоваровBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigator12
            // 
            this.bindingNavigator12.AddNewItem = this.toolStripButton1;
            this.bindingNavigator12.BindingSource = this.расходТоваровBindingSource;
            this.bindingNavigator12.CountItem = this.toolStripLabel1;
            this.bindingNavigator12.DeleteItem = this.toolStripButton2;
            this.bindingNavigator12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator12.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton3,
            this.toolStripButton4,
            this.toolStripSeparator11,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator12,
            this.toolStripButton5,
            this.toolStripButton6,
            this.toolStripSeparator13,
            this.toolStripButton1,
            this.toolStripButton2,
            this.toolStripButton7,
            this.toolStripSeparator14});
            this.bindingNavigator12.Location = new System.Drawing.Point(3, 129);
            this.bindingNavigator12.MoveFirstItem = this.toolStripButton3;
            this.bindingNavigator12.MoveLastItem = this.toolStripButton6;
            this.bindingNavigator12.MoveNextItem = this.toolStripButton5;
            this.bindingNavigator12.MovePreviousItem = this.toolStripButton4;
            this.bindingNavigator12.Name = "bindingNavigator12";
            this.bindingNavigator12.PositionItem = this.toolStripTextBox1;
            this.bindingNavigator12.Size = new System.Drawing.Size(670, 25);
            this.bindingNavigator12.TabIndex = 6;
            this.bindingNavigator12.Text = "bindingNavigator12";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeftAutoMirrorImage = true;
            this.toolStripButton1.Size = new System.Drawing.Size(119, 22);
            this.toolStripButton1.Text = "Добавить запись";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel1.Text = "для {0}";
            this.toolStripLabel1.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(111, 22);
            this.toolStripButton2.Text = "Удалить запись";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton3.Text = "Переместить в начало";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton4.Text = "Переместить назад";
            // 
            // toolStripSeparator11
            // 
            this.toolStripSeparator11.Name = "toolStripSeparator11";
            this.toolStripSeparator11.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Положение";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator12
            // 
            this.toolStripSeparator12.Name = "toolStripSeparator12";
            this.toolStripSeparator12.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton5.Text = "Переместить вперед";
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton6.Text = "Переместить в конец";
            // 
            // toolStripSeparator13
            // 
            this.toolStripSeparator13.Name = "toolStripSeparator13";
            this.toolStripSeparator13.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.Size = new System.Drawing.Size(129, 22);
            this.toolStripButton7.Text = "&Сохранить данные";
            this.toolStripButton7.Click += new System.EventHandler(this.toolStripButton7_Click);
            // 
            // toolStripSeparator14
            // 
            this.toolStripSeparator14.Name = "toolStripSeparator14";
            this.toolStripSeparator14.Size = new System.Drawing.Size(6, 25);
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.dataGridView13);
            this.groupBox4.Controls.Add(this.bindingNavigator13);
            this.groupBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.groupBox4.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.groupBox4.Location = new System.Drawing.Point(9, 163);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(670, 208);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Продукты в накладных";
            // 
            // dataGridView13
            // 
            this.dataGridView13.AutoGenerateColumns = false;
            this.dataGridView13.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView13.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.накладнойDataGridViewTextBoxColumn3,
            this.наименованиеПродуктаDataGridViewTextBoxColumn4,
            this.единицаИзмеренияDataGridViewTextBoxColumn3,
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2,
            this.количествоDataGridViewTextBoxColumn5,
            this.общаяСуммаDataGridViewTextBoxColumn1});
            this.dataGridView13.DataSource = this.кРасходуBindingSource;
            this.dataGridView13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView13.Location = new System.Drawing.Point(3, 16);
            this.dataGridView13.Name = "dataGridView13";
            this.dataGridView13.Size = new System.Drawing.Size(664, 164);
            this.dataGridView13.TabIndex = 4;
            // 
            // накладнойDataGridViewTextBoxColumn3
            // 
            this.накладнойDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.накладнойDataGridViewTextBoxColumn3.DataPropertyName = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn3.HeaderText = "№ накладной";
            this.накладнойDataGridViewTextBoxColumn3.Name = "накладнойDataGridViewTextBoxColumn3";
            // 
            // наименованиеПродуктаDataGridViewTextBoxColumn4
            // 
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.DataPropertyName = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.DataSource = this.справочникПродуктовBindingSource;
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.DisplayMember = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.HeaderText = "Наименование продукта";
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.Name = "наименованиеПродуктаDataGridViewTextBoxColumn4";
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.наименованиеПродуктаDataGridViewTextBoxColumn4.ValueMember = "Код продукта";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn3
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.единицаИзмеренияDataGridViewTextBoxColumn3.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn3.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn3.Name = "единицаИзмеренияDataGridViewTextBoxColumn3";
            // 
            // ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2
            // 
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2.DataPropertyName = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2.HeaderText = "Цена за единицу измерения";
            this.ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2.Name = "ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2";
            // 
            // количествоDataGridViewTextBoxColumn5
            // 
            this.количествоDataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn5.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn5.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn5.Name = "количествоDataGridViewTextBoxColumn5";
            // 
            // общаяСуммаDataGridViewTextBoxColumn1
            // 
            this.общаяСуммаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.общаяСуммаDataGridViewTextBoxColumn1.DataPropertyName = "Общая сумма";
            this.общаяСуммаDataGridViewTextBoxColumn1.HeaderText = "Общая сумма";
            this.общаяСуммаDataGridViewTextBoxColumn1.Name = "общаяСуммаDataGridViewTextBoxColumn1";
            // 
            // кРасходуBindingSource
            // 
            this.кРасходуBindingSource.DataMember = "К расходу";
            this.кРасходуBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigator13
            // 
            this.bindingNavigator13.AddNewItem = this.toolStripButton8;
            this.bindingNavigator13.BindingSource = this.кРасходуBindingSource;
            this.bindingNavigator13.CountItem = this.toolStripLabel2;
            this.bindingNavigator13.DeleteItem = this.toolStripButton9;
            this.bindingNavigator13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator13.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton10,
            this.toolStripButton11,
            this.toolStripSeparator15,
            this.toolStripTextBox2,
            this.toolStripLabel2,
            this.toolStripSeparator16,
            this.toolStripButton12,
            this.toolStripButton13,
            this.toolStripSeparator17,
            this.toolStripButton8,
            this.toolStripButton9,
            this.toolStripButton14,
            this.toolStripSeparator18});
            this.bindingNavigator13.Location = new System.Drawing.Point(3, 180);
            this.bindingNavigator13.MoveFirstItem = this.toolStripButton10;
            this.bindingNavigator13.MoveLastItem = this.toolStripButton13;
            this.bindingNavigator13.MoveNextItem = this.toolStripButton12;
            this.bindingNavigator13.MovePreviousItem = this.toolStripButton11;
            this.bindingNavigator13.Name = "bindingNavigator13";
            this.bindingNavigator13.PositionItem = this.toolStripTextBox2;
            this.bindingNavigator13.Size = new System.Drawing.Size(664, 25);
            this.bindingNavigator13.TabIndex = 3;
            this.bindingNavigator13.Text = "bindingNavigator11";
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton8.Image")));
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.RightToLeftAutoMirrorImage = true;
            this.toolStripButton8.Size = new System.Drawing.Size(119, 22);
            this.toolStripButton8.Text = "Добавить запись";
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(43, 22);
            this.toolStripLabel2.Text = "для {0}";
            this.toolStripLabel2.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton9.Image")));
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.RightToLeftAutoMirrorImage = true;
            this.toolStripButton9.Size = new System.Drawing.Size(111, 22);
            this.toolStripButton9.Text = "Удалить запись";
            // 
            // toolStripButton10
            // 
            this.toolStripButton10.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton10.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton10.Image")));
            this.toolStripButton10.Name = "toolStripButton10";
            this.toolStripButton10.RightToLeftAutoMirrorImage = true;
            this.toolStripButton10.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton10.Text = "Переместить в начало";
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.RightToLeftAutoMirrorImage = true;
            this.toolStripButton11.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton11.Text = "Переместить назад";
            // 
            // toolStripSeparator15
            // 
            this.toolStripSeparator15.Name = "toolStripSeparator15";
            this.toolStripSeparator15.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripTextBox2
            // 
            this.toolStripTextBox2.AccessibleName = "Положение";
            this.toolStripTextBox2.AutoSize = false;
            this.toolStripTextBox2.Name = "toolStripTextBox2";
            this.toolStripTextBox2.Size = new System.Drawing.Size(50, 23);
            this.toolStripTextBox2.Text = "0";
            this.toolStripTextBox2.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator16
            // 
            this.toolStripSeparator16.Name = "toolStripSeparator16";
            this.toolStripSeparator16.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.RightToLeftAutoMirrorImage = true;
            this.toolStripButton12.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton12.Text = "Переместить вперед";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.RightToLeftAutoMirrorImage = true;
            this.toolStripButton13.Size = new System.Drawing.Size(23, 22);
            this.toolStripButton13.Text = "Переместить в конец";
            // 
            // toolStripSeparator17
            // 
            this.toolStripSeparator17.Name = "toolStripSeparator17";
            this.toolStripSeparator17.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.Size = new System.Drawing.Size(129, 22);
            this.toolStripButton14.Text = "&Сохранить данные";
            this.toolStripButton14.Click += new System.EventHandler(this.toolStripButton14_Click);
            // 
            // toolStripSeparator18
            // 
            this.toolStripSeparator18.Name = "toolStripSeparator18";
            this.toolStripSeparator18.Size = new System.Drawing.Size(6, 25);
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.bindingNavigator9);
            this.tabPage12.Controls.Add(this.dataGridView9);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage12.Size = new System.Drawing.Size(688, 378);
            this.tabPage12.TabIndex = 2;
            this.tabPage12.Text = "Затраты продуктов на порцию";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator9
            // 
            this.bindingNavigator9.AddNewItem = this.bindingNavigatorAddNewItem8;
            this.bindingNavigator9.BindingSource = this.затратыПродуктовBindingSource;
            this.bindingNavigator9.CountItem = this.bindingNavigatorCountItem8;
            this.bindingNavigator9.DeleteItem = this.bindingNavigatorDeleteItem8;
            this.bindingNavigator9.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator9.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem8,
            this.bindingNavigatorMovePreviousItem8,
            this.bindingNavigatorSeparator24,
            this.bindingNavigatorPositionItem8,
            this.bindingNavigatorCountItem8,
            this.bindingNavigatorSeparator25,
            this.bindingNavigatorMoveNextItem8,
            this.bindingNavigatorMoveLastItem8,
            this.bindingNavigatorSeparator26,
            this.bindingNavigatorAddNewItem8,
            this.bindingNavigatorDeleteItem8,
            this.сохранитьToolStripButton8,
            this.toolStripSeparator9});
            this.bindingNavigator9.Location = new System.Drawing.Point(3, 350);
            this.bindingNavigator9.MoveFirstItem = this.bindingNavigatorMoveFirstItem8;
            this.bindingNavigator9.MoveLastItem = this.bindingNavigatorMoveLastItem8;
            this.bindingNavigator9.MoveNextItem = this.bindingNavigatorMoveNextItem8;
            this.bindingNavigator9.MovePreviousItem = this.bindingNavigatorMovePreviousItem8;
            this.bindingNavigator9.Name = "bindingNavigator9";
            this.bindingNavigator9.PositionItem = this.bindingNavigatorPositionItem8;
            this.bindingNavigator9.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator9.TabIndex = 1;
            this.bindingNavigator9.Text = "bindingNavigator9";
            // 
            // bindingNavigatorAddNewItem8
            // 
            this.bindingNavigatorAddNewItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem8.Image")));
            this.bindingNavigatorAddNewItem8.Name = "bindingNavigatorAddNewItem8";
            this.bindingNavigatorAddNewItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem8.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem8.Text = "Добавить запись";
            // 
            // затратыПродуктовBindingSource
            // 
            this.затратыПродуктовBindingSource.DataMember = "Затраты продуктов";
            this.затратыПродуктовBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigatorCountItem8
            // 
            this.bindingNavigatorCountItem8.Name = "bindingNavigatorCountItem8";
            this.bindingNavigatorCountItem8.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem8.Text = "для {0}";
            this.bindingNavigatorCountItem8.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem8
            // 
            this.bindingNavigatorDeleteItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem8.Image")));
            this.bindingNavigatorDeleteItem8.Name = "bindingNavigatorDeleteItem8";
            this.bindingNavigatorDeleteItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem8.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem8.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem8
            // 
            this.bindingNavigatorMoveFirstItem8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem8.Image")));
            this.bindingNavigatorMoveFirstItem8.Name = "bindingNavigatorMoveFirstItem8";
            this.bindingNavigatorMoveFirstItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem8.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem8.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem8
            // 
            this.bindingNavigatorMovePreviousItem8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem8.Image")));
            this.bindingNavigatorMovePreviousItem8.Name = "bindingNavigatorMovePreviousItem8";
            this.bindingNavigatorMovePreviousItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem8.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem8.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator24
            // 
            this.bindingNavigatorSeparator24.Name = "bindingNavigatorSeparator24";
            this.bindingNavigatorSeparator24.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem8
            // 
            this.bindingNavigatorPositionItem8.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem8.AutoSize = false;
            this.bindingNavigatorPositionItem8.Name = "bindingNavigatorPositionItem8";
            this.bindingNavigatorPositionItem8.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem8.Text = "0";
            this.bindingNavigatorPositionItem8.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator25
            // 
            this.bindingNavigatorSeparator25.Name = "bindingNavigatorSeparator25";
            this.bindingNavigatorSeparator25.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem8
            // 
            this.bindingNavigatorMoveNextItem8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem8.Image")));
            this.bindingNavigatorMoveNextItem8.Name = "bindingNavigatorMoveNextItem8";
            this.bindingNavigatorMoveNextItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem8.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem8.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem8
            // 
            this.bindingNavigatorMoveLastItem8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem8.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem8.Image")));
            this.bindingNavigatorMoveLastItem8.Name = "bindingNavigatorMoveLastItem8";
            this.bindingNavigatorMoveLastItem8.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem8.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem8.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator26
            // 
            this.bindingNavigatorSeparator26.Name = "bindingNavigatorSeparator26";
            this.bindingNavigatorSeparator26.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton8
            // 
            this.сохранитьToolStripButton8.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton8.Image")));
            this.сохранитьToolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton8.Name = "сохранитьToolStripButton8";
            this.сохранитьToolStripButton8.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton8.Text = "&Сохранить данные";
            this.сохранитьToolStripButton8.Click += new System.EventHandler(this.сохранитьToolStripButton8_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(6, 25);
            // 
            // dataGridView9
            // 
            this.dataGridView9.AutoGenerateColumns = false;
            this.dataGridView9.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView9.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаЗатратDataGridViewTextBoxColumn,
            this.продуктDataGridViewTextBoxColumn,
            this.количествоНаПорциюDataGridViewTextBoxColumn,
            this.единицаИзмеренияDataGridViewTextBoxColumn,
            this.ценаDataGridViewTextBoxColumn,
            this.типПитанияDataGridViewTextBoxColumn2});
            this.dataGridView9.DataSource = this.затратыПродуктовBindingSource;
            this.dataGridView9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView9.Location = new System.Drawing.Point(3, 3);
            this.dataGridView9.Name = "dataGridView9";
            this.dataGridView9.Size = new System.Drawing.Size(682, 372);
            this.dataGridView9.TabIndex = 0;
            // 
            // датаЗатратDataGridViewTextBoxColumn
            // 
            this.датаЗатратDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаЗатратDataGridViewTextBoxColumn.DataPropertyName = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn.HeaderText = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn.Name = "датаЗатратDataGridViewTextBoxColumn";
            // 
            // продуктDataGridViewTextBoxColumn
            // 
            this.продуктDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.продуктDataGridViewTextBoxColumn.DataPropertyName = "Продукт";
            this.продуктDataGridViewTextBoxColumn.DataSource = this.справочникПродуктовBindingSource;
            this.продуктDataGridViewTextBoxColumn.DisplayMember = "Наименование продукта";
            this.продуктDataGridViewTextBoxColumn.HeaderText = "Продукт";
            this.продуктDataGridViewTextBoxColumn.Name = "продуктDataGridViewTextBoxColumn";
            this.продуктDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.продуктDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.продуктDataGridViewTextBoxColumn.ValueMember = "Код продукта";
            // 
            // количествоНаПорциюDataGridViewTextBoxColumn
            // 
            this.количествоНаПорциюDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоНаПорциюDataGridViewTextBoxColumn.DataPropertyName = "Количество на порцию ";
            this.количествоНаПорциюDataGridViewTextBoxColumn.HeaderText = "Количество на порцию ";
            this.количествоНаПорциюDataGridViewTextBoxColumn.Name = "количествоНаПорциюDataGridViewTextBoxColumn";
            // 
            // единицаИзмеренияDataGridViewTextBoxColumn
            // 
            this.единицаИзмеренияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.единицаИзмеренияDataGridViewTextBoxColumn.DataPropertyName = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn.HeaderText = "Единица измерения";
            this.единицаИзмеренияDataGridViewTextBoxColumn.Name = "единицаИзмеренияDataGridViewTextBoxColumn";
            // 
            // ценаDataGridViewTextBoxColumn
            // 
            this.ценаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаDataGridViewTextBoxColumn.DataPropertyName = "Цена";
            dataGridViewCellStyle183.Format = "C2";
            dataGridViewCellStyle183.NullValue = null;
            this.ценаDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle183;
            this.ценаDataGridViewTextBoxColumn.HeaderText = "Цена";
            this.ценаDataGridViewTextBoxColumn.Name = "ценаDataGridViewTextBoxColumn";
            // 
            // типПитанияDataGridViewTextBoxColumn2
            // 
            this.типПитанияDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.типПитанияDataGridViewTextBoxColumn2.DataPropertyName = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn2.DataSource = this.справочникТиповПитанияBindingSource;
            this.типПитанияDataGridViewTextBoxColumn2.DisplayMember = "Название типа питания";
            this.типПитанияDataGridViewTextBoxColumn2.HeaderText = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn2.Name = "типПитанияDataGridViewTextBoxColumn2";
            this.типПитанияDataGridViewTextBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.типПитанияDataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.типПитанияDataGridViewTextBoxColumn2.ValueMember = "Код типа питания";
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.tabControl4);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(708, 416);
            this.tabPage9.TabIndex = 2;
            this.tabPage9.Text = "Продукты";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage13);
            this.tabControl1.Controls.Add(this.tabPage16);
            this.tabControl1.Location = new System.Drawing.Point(196, 18);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(716, 442);
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.tabControl5);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(708, 416);
            this.tabPage13.TabIndex = 3;
            this.tabPage13.Text = "Питание";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // tabControl5
            // 
            this.tabControl5.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl5.Controls.Add(this.tabPage14);
            this.tabControl5.Controls.Add(this.tabPage15);
            this.tabControl5.Location = new System.Drawing.Point(6, 6);
            this.tabControl5.Name = "tabControl5";
            this.tabControl5.SelectedIndex = 0;
            this.tabControl5.Size = new System.Drawing.Size(696, 404);
            this.tabControl5.TabIndex = 0;
            // 
            // tabPage14
            // 
            this.tabPage14.Controls.Add(this.dataGridView7);
            this.tabPage14.Controls.Add(this.bindingNavigator7);
            this.tabPage14.Location = new System.Drawing.Point(4, 22);
            this.tabPage14.Name = "tabPage14";
            this.tabPage14.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage14.Size = new System.Drawing.Size(688, 378);
            this.tabPage14.TabIndex = 0;
            this.tabPage14.Text = "Питание учителей";
            this.tabPage14.UseVisualStyleBackColor = true;
            // 
            // dataGridView7
            // 
            this.dataGridView7.AutoGenerateColumns = false;
            this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView7.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.фИОУчителяDataGridViewTextBoxColumn1,
            this.датаDataGridViewTextBoxColumn,
            this.типПитанияDataGridViewTextBoxColumn,
            this.количествоDataGridViewTextBoxColumn,
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn});
            this.dataGridView7.DataSource = this.питаниеУчителейBindingSource;
            this.dataGridView7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView7.Location = new System.Drawing.Point(3, 3);
            this.dataGridView7.Name = "dataGridView7";
            this.dataGridView7.Size = new System.Drawing.Size(682, 347);
            this.dataGridView7.TabIndex = 2;
            // 
            // фИОУчителяDataGridViewTextBoxColumn1
            // 
            this.фИОУчителяDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУчителяDataGridViewTextBoxColumn1.DataPropertyName = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn1.DataSource = this.учителяШколыBindingSource;
            this.фИОУчителяDataGridViewTextBoxColumn1.DisplayMember = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn1.HeaderText = "ФИО учителя";
            this.фИОУчителяDataGridViewTextBoxColumn1.Name = "фИОУчителяDataGridViewTextBoxColumn1";
            this.фИОУчителяDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.фИОУчителяDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.фИОУчителяDataGridViewTextBoxColumn1.ValueMember = "Код учителя";
            // 
            // учителяШколыBindingSource
            // 
            this.учителяШколыBindingSource.DataMember = "Учителя школы";
            this.учителяШколыBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // датаDataGridViewTextBoxColumn
            // 
            this.датаDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаDataGridViewTextBoxColumn.DataPropertyName = "Дата";
            dataGridViewCellStyle184.Format = "D";
            dataGridViewCellStyle184.NullValue = null;
            this.датаDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle184;
            this.датаDataGridViewTextBoxColumn.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn.Name = "датаDataGridViewTextBoxColumn";
            // 
            // типПитанияDataGridViewTextBoxColumn
            // 
            this.типПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.типПитанияDataGridViewTextBoxColumn.DataPropertyName = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn.DataSource = this.справочникТиповПитанияBindingSource;
            this.типПитанияDataGridViewTextBoxColumn.DisplayMember = "Название типа питания";
            this.типПитанияDataGridViewTextBoxColumn.HeaderText = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn.Name = "типПитанияDataGridViewTextBoxColumn";
            this.типПитанияDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.типПитанияDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.типПитанияDataGridViewTextBoxColumn.ValueMember = "Код типа питания";
            // 
            // количествоDataGridViewTextBoxColumn
            // 
            this.количествоDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn.Name = "количествоDataGridViewTextBoxColumn";
            // 
            // стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn
            // 
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Стоимость единицы типа питания";
            dataGridViewCellStyle185.Format = "C2";
            dataGridViewCellStyle185.NullValue = null;
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle185;
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Стоимость единицы типа питания";
            this.стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn.Name = "стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn";
            // 
            // питаниеУчителейBindingSource
            // 
            this.питаниеУчителейBindingSource.DataMember = "Питание учителей";
            this.питаниеУчителейBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigator7
            // 
            this.bindingNavigator7.AddNewItem = this.bindingNavigatorAddNewItem6;
            this.bindingNavigator7.BindingSource = this.питаниеУчителейBindingSource;
            this.bindingNavigator7.CountItem = this.bindingNavigatorCountItem6;
            this.bindingNavigator7.DeleteItem = this.bindingNavigatorDeleteItem6;
            this.bindingNavigator7.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator7.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem6,
            this.bindingNavigatorMovePreviousItem6,
            this.bindingNavigatorSeparator18,
            this.bindingNavigatorPositionItem6,
            this.bindingNavigatorCountItem6,
            this.bindingNavigatorSeparator19,
            this.bindingNavigatorMoveNextItem6,
            this.bindingNavigatorMoveLastItem6,
            this.bindingNavigatorSeparator20,
            this.bindingNavigatorAddNewItem6,
            this.bindingNavigatorDeleteItem6,
            this.сохранитьToolStripButton6,
            this.toolStripSeparator6});
            this.bindingNavigator7.Location = new System.Drawing.Point(3, 350);
            this.bindingNavigator7.MoveFirstItem = this.bindingNavigatorMoveFirstItem6;
            this.bindingNavigator7.MoveLastItem = this.bindingNavigatorMoveLastItem6;
            this.bindingNavigator7.MoveNextItem = this.bindingNavigatorMoveNextItem6;
            this.bindingNavigator7.MovePreviousItem = this.bindingNavigatorMovePreviousItem6;
            this.bindingNavigator7.Name = "bindingNavigator7";
            this.bindingNavigator7.PositionItem = this.bindingNavigatorPositionItem6;
            this.bindingNavigator7.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator7.TabIndex = 1;
            this.bindingNavigator7.Text = "bindingNavigator7";
            // 
            // bindingNavigatorAddNewItem6
            // 
            this.bindingNavigatorAddNewItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem6.Image")));
            this.bindingNavigatorAddNewItem6.Name = "bindingNavigatorAddNewItem6";
            this.bindingNavigatorAddNewItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem6.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem6.Text = "Добавить запись";
            // 
            // bindingNavigatorCountItem6
            // 
            this.bindingNavigatorCountItem6.Name = "bindingNavigatorCountItem6";
            this.bindingNavigatorCountItem6.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem6.Text = "для {0}";
            this.bindingNavigatorCountItem6.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem6
            // 
            this.bindingNavigatorDeleteItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem6.Image")));
            this.bindingNavigatorDeleteItem6.Name = "bindingNavigatorDeleteItem6";
            this.bindingNavigatorDeleteItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem6.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem6.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem6
            // 
            this.bindingNavigatorMoveFirstItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem6.Image")));
            this.bindingNavigatorMoveFirstItem6.Name = "bindingNavigatorMoveFirstItem6";
            this.bindingNavigatorMoveFirstItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem6.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem6.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem6
            // 
            this.bindingNavigatorMovePreviousItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem6.Image")));
            this.bindingNavigatorMovePreviousItem6.Name = "bindingNavigatorMovePreviousItem6";
            this.bindingNavigatorMovePreviousItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem6.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem6.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator18
            // 
            this.bindingNavigatorSeparator18.Name = "bindingNavigatorSeparator18";
            this.bindingNavigatorSeparator18.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem6
            // 
            this.bindingNavigatorPositionItem6.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem6.AutoSize = false;
            this.bindingNavigatorPositionItem6.Name = "bindingNavigatorPositionItem6";
            this.bindingNavigatorPositionItem6.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem6.Text = "0";
            this.bindingNavigatorPositionItem6.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator19
            // 
            this.bindingNavigatorSeparator19.Name = "bindingNavigatorSeparator19";
            this.bindingNavigatorSeparator19.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem6
            // 
            this.bindingNavigatorMoveNextItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem6.Image")));
            this.bindingNavigatorMoveNextItem6.Name = "bindingNavigatorMoveNextItem6";
            this.bindingNavigatorMoveNextItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem6.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem6.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem6
            // 
            this.bindingNavigatorMoveLastItem6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem6.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem6.Image")));
            this.bindingNavigatorMoveLastItem6.Name = "bindingNavigatorMoveLastItem6";
            this.bindingNavigatorMoveLastItem6.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem6.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem6.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator20
            // 
            this.bindingNavigatorSeparator20.Name = "bindingNavigatorSeparator20";
            this.bindingNavigatorSeparator20.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton6
            // 
            this.сохранитьToolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton6.Image")));
            this.сохранитьToolStripButton6.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton6.Name = "сохранитьToolStripButton6";
            this.сохранитьToolStripButton6.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton6.Text = "&Сохранить данные";
            this.сохранитьToolStripButton6.Click += new System.EventHandler(this.сохранитьToolStripButton6_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 25);
            // 
            // tabPage15
            // 
            this.tabPage15.Controls.Add(this.bindingNavigator8);
            this.tabPage15.Controls.Add(this.dataGridView8);
            this.tabPage15.Location = new System.Drawing.Point(4, 22);
            this.tabPage15.Name = "tabPage15";
            this.tabPage15.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage15.Size = new System.Drawing.Size(688, 378);
            this.tabPage15.TabIndex = 1;
            this.tabPage15.Text = "Питание учащихся";
            this.tabPage15.UseVisualStyleBackColor = true;
            // 
            // bindingNavigator8
            // 
            this.bindingNavigator8.AddNewItem = this.bindingNavigatorAddNewItem7;
            this.bindingNavigator8.BindingSource = this.питаниеУчениковBindingSource;
            this.bindingNavigator8.CountItem = this.bindingNavigatorCountItem7;
            this.bindingNavigator8.DeleteItem = this.bindingNavigatorDeleteItem7;
            this.bindingNavigator8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator8.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem7,
            this.bindingNavigatorMovePreviousItem7,
            this.bindingNavigatorSeparator21,
            this.bindingNavigatorPositionItem7,
            this.bindingNavigatorCountItem7,
            this.bindingNavigatorSeparator22,
            this.bindingNavigatorMoveNextItem7,
            this.bindingNavigatorMoveLastItem7,
            this.bindingNavigatorSeparator23,
            this.bindingNavigatorAddNewItem7,
            this.bindingNavigatorDeleteItem7,
            this.сохранитьToolStripButton7,
            this.toolStripSeparator7});
            this.bindingNavigator8.Location = new System.Drawing.Point(3, 350);
            this.bindingNavigator8.MoveFirstItem = this.bindingNavigatorMoveFirstItem7;
            this.bindingNavigator8.MoveLastItem = this.bindingNavigatorMoveLastItem7;
            this.bindingNavigator8.MoveNextItem = this.bindingNavigatorMoveNextItem7;
            this.bindingNavigator8.MovePreviousItem = this.bindingNavigatorMovePreviousItem7;
            this.bindingNavigator8.Name = "bindingNavigator8";
            this.bindingNavigator8.PositionItem = this.bindingNavigatorPositionItem7;
            this.bindingNavigator8.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator8.TabIndex = 1;
            this.bindingNavigator8.Text = "bindingNavigator8";
            // 
            // bindingNavigatorAddNewItem7
            // 
            this.bindingNavigatorAddNewItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem7.Image")));
            this.bindingNavigatorAddNewItem7.Name = "bindingNavigatorAddNewItem7";
            this.bindingNavigatorAddNewItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem7.Size = new System.Drawing.Size(119, 22);
            this.bindingNavigatorAddNewItem7.Text = "Добавить запись";
            // 
            // питаниеУчениковBindingSource
            // 
            this.питаниеУчениковBindingSource.DataMember = "Питание учеников";
            this.питаниеУчениковBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigatorCountItem7
            // 
            this.bindingNavigatorCountItem7.Name = "bindingNavigatorCountItem7";
            this.bindingNavigatorCountItem7.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem7.Text = "для {0}";
            this.bindingNavigatorCountItem7.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem7
            // 
            this.bindingNavigatorDeleteItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem7.Image")));
            this.bindingNavigatorDeleteItem7.Name = "bindingNavigatorDeleteItem7";
            this.bindingNavigatorDeleteItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem7.Size = new System.Drawing.Size(111, 22);
            this.bindingNavigatorDeleteItem7.Text = "Удалить запись";
            // 
            // bindingNavigatorMoveFirstItem7
            // 
            this.bindingNavigatorMoveFirstItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem7.Image")));
            this.bindingNavigatorMoveFirstItem7.Name = "bindingNavigatorMoveFirstItem7";
            this.bindingNavigatorMoveFirstItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem7.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem7.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem7
            // 
            this.bindingNavigatorMovePreviousItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem7.Image")));
            this.bindingNavigatorMovePreviousItem7.Name = "bindingNavigatorMovePreviousItem7";
            this.bindingNavigatorMovePreviousItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem7.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem7.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator21
            // 
            this.bindingNavigatorSeparator21.Name = "bindingNavigatorSeparator21";
            this.bindingNavigatorSeparator21.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem7
            // 
            this.bindingNavigatorPositionItem7.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem7.AutoSize = false;
            this.bindingNavigatorPositionItem7.Name = "bindingNavigatorPositionItem7";
            this.bindingNavigatorPositionItem7.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem7.Text = "0";
            this.bindingNavigatorPositionItem7.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator22
            // 
            this.bindingNavigatorSeparator22.Name = "bindingNavigatorSeparator22";
            this.bindingNavigatorSeparator22.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem7
            // 
            this.bindingNavigatorMoveNextItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem7.Image")));
            this.bindingNavigatorMoveNextItem7.Name = "bindingNavigatorMoveNextItem7";
            this.bindingNavigatorMoveNextItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem7.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem7.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem7
            // 
            this.bindingNavigatorMoveLastItem7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem7.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem7.Image")));
            this.bindingNavigatorMoveLastItem7.Name = "bindingNavigatorMoveLastItem7";
            this.bindingNavigatorMoveLastItem7.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem7.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem7.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator23
            // 
            this.bindingNavigatorSeparator23.Name = "bindingNavigatorSeparator23";
            this.bindingNavigatorSeparator23.Size = new System.Drawing.Size(6, 25);
            // 
            // сохранитьToolStripButton7
            // 
            this.сохранитьToolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("сохранитьToolStripButton7.Image")));
            this.сохранитьToolStripButton7.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.сохранитьToolStripButton7.Name = "сохранитьToolStripButton7";
            this.сохранитьToolStripButton7.Size = new System.Drawing.Size(129, 22);
            this.сохранитьToolStripButton7.Text = "&Сохранить данные";
            this.сохранитьToolStripButton7.Click += new System.EventHandler(this.сохранитьToolStripButton7_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 25);
            // 
            // dataGridView8
            // 
            this.dataGridView8.AutoGenerateColumns = false;
            this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView8.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.фИОУченикаDataGridViewTextBoxColumn1,
            this.датаDataGridViewTextBoxColumn1,
            this.типПитанияDataGridViewTextBoxColumn1,
            this.количествоDataGridViewTextBoxColumn1,
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn,
            this.классDataGridViewTextBoxColumn1});
            this.dataGridView8.DataSource = this.питаниеУчениковBindingSource;
            this.dataGridView8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView8.Location = new System.Drawing.Point(3, 3);
            this.dataGridView8.Name = "dataGridView8";
            this.dataGridView8.Size = new System.Drawing.Size(682, 372);
            this.dataGridView8.TabIndex = 0;
            // 
            // фИОУченикаDataGridViewTextBoxColumn1
            // 
            this.фИОУченикаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.фИОУченикаDataGridViewTextBoxColumn1.DataPropertyName = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn1.DataSource = this.ученикиШколыBindingSource;
            this.фИОУченикаDataGridViewTextBoxColumn1.DisplayMember = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn1.HeaderText = "ФИО ученика";
            this.фИОУченикаDataGridViewTextBoxColumn1.Name = "фИОУченикаDataGridViewTextBoxColumn1";
            this.фИОУченикаDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.фИОУченикаDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.фИОУченикаDataGridViewTextBoxColumn1.ValueMember = "Код ученика";
            // 
            // ученикиШколыBindingSource
            // 
            this.ученикиШколыBindingSource.DataMember = "Ученики школы";
            this.ученикиШколыBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // датаDataGridViewTextBoxColumn1
            // 
            this.датаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаDataGridViewTextBoxColumn1.DataPropertyName = "Дата";
            dataGridViewCellStyle186.Format = "D";
            dataGridViewCellStyle186.NullValue = null;
            this.датаDataGridViewTextBoxColumn1.DefaultCellStyle = dataGridViewCellStyle186;
            this.датаDataGridViewTextBoxColumn1.HeaderText = "Дата";
            this.датаDataGridViewTextBoxColumn1.Name = "датаDataGridViewTextBoxColumn1";
            // 
            // типПитанияDataGridViewTextBoxColumn1
            // 
            this.типПитанияDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.типПитанияDataGridViewTextBoxColumn1.DataPropertyName = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn1.DataSource = this.справочникТиповПитанияBindingSource1;
            this.типПитанияDataGridViewTextBoxColumn1.DisplayMember = "Название типа питания";
            this.типПитанияDataGridViewTextBoxColumn1.HeaderText = "Тип питания";
            this.типПитанияDataGridViewTextBoxColumn1.Name = "типПитанияDataGridViewTextBoxColumn1";
            this.типПитанияDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.типПитанияDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.типПитанияDataGridViewTextBoxColumn1.ValueMember = "Код типа питания";
            // 
            // справочникТиповПитанияBindingSource1
            // 
            this.справочникТиповПитанияBindingSource1.DataMember = "Справочник типов питания";
            this.справочникТиповПитанияBindingSource1.DataSource = this.schoolFoodDataSet;
            // 
            // количествоDataGridViewTextBoxColumn1
            // 
            this.количествоDataGridViewTextBoxColumn1.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn1.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn1.Name = "количествоDataGridViewTextBoxColumn1";
            // 
            // ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn
            // 
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Цена единицы типа питания";
            dataGridViewCellStyle187.Format = "C2";
            dataGridViewCellStyle187.NullValue = null;
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.DefaultCellStyle = dataGridViewCellStyle187;
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Цена единицы типа питания";
            this.ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn.Name = "ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn";
            // 
            // классDataGridViewTextBoxColumn1
            // 
            this.классDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.классDataGridViewTextBoxColumn1.DataPropertyName = "Класс";
            this.классDataGridViewTextBoxColumn1.DataSource = this.справочникКлассовBindingSource;
            this.классDataGridViewTextBoxColumn1.DisplayMember = "Название класса";
            this.классDataGridViewTextBoxColumn1.HeaderText = "Класс";
            this.классDataGridViewTextBoxColumn1.Name = "классDataGridViewTextBoxColumn1";
            this.классDataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.классDataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.классDataGridViewTextBoxColumn1.ValueMember = "Код класса";
            // 
            // справочникКлассовBindingSource
            // 
            this.справочникКлассовBindingSource.DataMember = "Справочник классов";
            this.справочникКлассовBindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // tabPage16
            // 
            this.tabPage16.Controls.Add(this.tabControl6);
            this.tabPage16.Location = new System.Drawing.Point(4, 22);
            this.tabPage16.Name = "tabPage16";
            this.tabPage16.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage16.Size = new System.Drawing.Size(708, 416);
            this.tabPage16.TabIndex = 4;
            this.tabPage16.Text = "Отчеты";
            this.tabPage16.UseVisualStyleBackColor = true;
            // 
            // tabControl6
            // 
            this.tabControl6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl6.Controls.Add(this.tabPage17);
            this.tabControl6.Controls.Add(this.tabPage18);
            this.tabControl6.Controls.Add(this.tabPage1);
            this.tabControl6.Controls.Add(this.tabPage19);
            this.tabControl6.Controls.Add(this.tabPage20);
            this.tabControl6.Controls.Add(this.tabPage21);
            this.tabControl6.Controls.Add(this.tabPage22);
            this.tabControl6.Controls.Add(this.tabPage23);
            this.tabControl6.Location = new System.Drawing.Point(6, 6);
            this.tabControl6.Multiline = true;
            this.tabControl6.Name = "tabControl6";
            this.tabControl6.SelectedIndex = 0;
            this.tabControl6.Size = new System.Drawing.Size(696, 404);
            this.tabControl6.TabIndex = 0;
            // 
            // tabPage17
            // 
            this.tabPage17.AutoScroll = true;
            this.tabPage17.Controls.Add(this.toolStrip1);
            this.tabPage17.Controls.Add(this.fillBy3ToolStrip);
            this.tabPage17.Controls.Add(this.fillBy2ToolStrip);
            this.tabPage17.Controls.Add(this.dataGridView17);
            this.tabPage17.Controls.Add(this.bindingNavigator18);
            this.tabPage17.Location = new System.Drawing.Point(4, 58);
            this.tabPage17.Name = "tabPage17";
            this.tabPage17.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage17.Size = new System.Drawing.Size(688, 342);
            this.tabPage17.TabIndex = 0;
            this.tabPage17.Text = "Ведомость о питании по классам за месяц";
            this.tabPage17.UseVisualStyleBackColor = true;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton23});
            this.toolStrip1.Location = new System.Drawing.Point(3, 239);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(682, 25);
            this.toolStrip1.TabIndex = 16;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripButton23
            // 
            this.toolStripButton23.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton23.Name = "toolStripButton23";
            this.toolStripButton23.Size = new System.Drawing.Size(71, 22);
            this.toolStripButton23.Text = "Все записи";
            this.toolStripButton23.Click += new System.EventHandler(this.fillToolStripButton_Click);
            // 
            // fillBy3ToolStrip
            // 
            this.fillBy3ToolStrip.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fillBy3ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel1,
            this.param1ToolStripTextBox1,
            this.param2ToolStripLabel,
            this.param2ToolStripTextBox,
            this.fillBy3ToolStripButton});
            this.fillBy3ToolStrip.Location = new System.Drawing.Point(3, 264);
            this.fillBy3ToolStrip.Name = "fillBy3ToolStrip";
            this.fillBy3ToolStrip.Size = new System.Drawing.Size(682, 25);
            this.fillBy3ToolStrip.TabIndex = 15;
            this.fillBy3ToolStrip.Text = "fillBy3ToolStrip";
            // 
            // param1ToolStripLabel1
            // 
            this.param1ToolStripLabel1.Name = "param1ToolStripLabel1";
            this.param1ToolStripLabel1.Size = new System.Drawing.Size(43, 22);
            this.param1ToolStripLabel1.Text = "Месяц";
            // 
            // param1ToolStripTextBox1
            // 
            this.param1ToolStripTextBox1.Name = "param1ToolStripTextBox1";
            this.param1ToolStripTextBox1.Size = new System.Drawing.Size(100, 25);
            // 
            // param2ToolStripLabel
            // 
            this.param2ToolStripLabel.Name = "param2ToolStripLabel";
            this.param2ToolStripLabel.Size = new System.Drawing.Size(29, 22);
            this.param2ToolStripLabel.Text = "Год:";
            // 
            // param2ToolStripTextBox
            // 
            this.param2ToolStripTextBox.Name = "param2ToolStripTextBox";
            this.param2ToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // fillBy3ToolStripButton
            // 
            this.fillBy3ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy3ToolStripButton.Name = "fillBy3ToolStripButton";
            this.fillBy3ToolStripButton.Size = new System.Drawing.Size(52, 22);
            this.fillBy3ToolStripButton.Text = "Фильтр";
            this.fillBy3ToolStripButton.Click += new System.EventHandler(this.fillBy3ToolStripButton_Click);
            // 
            // fillBy2ToolStrip
            // 
            this.fillBy2ToolStrip.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.fillBy2ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.param1ToolStripLabel3,
            this.param1ToolStripTextBox3,
            this.fillBy2ToolStripButton});
            this.fillBy2ToolStrip.Location = new System.Drawing.Point(3, 289);
            this.fillBy2ToolStrip.Name = "fillBy2ToolStrip";
            this.fillBy2ToolStrip.Size = new System.Drawing.Size(682, 25);
            this.fillBy2ToolStrip.TabIndex = 13;
            this.fillBy2ToolStrip.Text = "fillBy2ToolStrip";
            // 
            // param1ToolStripLabel3
            // 
            this.param1ToolStripLabel3.Name = "param1ToolStripLabel3";
            this.param1ToolStripLabel3.Size = new System.Drawing.Size(42, 22);
            this.param1ToolStripLabel3.Text = "Класс:";
            // 
            // param1ToolStripTextBox3
            // 
            this.param1ToolStripTextBox3.Name = "param1ToolStripTextBox3";
            this.param1ToolStripTextBox3.Size = new System.Drawing.Size(100, 25);
            // 
            // fillBy2ToolStripButton
            // 
            this.fillBy2ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy2ToolStripButton.Name = "fillBy2ToolStripButton";
            this.fillBy2ToolStripButton.Size = new System.Drawing.Size(52, 22);
            this.fillBy2ToolStripButton.Text = "Фильтр";
            this.fillBy2ToolStripButton.Click += new System.EventHandler(this.fillBy2ToolStripButton_Click);
            // 
            // dataGridView17
            // 
            this.dataGridView17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView17.AutoGenerateColumns = false;
            this.dataGridView17.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView17.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Месяц,
            this.Год,
            this.названиеКлассаDataGridViewTextBoxColumn1,
            this.названиеТипаПитанияDataGridViewTextBoxColumn1,
            this.количествоDataGridViewTextBoxColumn6,
            this.ценаПитанияDataGridViewTextBoxColumn});
            this.dataGridView17.DataSource = this.view51BindingSource;
            this.dataGridView17.Location = new System.Drawing.Point(3, 3);
            this.dataGridView17.Name = "dataGridView17";
            this.dataGridView17.Size = new System.Drawing.Size(682, 233);
            this.dataGridView17.TabIndex = 2;
            // 
            // Месяц
            // 
            this.Месяц.DataPropertyName = "Месяц";
            this.Месяц.HeaderText = "Месяц";
            this.Месяц.Name = "Месяц";
            this.Месяц.ReadOnly = true;
            // 
            // Год
            // 
            this.Год.DataPropertyName = "Год";
            this.Год.HeaderText = "Год";
            this.Год.Name = "Год";
            this.Год.ReadOnly = true;
            // 
            // названиеКлассаDataGridViewTextBoxColumn1
            // 
            this.названиеКлассаDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеКлассаDataGridViewTextBoxColumn1.DataPropertyName = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn1.HeaderText = "Название класса";
            this.названиеКлассаDataGridViewTextBoxColumn1.Name = "названиеКлассаDataGridViewTextBoxColumn1";
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn1
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn1.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn1.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn1.Name = "названиеТипаПитанияDataGridViewTextBoxColumn1";
            // 
            // количествоDataGridViewTextBoxColumn6
            // 
            this.количествоDataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.количествоDataGridViewTextBoxColumn6.DataPropertyName = "Количество";
            this.количествоDataGridViewTextBoxColumn6.HeaderText = "Количество";
            this.количествоDataGridViewTextBoxColumn6.Name = "количествоDataGridViewTextBoxColumn6";
            // 
            // ценаПитанияDataGridViewTextBoxColumn
            // 
            this.ценаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ценаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Цена питания";
            this.ценаПитанияDataGridViewTextBoxColumn.HeaderText = "Цена питания";
            this.ценаПитанияDataGridViewTextBoxColumn.Name = "ценаПитанияDataGridViewTextBoxColumn";
            // 
            // view51BindingSource
            // 
            this.view51BindingSource.DataMember = "View51";
            this.view51BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // bindingNavigator18
            // 
            this.bindingNavigator18.AddNewItem = null;
            this.bindingNavigator18.BindingSource = this.view51BindingSource;
            this.bindingNavigator18.CountItem = this.bindingNavigatorCountItem15;
            this.bindingNavigator18.DeleteItem = null;
            this.bindingNavigator18.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator18.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem15,
            this.bindingNavigatorMovePreviousItem15,
            this.bindingNavigatorSeparator45,
            this.bindingNavigatorPositionItem15,
            this.bindingNavigatorCountItem15,
            this.bindingNavigatorSeparator46,
            this.bindingNavigatorMoveNextItem15,
            this.bindingNavigatorMoveLastItem15,
            this.bindingNavigatorSeparator47,
            this.toolStripButton15,
            this.toolStripButton22});
            this.bindingNavigator18.Location = new System.Drawing.Point(3, 314);
            this.bindingNavigator18.MoveFirstItem = this.bindingNavigatorMoveFirstItem15;
            this.bindingNavigator18.MoveLastItem = this.bindingNavigatorMoveLastItem15;
            this.bindingNavigator18.MoveNextItem = this.bindingNavigatorMoveNextItem15;
            this.bindingNavigator18.MovePreviousItem = this.bindingNavigatorMovePreviousItem15;
            this.bindingNavigator18.Name = "bindingNavigator18";
            this.bindingNavigator18.PositionItem = this.bindingNavigatorPositionItem15;
            this.bindingNavigator18.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator18.TabIndex = 0;
            this.bindingNavigator18.Text = "bindingNavigator18";
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.Size = new System.Drawing.Size(125, 22);
            this.toolStripButton15.Text = "Обновить данные";
            this.toolStripButton15.Click += new System.EventHandler(this.toolStripButton15_Click);
            // 
            // toolStripButton22
            // 
            this.toolStripButton22.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton22.Image")));
            this.toolStripButton22.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton22.Name = "toolStripButton22";
            this.toolStripButton22.Size = new System.Drawing.Size(110, 22);
            this.toolStripButton22.Text = "Экспорт в Excel";
            this.toolStripButton22.Click += new System.EventHandler(this.toolStripButton22_Click);
            // 
            // dataGridViewComboBoxColumn1
            // 
            this.dataGridViewComboBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn1.DataPropertyName = "Наименование продукта";
            this.dataGridViewComboBoxColumn1.DataSource = this.справочникПродуктовBindingSource;
            this.dataGridViewComboBoxColumn1.DisplayMember = "Наименование продукта";
            this.dataGridViewComboBoxColumn1.HeaderText = "Наименование продукта";
            this.dataGridViewComboBoxColumn1.Name = "dataGridViewComboBoxColumn1";
            this.dataGridViewComboBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn1.ValueMember = "Код продукта";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "№ накладной";
            dataGridViewCellStyle188.Format = "C2";
            dataGridViewCellStyle188.NullValue = null;
            this.dataGridViewTextBoxColumn3.DefaultCellStyle = dataGridViewCellStyle188;
            this.dataGridViewTextBoxColumn3.HeaderText = "№ накладной";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn4.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle189.Format = "C2";
            dataGridViewCellStyle189.NullValue = null;
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle189;
            this.dataGridViewTextBoxColumn5.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Количество";
            dataGridViewCellStyle190.Format = "D";
            dataGridViewCellStyle190.NullValue = null;
            this.dataGridViewTextBoxColumn6.DefaultCellStyle = dataGridViewCellStyle190;
            this.dataGridViewTextBoxColumn6.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewComboBoxColumn2
            // 
            this.dataGridViewComboBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn2.DataPropertyName = "Наименование продукта";
            this.dataGridViewComboBoxColumn2.DataSource = this.справочникПродуктовBindingSource;
            this.dataGridViewComboBoxColumn2.DisplayMember = "Наименование продукта";
            this.dataGridViewComboBoxColumn2.HeaderText = "Наименование продукта";
            this.dataGridViewComboBoxColumn2.Name = "dataGridViewComboBoxColumn2";
            this.dataGridViewComboBoxColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn2.ValueMember = "Код продукта";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn7.DataPropertyName = "№ накладной";
            this.dataGridViewTextBoxColumn7.HeaderText = "№ накладной";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Дата расхода";
            dataGridViewCellStyle191.Format = "D";
            dataGridViewCellStyle191.NullValue = null;
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle191;
            this.dataGridViewTextBoxColumn8.HeaderText = "Дата расхода";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewComboBoxColumn3
            // 
            this.dataGridViewComboBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn3.DataPropertyName = "Тип питания";
            this.dataGridViewComboBoxColumn3.DataSource = this.справочникТиповПитанияBindingSource;
            this.dataGridViewComboBoxColumn3.DisplayMember = "Название типа питания";
            this.dataGridViewComboBoxColumn3.HeaderText = "Тип питания";
            this.dataGridViewComboBoxColumn3.Name = "dataGridViewComboBoxColumn3";
            this.dataGridViewComboBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn3.ValueMember = "Код типа питания";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Количество учащихся";
            this.dataGridViewTextBoxColumn9.HeaderText = "Количество учащихся";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn10.DataPropertyName = "№ накладной";
            this.dataGridViewTextBoxColumn10.HeaderText = "№ накладной";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewComboBoxColumn4
            // 
            this.dataGridViewComboBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn4.DataPropertyName = "Наименование продукта";
            this.dataGridViewComboBoxColumn4.DataSource = this.справочникПродуктовBindingSource;
            this.dataGridViewComboBoxColumn4.DisplayMember = "Наименование продукта";
            this.dataGridViewComboBoxColumn4.HeaderText = "Наименование продукта";
            this.dataGridViewComboBoxColumn4.Name = "dataGridViewComboBoxColumn4";
            this.dataGridViewComboBoxColumn4.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn4.ValueMember = "Код продукта";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn11.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn12.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn13.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Общая сумма";
            this.dataGridViewTextBoxColumn14.HeaderText = "Общая сумма";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Дата затрат";
            this.dataGridViewTextBoxColumn15.HeaderText = "Дата затрат";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewComboBoxColumn5
            // 
            this.dataGridViewComboBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn5.DataPropertyName = "Продукт";
            this.dataGridViewComboBoxColumn5.DataSource = this.справочникПродуктовBindingSource;
            this.dataGridViewComboBoxColumn5.DisplayMember = "Наименование продукта";
            this.dataGridViewComboBoxColumn5.HeaderText = "Продукт";
            this.dataGridViewComboBoxColumn5.Name = "dataGridViewComboBoxColumn5";
            this.dataGridViewComboBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn5.ValueMember = "Код продукта";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Количество на порцию ";
            this.dataGridViewTextBoxColumn16.HeaderText = "Количество на порцию ";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn17.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Цена";
            dataGridViewCellStyle192.Format = "C2";
            dataGridViewCellStyle192.NullValue = null;
            this.dataGridViewTextBoxColumn18.DefaultCellStyle = dataGridViewCellStyle192;
            this.dataGridViewTextBoxColumn18.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewComboBoxColumn6
            // 
            this.dataGridViewComboBoxColumn6.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn6.DataPropertyName = "Тип питания";
            this.dataGridViewComboBoxColumn6.DataSource = this.справочникТиповПитанияBindingSource;
            this.dataGridViewComboBoxColumn6.DisplayMember = "Название типа питания";
            this.dataGridViewComboBoxColumn6.HeaderText = "Тип питания";
            this.dataGridViewComboBoxColumn6.Name = "dataGridViewComboBoxColumn6";
            this.dataGridViewComboBoxColumn6.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn6.ValueMember = "Код типа питания";
            // 
            // dataGridViewComboBoxColumn7
            // 
            this.dataGridViewComboBoxColumn7.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn7.DataPropertyName = "ФИО учителя";
            this.dataGridViewComboBoxColumn7.DataSource = this.учителяШколыBindingSource;
            this.dataGridViewComboBoxColumn7.DisplayMember = "ФИО учителя";
            this.dataGridViewComboBoxColumn7.HeaderText = "ФИО учителя";
            this.dataGridViewComboBoxColumn7.Name = "dataGridViewComboBoxColumn7";
            this.dataGridViewComboBoxColumn7.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn7.ValueMember = "Код учителя";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Дата";
            dataGridViewCellStyle193.Format = "D";
            dataGridViewCellStyle193.NullValue = null;
            this.dataGridViewTextBoxColumn19.DefaultCellStyle = dataGridViewCellStyle193;
            this.dataGridViewTextBoxColumn19.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewComboBoxColumn8
            // 
            this.dataGridViewComboBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn8.DataPropertyName = "Тип питания";
            this.dataGridViewComboBoxColumn8.DataSource = this.справочникТиповПитанияBindingSource;
            this.dataGridViewComboBoxColumn8.DisplayMember = "Название типа питания";
            this.dataGridViewComboBoxColumn8.HeaderText = "Тип питания";
            this.dataGridViewComboBoxColumn8.Name = "dataGridViewComboBoxColumn8";
            this.dataGridViewComboBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn8.ValueMember = "Код типа питания";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn20.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Стоимость единицы типа питания";
            dataGridViewCellStyle194.Format = "C2";
            dataGridViewCellStyle194.NullValue = null;
            this.dataGridViewTextBoxColumn21.DefaultCellStyle = dataGridViewCellStyle194;
            this.dataGridViewTextBoxColumn21.HeaderText = "Стоимость единицы типа питания";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewComboBoxColumn9
            // 
            this.dataGridViewComboBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn9.DataPropertyName = "ФИО ученика";
            this.dataGridViewComboBoxColumn9.DataSource = this.ученикиШколыBindingSource;
            this.dataGridViewComboBoxColumn9.DisplayMember = "ФИО ученика";
            this.dataGridViewComboBoxColumn9.HeaderText = "ФИО ученика";
            this.dataGridViewComboBoxColumn9.Name = "dataGridViewComboBoxColumn9";
            this.dataGridViewComboBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn9.ValueMember = "Код ученика";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Дата";
            dataGridViewCellStyle195.Format = "D";
            dataGridViewCellStyle195.NullValue = null;
            this.dataGridViewTextBoxColumn22.DefaultCellStyle = dataGridViewCellStyle195;
            this.dataGridViewTextBoxColumn22.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewComboBoxColumn10
            // 
            this.dataGridViewComboBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn10.DataPropertyName = "Тип питания";
            this.dataGridViewComboBoxColumn10.DataSource = this.справочникТиповПитанияBindingSource1;
            this.dataGridViewComboBoxColumn10.DisplayMember = "Название типа питания";
            this.dataGridViewComboBoxColumn10.HeaderText = "Тип питания";
            this.dataGridViewComboBoxColumn10.Name = "dataGridViewComboBoxColumn10";
            this.dataGridViewComboBoxColumn10.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn10.ValueMember = "Код типа питания";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn23.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Цена единицы типа питания";
            dataGridViewCellStyle196.Format = "C2";
            dataGridViewCellStyle196.NullValue = null;
            this.dataGridViewTextBoxColumn24.DefaultCellStyle = dataGridViewCellStyle196;
            this.dataGridViewTextBoxColumn24.HeaderText = "Цена единицы типа питания";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewComboBoxColumn11
            // 
            this.dataGridViewComboBoxColumn11.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewComboBoxColumn11.DataPropertyName = "Класс";
            this.dataGridViewComboBoxColumn11.DataSource = this.справочникКлассовBindingSource;
            this.dataGridViewComboBoxColumn11.DisplayMember = "Название класса";
            this.dataGridViewComboBoxColumn11.HeaderText = "Класс";
            this.dataGridViewComboBoxColumn11.Name = "dataGridViewComboBoxColumn11";
            this.dataGridViewComboBoxColumn11.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewComboBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewComboBoxColumn11.ValueMember = "Код класса";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Месяц";
            this.dataGridViewTextBoxColumn25.HeaderText = "Месяц";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "Год";
            this.dataGridViewTextBoxColumn26.HeaderText = "Год";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Название класса";
            this.dataGridViewTextBoxColumn27.HeaderText = "Название класса";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn28.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn28.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn29.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Цена питания";
            this.dataGridViewTextBoxColumn30.HeaderText = "Цена питания";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Месяц";
            this.dataGridViewTextBoxColumn31.HeaderText = "Месяц";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn32.DataPropertyName = "Год";
            this.dataGridViewTextBoxColumn32.HeaderText = "Год";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            this.dataGridViewTextBoxColumn32.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn33.DataPropertyName = "ФИО учителя";
            this.dataGridViewTextBoxColumn33.HeaderText = "ФИО учителя";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn34.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn34.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn35.DataPropertyName = "Итого количество";
            this.dataGridViewTextBoxColumn35.HeaderText = "Итого количество";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn36.DataPropertyName = "Итого стоимость питания";
            dataGridViewCellStyle197.Format = "C2";
            dataGridViewCellStyle197.NullValue = null;
            this.dataGridViewTextBoxColumn36.DefaultCellStyle = dataGridViewCellStyle197;
            this.dataGridViewTextBoxColumn36.HeaderText = "Итого стоимость питания";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn37.DataPropertyName = "Дата";
            dataGridViewCellStyle198.Format = "D";
            dataGridViewCellStyle198.NullValue = null;
            this.dataGridViewTextBoxColumn37.DefaultCellStyle = dataGridViewCellStyle198;
            this.dataGridViewTextBoxColumn37.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn38.DataPropertyName = "Название класса";
            this.dataGridViewTextBoxColumn38.HeaderText = "Название класса";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn39.DataPropertyName = "ФИО ученика";
            this.dataGridViewTextBoxColumn39.HeaderText = "ФИО ученика";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn40.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn40.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn41.DataPropertyName = "Дата";
            dataGridViewCellStyle199.Format = "D";
            dataGridViewCellStyle199.NullValue = null;
            this.dataGridViewTextBoxColumn41.DefaultCellStyle = dataGridViewCellStyle199;
            this.dataGridViewTextBoxColumn41.HeaderText = "Дата";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            // 
            // dataGridViewTextBoxColumn42
            // 
            this.dataGridViewTextBoxColumn42.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn42.DataPropertyName = "ФИО учителя";
            this.dataGridViewTextBoxColumn42.HeaderText = "ФИО учителя";
            this.dataGridViewTextBoxColumn42.Name = "dataGridViewTextBoxColumn42";
            // 
            // dataGridViewTextBoxColumn43
            // 
            this.dataGridViewTextBoxColumn43.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn43.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn43.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn43.Name = "dataGridViewTextBoxColumn43";
            // 
            // dataGridViewTextBoxColumn44
            // 
            this.dataGridViewTextBoxColumn44.DataPropertyName = "Дата затрат";
            this.dataGridViewTextBoxColumn44.HeaderText = "Дата затрат";
            this.dataGridViewTextBoxColumn44.Name = "dataGridViewTextBoxColumn44";
            // 
            // dataGridViewTextBoxColumn45
            // 
            this.dataGridViewTextBoxColumn45.DataPropertyName = "Наименование продукта";
            this.dataGridViewTextBoxColumn45.HeaderText = "Наименование продукта";
            this.dataGridViewTextBoxColumn45.Name = "dataGridViewTextBoxColumn45";
            // 
            // dataGridViewTextBoxColumn46
            // 
            this.dataGridViewTextBoxColumn46.DataPropertyName = "Количество на порцию ";
            this.dataGridViewTextBoxColumn46.HeaderText = "Количество на порцию ";
            this.dataGridViewTextBoxColumn46.Name = "dataGridViewTextBoxColumn46";
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn47.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.DataPropertyName = "Цена";
            this.dataGridViewTextBoxColumn48.HeaderText = "Цена";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.DataPropertyName = "Название типа питания";
            this.dataGridViewTextBoxColumn49.HeaderText = "Название типа питания";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.DataPropertyName = "Дата поставки";
            this.dataGridViewTextBoxColumn50.HeaderText = "Дата поставки";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.DataPropertyName = "Название поставщика";
            this.dataGridViewTextBoxColumn51.HeaderText = "Название поставщика";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.DataPropertyName = "Наименование продукта";
            this.dataGridViewTextBoxColumn52.HeaderText = "Наименование продукта";
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            // 
            // dataGridViewTextBoxColumn53
            // 
            this.dataGridViewTextBoxColumn53.DataPropertyName = "Единица измерения";
            this.dataGridViewTextBoxColumn53.HeaderText = "Единица измерения";
            this.dataGridViewTextBoxColumn53.Name = "dataGridViewTextBoxColumn53";
            // 
            // dataGridViewTextBoxColumn54
            // 
            this.dataGridViewTextBoxColumn54.DataPropertyName = "Цена за единицу измерения";
            dataGridViewCellStyle200.Format = "C2";
            dataGridViewCellStyle200.NullValue = null;
            this.dataGridViewTextBoxColumn54.DefaultCellStyle = dataGridViewCellStyle200;
            this.dataGridViewTextBoxColumn54.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn54.Name = "dataGridViewTextBoxColumn54";
            // 
            // dataGridViewTextBoxColumn55
            // 
            this.dataGridViewTextBoxColumn55.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn55.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn55.Name = "dataGridViewTextBoxColumn55";
            // 
            // dataGridViewTextBoxColumn56
            // 
            this.dataGridViewTextBoxColumn56.DataPropertyName = "Итого";
            this.dataGridViewTextBoxColumn56.HeaderText = "Итого";
            this.dataGridViewTextBoxColumn56.Name = "dataGridViewTextBoxColumn56";
            this.dataGridViewTextBoxColumn56.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn57
            // 
            this.dataGridViewTextBoxColumn57.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn57.DataPropertyName = "Дата расхода";
            this.dataGridViewTextBoxColumn57.HeaderText = "Дата расхода";
            this.dataGridViewTextBoxColumn57.Name = "dataGridViewTextBoxColumn57";
            // 
            // dataGridViewTextBoxColumn58
            // 
            this.dataGridViewTextBoxColumn58.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn58.DataPropertyName = "Наименование продукта";
            this.dataGridViewTextBoxColumn58.HeaderText = "Наименование продукта";
            this.dataGridViewTextBoxColumn58.Name = "dataGridViewTextBoxColumn58";
            // 
            // dataGridViewTextBoxColumn59
            // 
            this.dataGridViewTextBoxColumn59.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn59.DataPropertyName = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn59.HeaderText = "Цена за единицу измерения";
            this.dataGridViewTextBoxColumn59.Name = "dataGridViewTextBoxColumn59";
            // 
            // dataGridViewTextBoxColumn60
            // 
            this.dataGridViewTextBoxColumn60.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn60.DataPropertyName = "Количество";
            this.dataGridViewTextBoxColumn60.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn60.Name = "dataGridViewTextBoxColumn60";
            // 
            // dataGridViewTextBoxColumn61
            // 
            this.dataGridViewTextBoxColumn61.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn61.DataPropertyName = "Общая сумма";
            this.dataGridViewTextBoxColumn61.HeaderText = "Общая сумма";
            this.dataGridViewTextBoxColumn61.Name = "dataGridViewTextBoxColumn61";
            // 
            // view2TableAdapter
            // 
            this.view2TableAdapter.ClearBeforeFill = true;
            // 
            // view2BindingSource1
            // 
            this.view2BindingSource1.DataMember = "View2";
            this.view2BindingSource1.DataSource = this.schoolFoodDataSet;
            // 
            // к_расходуTableAdapter
            // 
            this.к_расходуTableAdapter.ClearBeforeFill = true;
            // 
            // расход_товаровTableAdapter
            // 
            this.расход_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // к_поставке_товаровTableAdapter
            // 
            this.к_поставке_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // поставка_товаровTableAdapter
            // 
            this.поставка_товаровTableAdapter.ClearBeforeFill = true;
            // 
            // затраты_продуктовTableAdapter
            // 
            this.затраты_продуктовTableAdapter.ClearBeforeFill = true;
            // 
            // питание_учениковTableAdapter
            // 
            this.питание_учениковTableAdapter.ClearBeforeFill = true;
            // 
            // питание_учителейTableAdapter
            // 
            this.питание_учителейTableAdapter.ClearBeforeFill = true;
            // 
            // ученики_школыTableAdapter
            // 
            this.ученики_школыTableAdapter.ClearBeforeFill = true;
            // 
            // учителя_школыTableAdapter
            // 
            this.учителя_школыTableAdapter.ClearBeforeFill = true;
            // 
            // справочник_классовTableAdapter
            // 
            this.справочник_классовTableAdapter.ClearBeforeFill = true;
            // 
            // view4TableAdapter
            // 
            this.view4TableAdapter.ClearBeforeFill = true;
            // 
            // справочник_продуктовTableAdapter
            // 
            this.справочник_продуктовTableAdapter.ClearBeforeFill = true;
            // 
            // справочник_поставщиковTableAdapter
            // 
            this.справочник_поставщиковTableAdapter.ClearBeforeFill = true;
            // 
            // schoolFoodDataSet1
            // 
            this.schoolFoodDataSet1.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // schoolFoodDataSet2
            // 
            this.schoolFoodDataSet2.DataSetName = "SchoolFoodDataSet";
            this.schoolFoodDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // view3BindingSource
            // 
            this.view3BindingSource.DataMember = "View3";
            this.view3BindingSource.DataSource = this.schoolFoodDataSet2;
            // 
            // справочник_типов_питанияTableAdapter
            // 
            this.справочник_типов_питанияTableAdapter.ClearBeforeFill = true;
            // 
            // view4BindingSource
            // 
            this.view4BindingSource.DataMember = "View4";
            this.view4BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // view8TableAdapter
            // 
            this.view8TableAdapter.ClearBeforeFill = true;
            // 
            // viewTableAdapter
            // 
            this.viewTableAdapter.ClearBeforeFill = true;
            // 
            // view61TableAdapter
            // 
            this.view61TableAdapter.ClearBeforeFill = true;
            // 
            // view51TableAdapter
            // 
            this.view51TableAdapter.ClearBeforeFill = true;
            // 
            // view3TableAdapter
            // 
            this.view3TableAdapter.ClearBeforeFill = true;
            // 
            // view41TableAdapter
            // 
            this.view41TableAdapter.ClearBeforeFill = true;
            // 
            // view1BindingSource
            // 
            this.view1BindingSource.DataMember = "View1";
            this.view1BindingSource.DataSource = this.schoolFoodDataSet;
            // 
            // поставкаТоваровBindingSource1
            // 
            this.поставкаТоваровBindingSource1.DataMember = "Поставка товаров";
            this.поставкаТоваровBindingSource1.DataSource = this.schoolFoodDataSet3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.bindingNavigator1);
            this.tabPage1.Controls.Add(this.dataGridView21);
            this.tabPage1.Location = new System.Drawing.Point(4, 58);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(688, 342);
            this.tabPage1.TabIndex = 7;
            this.tabPage1.Text = "Стоимость порции";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView21
            // 
            this.dataGridView21.AutoGenerateColumns = false;
            this.dataGridView21.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView21.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.датаЗатратDataGridViewTextBoxColumn2,
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn,
            this.названиеТипаПитанияDataGridViewTextBoxColumn});
            this.dataGridView21.DataSource = this.view10BindingSource;
            this.dataGridView21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView21.Location = new System.Drawing.Point(3, 3);
            this.dataGridView21.Name = "dataGridView21";
            this.dataGridView21.Size = new System.Drawing.Size(682, 336);
            this.dataGridView21.TabIndex = 1;
            // 
            // view10BindingSource
            // 
            this.view10BindingSource.DataMember = "View10";
            this.view10BindingSource.DataSource = this.schoolFoodDataSet3;
            // 
            // view10TableAdapter
            // 
            this.view10TableAdapter.ClearBeforeFill = true;
            // 
            // датаЗатратDataGridViewTextBoxColumn2
            // 
            this.датаЗатратDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.датаЗатратDataGridViewTextBoxColumn2.DataPropertyName = "Дата затрат";
            this.датаЗатратDataGridViewTextBoxColumn2.HeaderText = "Дата ";
            this.датаЗатратDataGridViewTextBoxColumn2.Name = "датаЗатратDataGridViewTextBoxColumn2";
            // 
            // стоимостьТипаПитанияDataGridViewTextBoxColumn
            // 
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Стоимость типа питания";
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Стоимость типа питания";
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.Name = "стоимостьТипаПитанияDataGridViewTextBoxColumn";
            this.стоимостьТипаПитанияDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // названиеТипаПитанияDataGridViewTextBoxColumn
            // 
            this.названиеТипаПитанияDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.названиеТипаПитанияDataGridViewTextBoxColumn.DataPropertyName = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn.HeaderText = "Название типа питания";
            this.названиеТипаПитанияDataGridViewTextBoxColumn.Name = "названиеТипаПитанияDataGridViewTextBoxColumn";
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = null;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = null;
            this.bindingNavigator1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2});
            this.bindingNavigator1.Location = new System.Drawing.Point(3, 314);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(682, 25);
            this.bindingNavigator1.TabIndex = 2;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(43, 22);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // Cooker
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(916, 461);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.Close_Pr);
            this.Controls.Add(this.pictureBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Cooker";
            this.Text = "Режим повара";
            this.Load += new System.EventHandler(this.Cooker_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage21.ResumeLayout(false);
            this.tabPage21.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator15)).EndInit();
            this.bindingNavigator15.ResumeLayout(false);
            this.bindingNavigator15.PerformLayout();
            this.tabPage22.ResumeLayout(false);
            this.tabPage22.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view41BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator17)).EndInit();
            this.bindingNavigator17.ResumeLayout(false);
            this.bindingNavigator17.PerformLayout();
            this.tabPage18.ResumeLayout(false);
            this.tabPage18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view61BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator19)).EndInit();
            this.bindingNavigator19.ResumeLayout(false);
            this.bindingNavigator19.PerformLayout();
            this.tabPage19.ResumeLayout(false);
            this.tabPage19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator20)).EndInit();
            this.bindingNavigator20.ResumeLayout(false);
            this.bindingNavigator20.PerformLayout();
            this.tabPage20.ResumeLayout(false);
            this.tabPage20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view8BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator14)).EndInit();
            this.bindingNavigator14.ResumeLayout(false);
            this.bindingNavigator14.PerformLayout();
            this.tabPage23.ResumeLayout(false);
            this.tabPage23.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator16)).EndInit();
            this.bindingNavigator16.ResumeLayout(false);
            this.bindingNavigator16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator11)).EndInit();
            this.bindingNavigator11.ResumeLayout(false);
            this.bindingNavigator11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.кПоставкеТоваровBindingSource)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникПродуктовBindingSource)).EndInit();
            this.tabPage10.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникПоставщиковBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.поставкаТоваровBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator10)).EndInit();
            this.bindingNavigator10.ResumeLayout(false);
            this.bindingNavigator10.PerformLayout();
            this.tabControl4.ResumeLayout(false);
            this.tabPage11.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникТиповПитанияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.расходТоваровBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator12)).EndInit();
            this.bindingNavigator12.ResumeLayout(false);
            this.bindingNavigator12.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.кРасходуBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator13)).EndInit();
            this.bindingNavigator13.ResumeLayout(false);
            this.bindingNavigator13.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator9)).EndInit();
            this.bindingNavigator9.ResumeLayout(false);
            this.bindingNavigator9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.затратыПродуктовBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView9)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabControl5.ResumeLayout(false);
            this.tabPage14.ResumeLayout(false);
            this.tabPage14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.учителяШколыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеУчителейBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator7)).EndInit();
            this.bindingNavigator7.ResumeLayout(false);
            this.bindingNavigator7.PerformLayout();
            this.tabPage15.ResumeLayout(false);
            this.tabPage15.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator8)).EndInit();
            this.bindingNavigator8.ResumeLayout(false);
            this.bindingNavigator8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеУчениковBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ученикиШколыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникТиповПитанияBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.справочникКлассовBindingSource)).EndInit();
            this.tabPage16.ResumeLayout(false);
            this.tabControl6.ResumeLayout(false);
            this.tabPage17.ResumeLayout(false);
            this.tabPage17.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.fillBy3ToolStrip.ResumeLayout(false);
            this.fillBy3ToolStrip.PerformLayout();
            this.fillBy2ToolStrip.ResumeLayout(false);
            this.fillBy2ToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view51BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator18)).EndInit();
            this.bindingNavigator18.ResumeLayout(false);
            this.bindingNavigator18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.view2BindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.schoolFoodDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view3BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view4BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view1BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.поставкаТоваровBindingSource1)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.view10BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Button Close_Pr;
        private System.Windows.Forms.TabPage tabPage21;
        private System.Windows.Forms.DataGridView dataGridView15;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗатратDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоНаПорциюDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource view2BindingSource;
        private SchoolFoodDataSet schoolFoodDataSet3;
        private System.Windows.Forms.BindingNavigator bindingNavigator15;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem12;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem12;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem12;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator36;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem12;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator37;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem12;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem12;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator38;
        private System.Windows.Forms.BindingSource справочникПродуктовBindingSource;
        private SchoolFoodDataSet schoolFoodDataSet;
        private System.Windows.Forms.BindingSource справочникТиповПитанияBindingSource;
        private System.Windows.Forms.BindingSource справочникПоставщиковBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.TabPage tabPage22;
        private System.Windows.Forms.DataGridView dataGridView14;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаПоставкиDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеПоставщикаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn итогоDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource view41BindingSource;
        private System.Windows.Forms.BindingNavigator bindingNavigator17;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem14;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem14;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem14;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator42;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem14;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator43;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem14;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem14;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator41;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem13;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem13;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator40;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem13;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator39;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem13;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem13;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаРасходаDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource поставкаТоваровBindingSource;
        private System.Windows.Forms.TabPage tabPage18;
        private System.Windows.Forms.BindingSource view61BindingSource;
        private SchoolFoodDataSet schoolFoodDataSet5;
        private System.Windows.Forms.BindingNavigator bindingNavigator19;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem16;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem16;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem16;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator48;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem16;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator49;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem16;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem16;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator50;
        private System.Windows.Forms.BindingSource кПоставкеТоваровBindingSource;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem13;
        private System.Windows.Forms.BindingSource справочникКлассовBindingSource;
        private System.Windows.Forms.BindingSource ученикиШколыBindingSource;
        private System.Windows.Forms.TabPage tabPage19;
        private System.Windows.Forms.DataGridView dataGridView19;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеКлассаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУченикаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn4;
        private System.Windows.Forms.BindingSource viewBindingSource;
        private System.Windows.Forms.BindingNavigator bindingNavigator20;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem17;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem17;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem17;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator51;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem17;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator52;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem17;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem17;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator53;
        private System.Windows.Forms.TabPage tabPage20;
        private System.Windows.Forms.DataGridView dataGridView20;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУчителяDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn5;
        private System.Windows.Forms.BindingSource view8BindingSource;
        private SchoolFoodDataSet schoolFoodDataSet6;
        private System.Windows.Forms.BindingNavigator bindingNavigator14;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem11;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem11;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem11;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator33;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem11;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator34;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem11;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem11;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator35;
        private System.Windows.Forms.BindingSource учителяШколыBindingSource;
        private System.Windows.Forms.TabPage tabPage23;
        private System.Windows.Forms.DataGridView dataGridView16;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаРасходаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn общаяСуммаDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource view3BindingSource1;
        private SchoolFoodDataSet schoolFoodDataSet4;
        private System.Windows.Forms.BindingNavigator bindingNavigator16;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator47;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem15;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem15;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator46;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem15;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator45;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem15;
        private System.Windows.Forms.DataGridViewTextBoxColumn накладнойDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn типПитанияDataGridViewTextBoxColumn3;
        private SchoolFoodDataSetTableAdapters.View2TableAdapter view2TableAdapter;
        private System.Windows.Forms.BindingSource view2BindingSource1;
        private SchoolFoodDataSetTableAdapters.К_расходуTableAdapter к_расходуTableAdapter;
        private SchoolFoodDataSetTableAdapters.Расход_товаровTableAdapter расход_товаровTableAdapter;
        private SchoolFoodDataSetTableAdapters.К_поставке_товаровTableAdapter к_поставке_товаровTableAdapter;
        private SchoolFoodDataSetTableAdapters.Поставка_товаровTableAdapter поставка_товаровTableAdapter;
        private SchoolFoodDataSetTableAdapters.Затраты_продуктовTableAdapter затраты_продуктовTableAdapter;
        private SchoolFoodDataSetTableAdapters.Питание_учениковTableAdapter питание_учениковTableAdapter;
        private SchoolFoodDataSetTableAdapters.Питание_учителейTableAdapter питание_учителейTableAdapter;
        private SchoolFoodDataSetTableAdapters.Ученики_школыTableAdapter ученики_школыTableAdapter;
        private SchoolFoodDataSetTableAdapters.Учителя_школыTableAdapter учителя_школыTableAdapter;
        private SchoolFoodDataSetTableAdapters.Справочник_классовTableAdapter справочник_классовTableAdapter;
        private SchoolFoodDataSetTableAdapters.View4TableAdapter view4TableAdapter;
        private SchoolFoodDataSetTableAdapters.Справочник_продуктовTableAdapter справочник_продуктовTableAdapter;
        private SchoolFoodDataSetTableAdapters.Справочник_поставщиковTableAdapter справочник_поставщиковTableAdapter;
        private SchoolFoodDataSet schoolFoodDataSet1;
        private SchoolFoodDataSet schoolFoodDataSet2;
        private System.Windows.Forms.BindingSource view3BindingSource;
        private SchoolFoodDataSetTableAdapters.Справочник_типов_питанияTableAdapter справочник_типов_питанияTableAdapter;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem15;
        private System.Windows.Forms.BindingSource view4BindingSource;
        private SchoolFoodDataSetTableAdapters.View8TableAdapter view8TableAdapter;
        private SchoolFoodDataSetTableAdapters.ViewTableAdapter viewTableAdapter;
        private SchoolFoodDataSetTableAdapters.View61TableAdapter view61TableAdapter;
        private SchoolFoodDataSetTableAdapters.View51TableAdapter view51TableAdapter;
        private SchoolFoodDataSetTableAdapters.View3TableAdapter view3TableAdapter;
        private SchoolFoodDataSetTableAdapters.View41TableAdapter view41TableAdapter;
        private System.Windows.Forms.BindingSource справочникТиповПитанияBindingSource1;
        private System.Windows.Forms.BindingSource питаниеУчениковBindingSource;
        private System.Windows.Forms.BindingSource питаниеУчителейBindingSource;
        private System.Windows.Forms.DataGridViewComboBoxColumn типПитанияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn продуктDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗатратDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource затратыПродуктовBindingSource;
        private System.Windows.Forms.BindingSource кРасходуBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn общаяСуммаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewComboBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn накладнойDataGridViewTextBoxColumn3;
        private System.Windows.Forms.BindingSource расходТоваровBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоНаПорциюDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоУчащихсяDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource view1BindingSource;
        private System.Windows.Forms.BindingSource view51BindingSource;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem15;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem10;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem10;
        private System.Windows.Forms.BindingNavigator bindingNavigator11;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem10;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator30;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem10;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator31;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem10;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator32;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton10;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridView11;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.BindingNavigator bindingNavigator10;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem9;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem9;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator27;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem9;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator28;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem9;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator29;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton9;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.TabPage tabPage11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView12;
        private System.Windows.Forms.BindingNavigator bindingNavigator12;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator11;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator12;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator13;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator14;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dataGridView13;
        private System.Windows.Forms.BindingNavigator bindingNavigator13;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton10;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator15;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator16;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator17;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator18;
        private System.Windows.Forms.TabPage tabPage12;
        private System.Windows.Forms.BindingNavigator bindingNavigator9;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem8;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem8;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator24;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem8;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator25;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem8;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator26;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton8;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.DataGridView dataGridView9;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage13;
        private System.Windows.Forms.TabControl tabControl5;
        private System.Windows.Forms.TabPage tabPage14;
        private System.Windows.Forms.DataGridView dataGridView7;
        private System.Windows.Forms.BindingNavigator bindingNavigator7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem6;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem6;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator18;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem6;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator19;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem6;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem6;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator20;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton6;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.TabPage tabPage15;
        private System.Windows.Forms.BindingNavigator bindingNavigator8;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem7;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem7;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator21;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem7;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator22;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem7;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem7;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator23;
        private System.Windows.Forms.ToolStripButton сохранитьToolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.TabPage tabPage16;
        private System.Windows.Forms.TabControl tabControl6;
        private System.Windows.Forms.TabPage tabPage17;
        private System.Windows.Forms.BindingNavigator bindingNavigator18;
        private System.Windows.Forms.BindingSource поставкаТоваровBindingSource1;
        private System.Windows.Forms.DataGridViewTextBoxColumn накладнойDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn наименованиеПродуктаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn единицаИзмеренияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЗаЕдиницуИзмеренияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn фИОУчителяDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn типПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn стоимостьЕдиницыТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn фИОУченикаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn типПитанияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаЕдиницыТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn классDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn накладнойDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаПоставкиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn поставщикDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView17;
        private System.Windows.Forms.DataGridViewTextBoxColumn Месяц;
        private System.Windows.Forms.DataGridViewTextBoxColumn Год;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеКлассаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоDataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn ценаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn фИОУчителяDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn итогоКоличествоDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn итогоСтоимостьПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private System.Windows.Forms.ToolStripButton toolStripButton18;
        private System.Windows.Forms.ToolStripButton toolStripButton19;
        private System.Windows.Forms.ToolStripButton toolStripButton20;
        private System.Windows.Forms.ToolStripButton toolStripButton21;
        private System.Windows.Forms.ToolStripButton toolStripButton22;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn6;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewComboBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn53;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn54;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn55;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn56;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn57;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn59;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn60;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn61;
        private System.Windows.Forms.ToolStrip fillBy2ToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel3;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox3;
        private System.Windows.Forms.ToolStripButton fillBy2ToolStripButton;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripButton23;
        private System.Windows.Forms.ToolStrip fillBy3ToolStrip;
        private System.Windows.Forms.ToolStripLabel param1ToolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox param1ToolStripTextBox1;
        private System.Windows.Forms.ToolStripLabel param2ToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox param2ToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillBy3ToolStripButton;
        private System.Windows.Forms.ToolStripButton toolStripButton24;
        private System.Windows.Forms.ToolStripButton toolStripButton25;
        private System.Windows.Forms.ToolStripButton toolStripButton26;
        private System.Windows.Forms.ToolStripButton toolStripButton27;
        private System.Windows.Forms.ToolStripButton toolStripButton28;
        private System.Windows.Forms.ToolStripButton toolStripButton29;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridView21;
        private System.Windows.Forms.BindingSource view10BindingSource;
        private SchoolFoodDataSetTableAdapters.View10TableAdapter view10TableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗатратDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn стоимостьТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеТипаПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
    }
}